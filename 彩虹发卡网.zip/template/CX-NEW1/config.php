<?php
/**
 * CX-NEW1 模板配置文件
 * 作者：神秘人
 * 博客地址：www.7cvv.cn
 * Q群：1011130040
 */

$template_info = [
    'name' => 'CX-NEW1',
    'version' => 1.0,
];

$template_settings = [
    'top_image' => ['name' => '顶部图片', 'type' => 'input', 'note' => '仅支持本地路径，如：assets/img/above.png'],
];