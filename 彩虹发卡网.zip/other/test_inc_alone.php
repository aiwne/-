<?php
// 专门测试inc.php文件的脚本

// 直接输出基本信息，确保脚本能运行
echo "<h1>inc.php 测试</h1>";
echo "<p>测试时间: " . date('Y-m-d H:i:s') . "</p>";

// 检查inc.php文件
echo "<h2>1. 文件检查</h2>";
$inc_path = __DIR__ . '/inc.php';
echo "<p>inc.php路径: $inc_path</p>";

if (file_exists($inc_path)) {
    echo "<p style='color: green;'>✓ 文件存在</p>";
    echo "<p>文件大小: " . filesize($inc_path) . " bytes</p>";
    
    // 尝试读取文件内容（前200字符）
    echo "<h2>2. 文件内容预览</h2>";
    $content = file_get_contents($inc_path, false, null, 0, 200);
    echo "<pre style='background: #f0f0f0; padding: 10px;'>" . htmlspecialchars($content) . "...</pre>";
    
    // 尝试使用不同方式加载文件
    echo "<h2>3. 文件加载测试</h2>";
    
    // 方法1: 使用include_once并捕获输出
    echo "<h3>方法1: include_once</h3>";
    ob_start();
    $result1 = @include_once $inc_path;
    $output1 = ob_get_clean();
    echo "<p>返回值: " . ($result1 ? 'true' : 'false') . "</p>";
    if (!empty($output1)) {
        echo "<p>输出: " . nl2br(htmlspecialchars($output1)) . "</p>";
    }
    
    // 方法2: 使用require_once（更严格）
    echo "<h3>方法2: require_once</h3>";
    ob_start();
    $result2 = false;
    try {
        require_once $inc_path;
        $result2 = true;
    } catch (Exception $e) {
        echo "<p style='color: red;'>捕获异常: " . $e->getMessage() . "</p>";
    }
    $output2 = ob_get_clean();
    echo "<p>结果: " . ($result2 ? '成功' : '失败') . "</p>";
    if (!empty($output2)) {
        echo "<p>输出: " . nl2br(htmlspecialchars($output2)) . "</p>";
    }
    
    // 方法3: 逐行读取执行（调试用）
    echo "<h3>方法3: 逐行读取分析</h3>";
    $lines = file($inc_path);
    echo "<p>文件总行数: " . count($lines) . "</p>";
    
    // 检查前10行
    echo "<h4>前10行:</h4>";
    echo "<pre style='background: #f0f0f0; padding: 10px;'>";
    for ($i = 0; $i < min(10, count($lines)); $i++) {
        echo ($i+1) . ": " . rtrim(htmlspecialchars($lines[$i])) . "\n";
    }
    echo "</pre>";
    
    // 检查是否有语法错误
    echo "<h3>方法4: PHP语法检查</h3>";
    // 使用php -l命令检查语法
    $cmd = "php -l " . escapeshellarg($inc_path);
    echo "<p>执行命令: $cmd</p>";
    $output = shell_exec($cmd);
    echo "<p>语法检查结果: " . htmlspecialchars($output) . "</p>";
    
} else {
    echo "<p style='color: red;'>✗ 文件不存在</p>";
}

echo "<h2>测试完成</h2>";
