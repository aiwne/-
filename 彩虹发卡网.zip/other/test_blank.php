<?php
// 极致简单的测试脚本，只测试基本输出和配置加载

// 直接输出HTML，确保能看到内容
echo "<!DOCTYPE html>\n";
echo "<html>\n";
echo "<head>\n";
echo "<meta charset='UTF-8'>\n";
echo "<title>空白页测试</title>\n";
echo "</head>\n";
echo "<body>\n";
echo "<h1>空白页测试</h1>\n";
echo "<p>当前时间: " . date('Y-m-d H:i:s') . "</p>\n";

echo "<h2>请求信息</h2>\n";
echo "<p>请求URL: " . $_SERVER['REQUEST_URI'] . "</p>\n";
echo "<p>请求方法: " . $_SERVER['REQUEST_METHOD'] . "</p>\n";
echo "<p>PHP版本: " . phpversion() . "</p>\n";

echo "<h2>GET参数</h2>\n";
if (!empty($_GET)) {
    echo "<ul>\n";
    foreach ($_GET as $key => $value) {
        echo "<li>$key: $value</li>\n";
    }
    echo "</ul>\n";
} else {
    echo "<p>无GET参数</p>\n";
}

echo "<h2>服务器信息</h2>\n";
echo "<p>服务器软件: " . $_SERVER['SERVER_SOFTWARE'] . "</p>\n";
echo "<p>文档根目录: " . $_SERVER['DOCUMENT_ROOT'] . "</p>\n";
echo "<p>脚本路径: " . $_SERVER['SCRIPT_FILENAME'] . "</p>\n";

echo "<h2>PHP配置</h2>\n";
echo "<p>error_reporting: " . error_reporting() . "</p>\n";
echo "<p>display_errors: " . ini_get('display_errors') . "</p>\n";
echo "<p>log_errors: " . ini_get('log_errors') . "</p>\n";
echo "<p>error_log: " . ini_get('error_log') . "</p>\n";
echo "<p>output_buffering: " . ini_get('output_buffering') . "</p>\n";

echo "<h2>文件权限测试</h2>\n";
$test_file = __DIR__ . '/test_write.txt';
$can_write = is_writable(__DIR__);
echo "<p>当前目录可写: " . ($can_write ? '是' : '否') . "</p>\n";

if ($can_write) {
    $write_result = file_put_contents($test_file, "测试写入 - " . date('Y-m-d H:i:s'));
    echo "<p>写入测试文件: " . ($write_result ? '成功' : '失败') . "</p>\n";
    if ($write_result) {
        echo "<p>写入大小: $write_result bytes</p>\n";
        unlink($test_file); // 清理测试文件
    }
}

echo "<h2>简单包含测试</h2>\n";
$simple_inc = __DIR__ . '/test_inc.php';

// 创建一个简单的测试包含文件
file_put_contents($simple_inc, "<?php\n\$test_inc_var = '测试变量值';\necho '<p>从包含文件输出: 包含成功</p>\n';\n?>");

echo "<p>尝试包含简单文件...</p>\n";
@include $simple_inc;
if (isset($test_inc_var)) {
    echo "<p>包含文件变量: $test_inc_var</p>\n";
}
unlink($simple_inc); // 清理测试文件

echo "<h2>测试完成</h2>\n";
echo "</body></html>\n";
