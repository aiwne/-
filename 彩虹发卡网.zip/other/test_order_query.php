<?php
// 测试 orderQuery 方法修复

// 模拟配置
$config = array(
    'sign_type' => 'RSA2',
    'alipay_public_key' => 'test_public_key',
    'merchant_private_key' => 'test_private_key',
    'charset' => 'UTF-8',
    'gatewayUrl' => 'https://openapi.alipay.com/gateway.do',
    'app_id' => 'test_app_id',
    'notify_url' => 'http://example.com/notify',
    'return_url' => 'http://example.com/return',
);

try {
    // 加载 AlipayTradeService 类
    require_once __DIR__ . '/alipay/AlipayTradeService.php';
    
    // 创建服务实例
    $alipayService = new AlipayTradeService($config);
    
    echo "AlipayTradeService 实例创建成功\n";
    
    // 测试数组参数（out_trade_no）
    $testParams = array('out_trade_no' => 'test_trade_123');
    echo "测试数组参数：" . json_encode($testParams) . "\n";
    
    // 模拟 orderQuery 内部逻辑
    $queryContentBuilder = new AlipayTradeQueryContentBuilder();
    if (is_array($testParams)) {
        if (isset($testParams['out_trade_no'])) {
            $queryContentBuilder->setOutTradeNo($testParams['out_trade_no']);
            echo "调用 setOutTradeNo 成功\n";
        } elseif (isset($testParams['trade_no'])) {
            $queryContentBuilder->setTradeNo($testParams['trade_no']);
            echo "调用 setTradeNo 成功\n";
        } else {
            throw new Exception('缺少必要的订单参数');
        }
    }
    
    $bizContent = $queryContentBuilder->getBizContent();
    echo "生成的业务参数：" . $bizContent . "\n";
    
    echo "\n测试成功！orderQuery 方法现在支持数组参数了\n";
    
} catch (Exception $e) {
    echo "测试失败：" . $e->getMessage() . "\n";
    echo "错误堆栈：" . $e->getTraceAsString() . "\n";
}
?>