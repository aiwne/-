<?php
// 极简测试脚本
echo "<h1>测试页面</h1>";
echo "<p>当前时间: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>PHP版本: " . phpversion() . "</p>";

// 检查基本变量
echo "<h2>基本变量</h2>";
echo "<p>__DIR__: " . __DIR__ . "</p>";
echo "<p>SYSTEM_ROOT: " . (defined('SYSTEM_ROOT') ? SYSTEM_ROOT : '未定义') . "</p>";
echo "<p>ROOT: " . (defined('ROOT') ? ROOT : '未定义') . "</p>";

// 检查文件存在性
echo "<h2>文件检查</h2>";
$files = array(
    'inc.php' => __DIR__ . '/inc.php',
    'WxPay.Api.php' => __DIR__ . '/wxpay/WxPay.Api.php'
);

foreach ($files as $name => $path) {
    echo "<p>$name: " . (file_exists($path) ? '存在' : '不存在') . "</p>";
    if (file_exists($path)) {
        echo "<p>  大小: " . filesize($path) . " bytes</p>";
    }
}

// 检查PHP配置
echo "<h2>PHP配置</h2>";
echo "<p>error_reporting: " . error_reporting() . "</p>";
echo "<p>display_errors: " . ini_get('display_errors') . "</p>";
echo "<p>log_errors: " . ini_get('log_errors') . "</p>";
echo "<p>error_log: " . ini_get('error_log') . "</p>";

// 尝试简单的包含
echo "<h2>包含测试</h2>";
$inc_path = __DIR__ . '/inc.php';
if (file_exists($inc_path)) {
    echo "<p>尝试包含 inc.php...</p>";
    
    // 使用输出缓冲捕获错误
    ob_start();
    $result = @include $inc_path;
    $output = ob_get_clean();
    
    echo "<p>包含结果: " . ($result ? '成功' : '失败') . "</p>";
    if ($output) {
        echo "<p>输出: " . nl2br(htmlspecialchars($output)) . "</p>";
    }
} else {
    echo "<p>inc.php 不存在，跳过包含测试</p>";
}

// 尝试读取文件内容
echo "<h2>文件内容测试</h2>";
$wxpay_api_path = __DIR__ . '/wxpay/WxPay.Api.php';
if (file_exists($wxpay_api_path)) {
    echo "<p>尝试读取 WxPay.Api.php 前1000字符...</p>";
    $content = @file_get_contents($wxpay_api_path, false, null, 0, 1000);
    if ($content) {
        echo "<pre>" . htmlspecialchars($content) . "</pre>";
    } else {
        echo "<p>读取失败</p>";
    }
} else {
    echo "<p>WxPay.Api.php 不存在，跳过读取测试</p>";
}

echo "<h2>测试完成</h2>";
