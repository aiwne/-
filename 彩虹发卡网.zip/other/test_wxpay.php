<?php
// 简单的微信支付测试脚本

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 加载配置
require 'inc.php';

echo "<h1>微信支付测试</h1>";
echo "<p>当前配置：</p>";
echo "<ul>";
echo "<li>wxpay_api: " . $conf['wxpay_api'] . "</li>";
echo "<li>wxpay_appid: " . $conf['wxpay_appid'] . "</li>";
echo "<li>wxpay_mchid: " . $conf['wxpay_mchid'] . "</li>";
echo "<li>wxpay_key: " . (empty($conf['wxpay_key']) ? '未设置' : '已设置') . "</li>";
echo "</ul>";

// 检查微信支付SDK文件
$wxpay_files = array(
    'WxPay.Api.php' => SYSTEM_ROOT . 'wxpay/WxPay.Api.php',
    'WxPay.Config.php' => SYSTEM_ROOT . 'wxpay/WxPay.Config.php',
    'WxPay.Data.php' => SYSTEM_ROOT . 'wxpay/WxPay.Data.php',
    'WxPay.Exception.php' => SYSTEM_ROOT . 'wxpay/WxPay.Exception.php'
);

echo "<p>微信支付SDK文件检查：</p>";
echo "<ul>";
foreach ($wxpay_files as $name => $path) {
    if (file_exists($path)) {
        echo "<li style='color: green;'>✓ $name: 存在</li>";
    } else {
        echo "<li style='color: red;'>✗ $name: 不存在</li>";
    }
}
echo "</ul>";

// 尝试加载SDK文件
echo "<p>加载微信支付SDK：</p>";
try {
    require_once SYSTEM_ROOT . 'wxpay/WxPay.Api.php';
    echo "<p style='color: green;'>✓ 微信支付SDK加载成功</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ 微信支付SDK加载失败：" . $e->getMessage() . "</p>";
    exit;
}

// 测试配置类
echo "<p>测试WxPayConfig类：</p>";
try {
    echo "<ul>";
    echo "<li>APPID: " . WxPayConfig::APPID . "</li>";
    echo "<li>MCHID: " . WxPayConfig::MCHID . "</li>";
    echo "<li>KEY: " . (empty(WxPayConfig::KEY) ? '未设置' : '已设置') . "</li>";
    echo "</ul>";
    echo "<p style='color: green;'>✓ WxPayConfig类测试成功</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ WxPayConfig类测试失败：" . $e->getMessage() . "</p>";
    exit;
}

echo "<p><strong>测试完成！</strong></p>";
?>