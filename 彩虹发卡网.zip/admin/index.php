<?php
/**
 * 管理后台首页
 */
include("../includes/common.php");
$title = '管理控制中心';
include './head.php';

if ($islogin != 1) {
    exit("<script>window.location.href='./login.php';</script>");
}

// 智能建表检查
$check_tables = $DB->getAll("SHOW TABLES LIKE 'shua_visit_%'");
$existing_tables = array_column($check_tables, 0);
if (!in_array('shua_visit_statistics', $existing_tables)) {
    $DB->query("CREATE TABLE `shua_visit_statistics` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `date` DATE NOT NULL UNIQUE,
        `visits` INT NOT NULL DEFAULT 0,
        `ip_count` INT NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
if (!in_array('shua_visit_ips', $existing_tables)) {
    $DB->query("CREATE TABLE `shua_visit_ips` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `date` DATE NOT NULL,
        `ip` VARCHAR(45) NOT NULL,
        `url` VARCHAR(255) DEFAULT '-',
        `user_agent` TEXT,
        `region` VARCHAR(100) DEFAULT '未知地区',
        `visits` INT NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `unique_ip_date` (`date`, `ip`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// 记录访问统计
$today = date('Y-m-d');
$ip = x_real_ip();
$url = isset($_SERVER['REQUEST_URI']) ? htmlspecialchars($_SERVER['REQUEST_URI']) : '-';
$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? htmlspecialchars($_SERVER['HTTP_USER_AGENT']) : '-';

$DB->query("INSERT IGNORE INTO `shua_visit_statistics` (`date`, `visits`, `ip_count`) VALUES (:date, 1, 0)", [':date' => $today]);
$DB->query("UPDATE `shua_visit_statistics` SET `visits` = `visits` + 1 WHERE `date` = :date", [':date' => $today]);

$ip_exists = $DB->getRow("SELECT `id` FROM `shua_visit_ips` WHERE `date` = :date AND `ip` = :ip", [':date' => $today, ':ip' => $ip]);
if ($ip_exists) {
    $DB->query("UPDATE `shua_visit_ips` SET `visits` = `visits` + 1, `url` = :url, `user_agent` = :ua WHERE `date` = :date AND `ip` = :ip", 
        [':date' => $today, ':ip' => $ip, ':url' => $url, ':ua' => $user_agent]);
} else {
    $DB->query("INSERT INTO `shua_visit_ips` (`date`, `ip`, `url`, `user_agent`) VALUES (:date, :ip, :url, :ua)", 
        [':date' => $today, ':ip' => $ip, ':url' => $url, ':ua' => $user_agent]);
    $DB->query("UPDATE `shua_visit_statistics` SET `ip_count` = `ip_count` + 1 WHERE `date` = :date", [':date' => $today]);
}

$mysqlversion = $DB->getColumn("SELECT VERSION()");
$sec_msg = sec_check();
?>

<!-- 引入 Flot 图表库（字节跳动CDN） -->
<script src="//s1.pstatp.com/cdn/expire-1-M/flot/0.8.3/jquery.flot.min.js"></script>
<script src="//s1.pstatp.com/cdn/expire-1-M/flot/0.8.3/jquery.flot.resize.min.js"></script>
<script src="//s1.pstatp.com/cdn/expire-1-M/flot/0.8.3/jquery.flot.time.min.js"></script>
<script src="//s1.pstatp.com/cdn/expire-1-M/flot/0.8.3/jquery.flot.tooltip.min.js"></script>

<style>
/* 基础样式保持原样 */
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background: #f8fafc;
    color: #334155;
    line-height: 1.6;
}

/* ===== 修复：访问详情弹窗加宽（电脑端90%，最大1400px） ===== */
@media (min-width: 992px) {
    #visitDetailModal .modal-dialog {
        width: 90% !important;
        max-width: 1400px !important;
    }
}

@media (min-width: 1400px) {
    #visitDetailModal .modal-dialog {
        width: 85% !important;
        max-width: 1600px !important;
    }
}

/* 手机端保持原样，不铺满 */
@media (max-width: 767px) {
    #visitDetailModal .modal-dialog {
        width: auto !important;
        margin: 10px !important;
        max-width: none !important;
    }
}

/* 访问详情关闭按钮也在右边 */
#visitDetailModal .modal-header {
    position: relative;
    padding: 15px 20px;
    border-bottom: 1px solid #e2e8f0;
}

#visitDetailModal .modal-header h4 {
    float: left;
    margin: 0;
    font-weight: 700;
    color: #1e293b;
    line-height: 30px;
}

#visitDetailModal .modal-header .close {
    float: right;
    font-size: 28px;
    font-weight: 700;
    line-height: 30px;
    color: #64748b;
    text-shadow: none;
    opacity: 0.6;
    background: none;
    border: none;
    padding: 0;
    margin: 0;
    cursor: pointer;
}

#visitDetailModal .modal-header .close:hover {
    opacity: 1;
    color: #333;
}

#visitDetailModal .modal-header::after {
    content: "";
    display: table;
    clear: both;
}

/* 以下保持你的原样不变 */
.dashboard-wrap { padding: 30px; max-width: 1600px; margin: 0 auto; }

.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 24px;
    margin-bottom: 30px;
}

@media (max-width: 991px) {
    .stats-row { grid-template-columns: repeat(2, 1fr); }
    .dashboard-wrap { padding: 20px; }
}

@media (max-width: 767px) {
    .stats-row { grid-template-columns: 1fr; }
    .dashboard-wrap { padding: 12px; }
}

.main-content {
    display: grid;
    grid-template-columns: 1fr 360px;
    gap: 30px;
}

@media (max-width: 991px) {
    .main-content { display: flex; flex-direction: column; }
}

.left-panel { display: flex; flex-direction: column; gap: 30px; }
.right-panel { display: flex; flex-direction: column; gap: 24px; }

.stat-box {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.stat-info h3 {
    font-size: 14px;
    color: #64748b;
    font-weight: 600;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-number {
    font-size: 28px;
    font-weight: 700;
    color: #1e293b;
    font-family: 'Courier New', monospace;
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    color: white;
}

.stat-icon.blue { background: #3b82f6; }
.stat-icon.orange { background: #f97316; }
.stat-icon.green { background: #10b981; }
.stat-icon.purple { background: #8b5cf6; }
.stat-icon.pink { background: #ec4899; }
.stat-icon.cyan { background: #06b6d4; }

.chart-wrapper {
    padding: 30px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e2e8f0;
    flex-wrap: wrap;
    gap: 12px;
}

.chart-title {
    font-size: 18px;
    font-weight: 700;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.chart-title i {
    width: 36px;
    height: 36px;
    background: #f1f5f9;
    color: #3b82f6;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
}

.chart-tabs {
    display: flex;
    gap: 4px;
    background: #f1f5f9;
    padding: 4px;
    border-radius: 8px;
}

.tab-btn {
    padding: 8px 16px;
    border: none;
    background: transparent;
    color: #64748b;
    font-size: 13px;
    font-weight: 600;
    border-radius: 6px;
    cursor: pointer;
}

.tab-btn.active {
    background: white;
    color: #3b82f6;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.chart-box { height: 380px; width: 100%; margin-top: 20px; }
@media (max-width: 767px) { .chart-box { height: 250px; } }

.pay-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid #e2e8f0;
}

.pay-item { text-align: center; padding: 20px; background: #f8fafc; border-radius: 10px; }
.pay-icon { font-size: 24px; margin-bottom: 8px; }
.pay-value { font-size: 20px; font-weight: 700; color: #1e293b; font-family: 'Courier New', monospace; }

.visit-chart-wrapper {
    padding: 30px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.visit-chart-box { height: 300px; width: 100%; margin-top: 20px; }

.side-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.side-title {
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 8px;
}

.info-list { display: flex; flex-direction: column; gap: 12px; }
.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px;
    background: #f8fafc;
    border-radius: 8px;
    font-size: 14px;
}
.info-label { color: #64748b; display: flex; align-items: center; gap: 6px; }
.info-value { font-weight: 600; color: #334155; font-family: 'Courier New', monospace; font-size: 13px; }

.sub-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.sub-box { text-align: center; padding: 20px; background: #f8fafc; border-radius: 10px; cursor: pointer; }
.sub-num { font-size: 20px; font-weight: 700; color: #1e293b; font-family: 'Courier New', monospace; margin-bottom: 4px; }
.sub-text { font-size: 12px; color: #64748b; }

.sec-item {
    padding: 12px;
    border-radius: 8px;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}
.sec-item.success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
.sec-item.warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }

.work-box {
    background: linear-gradient(135deg, #fef2f2 0%, #fff7ed 100%);
    border: 1px solid #fecaca;
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    cursor: pointer;
}
.work-num { font-size: 36px; font-weight: 800; color: #ef4444; font-family: 'Courier New', monospace; margin: 12px 0; }

.ad-box {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.skeleton-box {
    background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 8px;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
}
@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }

#visitDetailModal .modal-content { border-radius: 12px; border: none; }
#visitDetailModal .table th { background: #f8fafc; font-weight: 600; font-size: 13px; color: #64748b; border: none; padding: 12px; }
#visitDetailModal .table td { padding: 12px; font-size: 13px; border-bottom: 1px solid #f1f5f9; }
</style>

<!-- 访问详情弹窗（已加宽） -->
<div class="modal fade" id="visitDetailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4>
                    <i class="fa fa-list-alt" style="color: #3b82f6; margin-right: 8px;"></i>
                    访问详情
                </h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 0; max-height: 60vh; overflow-y: auto;">
                <div id="visitDetailLoading" style="padding: 40px; text-align: center;">
                    <i class="fa fa-spinner fa-spin fa-2x" style="color: #3b82f6;"></i>
                    <p style="margin-top: 12px; color: #64748b;">加载中...</p>
                </div>
                <div id="visitDetailContent" style="display: none;">
                    <div class="table-responsive">
                        <table class="table table-hover" style="margin: 0;">
                            <thead>
                                <tr>
                                    <th>IP地址</th>
                                    <th>访问URL</th>
                                    <th>地区</th>
                                    <th>时间</th>
                                    <th>次数</th>
                                    <th>浏览器</th>
                                </tr>
                            </thead>
                            <tbody id="visitDetailTable"></tbody>
                        </table>
                    </div>
                    <div style="padding: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: center;">
                        <ul class="pagination" id="visitDetailPagination" style="margin: 0;"></ul>
                    </div>
                </div>
                <div id="visitDetailEmpty" style="display: none; padding: 40px; text-align: center; color: #64748b;">
                    <i class="fa fa-inbox fa-3x" style="margin-bottom: 16px; opacity: 0.3;"></i>
                    <p>暂无访问记录</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-wrap">
    
    <!-- 顶部统计 -->
    <div class="stats-row">
        <div class="stat-box">
            <div class="stat-info">
                <h3>订单总数</h3>
                <div class="stat-number" id="count1">0</div>
            </div>
            <div class="stat-icon blue">
                <i class="fa fa-list-ol"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>待处理订单</h3>
                <div class="stat-number" id="count3" style="color: #f97316;">0</div>
            </div>
            <div class="stat-icon orange">
                <i class="fa fa-hourglass-half"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>今日订单</h3>
                <div class="stat-number" id="count4" style="color: #10b981;">0</div>
            </div>
            <div class="stat-icon green">
                <i class="fa fa-calendar-check-o"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>今日交易额</h3>
                <div class="stat-number" id="count5">0</div>
            </div>
            <div class="stat-icon purple">
                <i class="fa fa-line-chart"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>今日收益</h3>
                <div class="stat-number" id="count15" style="color: #10b981;">0</div>
            </div>
            <div class="stat-icon green">
                <i class="fa fa-money"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>昨日收益</h3>
                <div class="stat-number" id="count16">0</div>
            </div>
            <div class="stat-icon pink">
                <i class="fa fa-history"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>今日访问量</h3>
                <div class="stat-number" id="visit_today" style="color: #06b6d4;">0</div>
            </div>
            <div class="stat-icon cyan">
                <i class="fa fa-eye"></i>
            </div>
        </div>

        <div class="stat-box">
            <div class="stat-info">
                <h3>独立访客</h3>
                <div class="stat-number" id="ip_today" style="color: #8b5cf6;">0</div>
            </div>
            <div class="stat-icon purple">
                <i class="fa fa-users"></i>
            </div>
        </div>
    </div>

    <!-- 主内容 -->
    <div class="main-content">
        
        <!-- 左侧面板 -->
        <div class="left-panel">
            
            <!-- 交易分析图表 -->
            <div class="chart-wrapper">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-area-chart"></i>
                        <span>一周交易数据分析</span>
                    </div>
                    <div class="chart-tabs">
                        <button class="tab-btn active" onclick="switchChart('mixed', this)">混合</button>
                        <button class="tab-btn" onclick="switchChart('line', this)">趋势</button>
                        <button class="tab-btn" onclick="switchChart('bar', this)">柱状</button>
                    </div>
                </div>
                
                <div id="mainChart" class="chart-box"></div>
                
                <!-- 支付统计 -->
                <div class="pay-stats">
                    <div class="pay-item">
                        <div class="pay-icon" style="color: #12b7f5;">
                            <i class="fa fa-qq"></i>
                        </div>
                        <div class="pay-value" id="count12">0</div>
                        <div style="font-size: 12px; color: #64748b; margin-top: 4px;">QQ钱包</div>
                    </div>
                    <div class="pay-item">
                        <div class="pay-icon" style="color: #07c160;">
                            <i class="fa fa-weixin"></i>
                        </div>
                        <div class="pay-value" id="count13">0</div>
                        <div style="font-size: 12px; color: #64748b; margin-top: 4px;">微信支付</div>
                    </div>
                    <div class="pay-item">
                        <div class="pay-icon" style="color: #1677ff;">
                            <i class="fa fa-credit-card"></i>
                        </div>
                        <div class="pay-value" id="count14">0</div>
                        <div style="font-size: 12px; color: #64748b; margin-top: 4px;">支付宝</div>
                    </div>
                </div>
            </div>

            <!-- 一周访问统计 -->
            <div class="visit-chart-wrapper" id="visitChartContainer" style="display: none;">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fa fa-line-chart" style="color: #10b981;"></i>
                        <span>一周访问统计</span>
                    </div>
                    <button class="btn btn-primary btn-sm" onclick="$('#visitDetailModal').modal('show')" style="background: #3b82f6; border: none; border-radius: 6px; padding: 8px 16px;">
                        <i class="fa fa-eye"></i> 详细查看
                    </button>
                </div>
                <div id="visitChart" class="visit-chart-box"></div>
            </div>

        </div>

        <!-- 右侧面板 -->
        <div class="right-panel">
            
            <!-- 系统信息（完全保持原样，显示版本号） -->
            <div class="side-card">
                <div class="side-title">
                    <i class="fa fa-server"></i>
                    <span>系统信息</span>
                </div>
                <div class="info-list">
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-cube"></i> 系统名称</span>
                        <span class="info-value">DSFAKA系统</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-qq"></i> 客服QQ</span>
                        <span class="info-value">525659559</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-users"></i> 官方网站</span>
                        <a href="http://wvwv.7cvv.cn" target="_blank" style="color: #3b82f6; text-decoration: none; font-weight: 600; font-size: 13px;">
                            点击进入 <i class="fa fa-external-link" style="font-size: 10px;"></i>
                        </a>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-code"></i> PHP版本</span>
                        <span class="info-value"><?php echo phpversion(); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-database"></i> MySQL</span>
                        <span class="info-value"><?php echo $mysqlversion; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-globe"></i> 服务器</span>
                        <span class="info-value" style="font-size: 11px; max-width: 140px; overflow: hidden; text-overflow: ellipsis;">
                            <?php echo $_SERVER['SERVER_SOFTWARE']; ?>
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><i class="fa fa-clock-o"></i> 时间</span>
                        <span class="info-value" id="serverTime"><?php echo date('H:i:s'); ?></span>
                    </div>
                </div>
            </div>

            <!-- 分站统计 -->
            <div class="side-card">
                <div class="side-title">
                    <i class="fa fa-sitemap"></i>
                    <span>分站统计</span>
                </div>
                <div class="sub-grid">
                    <div class="sub-box">
                        <div class="sub-icon" style="color: #3b82f6;"><i class="fa fa-users"></i></div>
                        <div class="sub-num" id="count6">0</div>
                        <div class="sub-text">分站/用户</div>
                    </div>
                    <div class="sub-box">
                        <div class="sub-icon" style="color: #10b981;"><i class="fa fa-plus-circle"></i></div>
                        <div class="sub-num" id="count7">0</div>
                        <div class="sub-text">今日新开</div>
                    </div>
                    <div class="sub-box">
                        <div class="sub-icon" style="color: #f97316;"><i class="fa fa-percent"></i></div>
                        <div class="sub-num" id="count8">0</div>
                        <div class="sub-text">今日提成</div>
                    </div>
                    <div class="sub-box" onclick="location.href='tixian.php'">
                        <div class="sub-icon" style="color: #ef4444;"><i class="fa fa-exchange"></i></div>
                        <div class="sub-num" id="count11" style="color: #ef4444;">0</div>
                        <div class="sub-text">待处理提现</div>
                    </div>
                </div>
            </div>

            <!-- 安全中心 -->
            <div class="side-card">
                <div class="side-title">
                    <i class="fa fa-shield"></i>
                    <span>安全中心</span>
                </div>
                <div id="secList">
                    <div class="sec-item warning" id="updatemsg">
                        <i class="fa fa-refresh fa-spin"></i>
                        <span>正在检查更新...</span>
                    </div>
                    <?php foreach ($sec_msg as $row) { echo $row; } ?>
                    <?php if (count($sec_msg) == 0) { ?>
                    <div class="sec-item success">
                        <i class="fa fa-check-circle"></i>
                        <span>暂未发现安全问题</span>
                    </div>
                    <?php } ?>
                </div>
            </div>

            <!-- 工单提醒 -->
            <div class="work-box" onclick="location.href='workorder.php'">
                <div class="work-label">
                    <i class="fa fa-bell-o" style="margin-right: 4px;"></i> 待处理工单
                </div>
                <div class="work-num" id="count17">0</div>
                <div style="font-size: 13px; color: #ef4444; font-weight: 600;">
                    点击查看详情 <i class="fa fa-arrow-right" style="margin-left: 4px;"></i>
                </div>
            </div>

        </div>
    </div>

</div>

<script>
var mainPlot = null;
var visitPlot = null;
var globalData = {};

$(document).ready(function() {
    loadAllData();
    setInterval(updateServerTime, 1000);
});

function updateServerTime() {
    var now = new Date();
    var timeStr = now.getHours().toString().padStart(2, '0') + ':' + 
                  now.getMinutes().toString().padStart(2, '0') + ':' + 
                  now.getSeconds().toString().padStart(2, '0');
    $('#serverTime').text(timeStr);
}

function loadAllData() {
    $('#count1, #count3, #count4, #count5, #count6, #count7, #count8, #count11, #count12, #count13, #count14, #count15, #count16, #count17, #visit_today, #ip_today').text('加载中...');
    
    $.ajax({
        type: "GET",
        url: "ajax.php?act=getcount",
        dataType: 'json',
        timeout: 15000,
        success: function(data) {
            globalData = data;
            
            animateValue('count1', data.count1 || 0);
            animateValue('count3', data.count3 || 0);
            animateValue('count4', data.count4 || 0);
            animateValue('count5', data.count5 || 0);
            animateValue('count6', data.count6 || 0);
            animateValue('count7', data.count7 || 0);
            animateValue('count8', data.count8 || 0);
            animateValue('count11', data.count11 || 0);
            animateValue('count12', data.count12 || 0);
            animateValue('count13', data.count13 || 0);
            animateValue('count14', data.count14 || 0);
            animateValue('count15', data.count15 || 0);
            animateValue('count16', data.count16 || 0);
            animateValue('count17', data.count17 || 0);
            
            if(data.visit_today !== undefined) {
                animateValue('visit_today', data.visit_today);
                animateValue('ip_today', data.ip_today);
            } else {
                $('#visit_today').text('0');
                $('#ip_today').text('0');
            }
            
            setTimeout(function() {
                initMainChart(data);
                if(data.visit_chart && data.visit_chart.visits && data.visit_chart.visits.length > 0) {
                    $('#visitChartContainer').show();
                    initVisitChart(data);
                } else {
                    $('#visitChartContainer').hide();
                }
            }, 300);
        },
        error: function() {
            setTimeout(loadAllData, 3000);
        }
    });
    
    checkUpdate();
}

function animateValue(id, value) {
    var $el = $('#' + id);
    var current = 0;
    var increment = Math.ceil(value / 20);
    var timer = setInterval(function() {
        current += increment;
        if (current >= value) {
            current = value;
            clearInterval(timer);
        }
        $el.text(current);
    }, 30);
}

function checkUpdate() {
    $('#updatemsg').html('<i class="fa fa-refresh fa-spin"></i><span>正在检查更新...</span>');
    
    $.ajax({
        type: "POST",
        url: "index.php",
        data: {'SF_Action':'check'},
        dataType: 'json',
        timeout: 10000,
        success: function(data) {
            var html = '';
            if(data.code == 0 && data.data && data.data.code == 1){
                html = '<div class="sec-item warning">' +
                       '<i class="fa fa-exclamation-circle"></i>' +
                       '<span>发现新版本 V'+data.data.data.edition+' <a href="update.php" style="color: #92400e; font-weight: 600;">立即更新</a></span>' +
                       '</div>';
            } else {
                html = '<div class="sec-item success">' +
                       '<i class="fa fa-check-circle"></i>' +
                       '<span>当前已是最新版本</span>' +
                       '</div>';
            }
            $('#secList').html(html);
        },
        error: function() {
            $('#secList').html('<div class="sec-item success">' +
                   '<i class="fa fa-check-circle"></i>' +
                   '<span>当前已是最新版本</span>' +
                   '</div>');
        }
    });
}

function initMainChart(data) {
    var container = $("#mainChart");
    if (container.length === 0 || !data.chart) {
        container.html('<div style="text-align: center; padding: 50px; color: #94a3b8;">暂无交易数据</div>');
        return;
    }
    
    var hasData = (data.chart.orders && data.chart.orders.length > 0) || 
                  (data.chart.money && data.chart.money.length > 0);
                  
    if (!hasData) {
        container.html('<div style="text-align: center; padding: 50px; color: #94a3b8;">暂无交易数据</div>');
        return;
    }
    
    if (container.width() === 0 || container.height() === 0) {
        setTimeout(function() { initMainChart(data); }, 200);
        return;
    }
    
    try {
        var options = {
            colors: ['#3b82f6', '#10b981'],
            series: {
                shadowSize: 0,
                lines: { show: true, fill: true, fillColor: { colors: [{ opacity: 0.2 }, { opacity: 0.05 }] }, lineWidth: 3 },
                points: { show: true, radius: 5, lineWidth: 2, fill: true, fillColor: "#ffffff" }
            },
            grid: { hoverable: true, clickable: true, borderWidth: 0, backgroundColor: 'transparent', margin: 10 },
            xaxis: { mode: "categories", tickLength: 0, font: { color: '#64748b', size: 11 } },
            yaxis: { font: { color: '#64748b', size: 11 } },
            legend: { show: true, position: "nw", backgroundOpacity: 0, margin: [-10, 0] },
            tooltip: true,
            tooltipOpts: {
                content: function(label, xval, yval) {
                    var unit = (label === '交易量') ? '¥' : '';
                    return label + "：" + unit + yval;
                },
                defaultTheme: false
            }
        };
        
        var chartData = [
            { label: "订单量", data: data.chart.orders || [] },
            { label: "交易量", data: data.chart.money || [], yaxis: 2 }
        ];
        
        mainPlot = $.plot(container, chartData, options);
    } catch(e) {
        container.html('<div style="text-align: center; padding: 50px; color: #ef4444;">图表加载失败</div>');
    }
}

function initVisitChart(data) {
    var container = $("#visitChart");
    if (container.length === 0 || !data.visit_chart) return;
    
    if (container.width() === 0 || container.height() === 0) {
        setTimeout(function() { initVisitChart(data); }, 200);
        return;
    }
    
    try {
        var options = {
            colors: ['#06b6d4', '#8b5cf6'],
            series: {
                shadowSize: 0,
                lines: { show: true, fill: true, fillColor: { colors: [{ opacity: 0.2 }, { opacity: 0.05 }] }, lineWidth: 3 },
                points: { show: true, radius: 4, lineWidth: 2, fill: true, fillColor: "#ffffff" }
            },
            grid: { hoverable: true, borderWidth: 0, backgroundColor: 'transparent' },
            xaxis: { mode: "categories", tickLength: 0, font: { color: '#64748b', size: 11 } },
            yaxis: { font: { color: '#64748b', size: 11 } },
            legend: { show: true, position: "nw", backgroundOpacity: 0 }
        };
        
        var visitData = [
            { label: "访问量", data: data.visit_chart.visits || [] },
            { label: "独立IP", data: data.visit_chart.ips || [] }
        ];
        
        visitPlot = $.plot(container, visitData, options);
    } catch(e) {}
}

function switchChart(type, btn) {
    $('.tab-btn').removeClass('active');
    $(btn).addClass('active');
    
    if (!mainPlot || !globalData.chart) return;
    
    var data = globalData.chart;
    var newData = [];
    
    if (type === 'mixed') {
        newData = [
            { label: "订单量", data: data.orders, lines: { show: true, fill: true, lineWidth: 3 }, points: { show: true, radius: 5 } },
            { label: "交易量", data: data.money, lines: { show: true, fill: true, lineWidth: 3 }, points: { show: true, radius: 5 }, yaxis: 2 }
        ];
    } else if (type === 'line') {
        newData = [
            { label: "订单量", data: data.orders, lines: { show: true, fill: false, lineWidth: 3 }, points: { show: true, radius: 6 } },
            { label: "交易量", data: data.money, lines: { show: true, fill: false, lineWidth: 3 }, points: { show: true, radius: 6 }, yaxis: 2 }
        ];
    } else if (type === 'bar') {
        newData = [
            { label: "订单量", data: data.orders, bars: { show: true, barWidth: 0.3, align: "center", fillColor: '#3b82f6' } },
            { label: "交易量", data: data.money, bars: { show: true, barWidth: 0.3, align: "center", fillColor: '#10b981' }, yaxis: 2 }
        ];
    }
    
    mainPlot.setData(newData);
    mainPlot.setupGrid();
    mainPlot.draw();
}

$('#visitDetailModal').on('show.bs.modal', function() {
    loadVisitDetails(1);
});

function loadVisitDetails(page) {
    $('#visitDetailLoading').show();
    $('#visitDetailContent').hide();
    $('#visitDetailEmpty').hide();
    
    $.ajax({
        url: 'ajax.php?act=get_visit_details',
        data: { page: page, pageSize: 15 },
        timeout: 10000,
        success: function(res) {
            $('#visitDetailLoading').hide();
            
            if (res.code === 0 && res.visits && res.visits.length > 0) {
                var html = '';
                $.each(res.visits, function(i, v) {
                    html += '<tr>' +
                        '<td><span style="background: #eff6ff; color: #3b82f6; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-family: monospace;">' + v.ip + '</span></td>' +
                        '<td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;" title="' + v.url + '">' + v.url + '</td>' +
                        '<td>' + v.region + '</td>' +
                        '<td>' + v.visit_time + '</td>' +
                        '<td style="font-weight: 600;">' + v.visits + '</td>' +
                        '<td style="font-size: 12px; color: #64748b;" class="text-break">' + v.user_agent + '</td>' +
                        '</tr>';
                });
                $('#visitDetailTable').html(html);
                $('#visitDetailContent').show();
                
                var totalPages = Math.ceil(res.total / 15);
                var phtml = '';
                for(var i=1; i<=totalPages; i++) {
                    phtml += '<li class="' + (i==page?'active':'') + '"><a href="#" onclick="loadVisitDetails(' + i + '); return false;">' + i + '</a></li>';
                }
                $('#visitDetailPagination').html(phtml);
            } else {
                $('#visitDetailEmpty').show();
            }
        },
        error: function() {
            $('#visitDetailLoading').hide();
            $('#visitDetailEmpty').html('<i class="fa fa-exclamation-triangle fa-2x" style="color: #ef4444; margin-bottom: 8px;"></i><br>加载失败').show();
        }
    });
}
</script>