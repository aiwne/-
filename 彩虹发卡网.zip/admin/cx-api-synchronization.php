<?php
/*
 * 自动同步API处理文件
 * 博客：www.7cvv.cn
 * QQ群：1011130040
 * 开发者：神秘人
 * 功能：处理商品自动同步的核心逻辑，包括分类同步、商品同步、数据更新等
 */
header("Content-Type: text/html;charset=utf-8");
include("../includes/common.php");

// 检查监控密钥
$monitor_key = $DB->getColumn("SELECT v FROM pre_config WHERE k='monitor_key'");
if($monitor_key && $_GET['key'] != $monitor_key) {
    exit('Access Denied');
}

// 设置同步任务开始时间
$DB->exec("REPLACE INTO pre_config SET k='last_sync_time',v='{$date}'");
echo "同步任务开始时间：{$date}<br/>";

// 模拟任务管理器功能
class SimpleTask {
    private $name;
    
    public function __construct($name) {
        $this->name = $name;
    }
    
    public function updateProgress($message) {
        echo $message . "<br/>";
    }
    
    public function checkTimeout() {
        // 简单实现，不做超时检查
    }
    
    public function cleanup() {
        // 简单实现，不做清理
    }
}

// 创建简单任务实例
$task = new SimpleTask('auto_sync');

try {
    // 获取所有启用的同步配置
    $configs = $DB->query("SELECT * FROM pre_sync_config WHERE status=1");
    $total_synced = 0;
    $total_updated = 0;
    $total_deleted = 0;
    
    while($row = $configs->fetch()) {
        $task->updateProgress("开始处理站点配置: ID=" . $row['shequ_id']);
        echo "开始处理站点配置: ID=" . $row['shequ_id'] . "<br/>";
        
        // 获取对接站点信息
        $shequ = $DB->getRow("SELECT * FROM pre_shequ WHERE id='" . $row['shequ_id'] . "'");
        if(!$shequ) {
            $task->updateProgress("跳过: 未找到站点信息 ID=" . $row['shequ_id']);
            echo "跳过: 未找到站点信息 ID=" . $row['shequ_id'] . "<br/>";
            continue;
        }
        
        // 检查插件是否存在
        $plugin_file = PLUGIN_ROOT . 'third_' . $shequ['type'] . '.php';
        if(!file_exists($plugin_file)) {
            $task->updateProgress("跳过: 插件文件不存在 {$plugin_file}");
            echo "跳过: 插件文件不存在 {$plugin_file}<br/>";
            continue;
        }
        
        // 同步分类
        if($row['sync_class'] || $row['add_class']) {
            $task->updateProgress("开始同步分类信息");
            echo "开始同步分类信息<br/>";
            syncCategories($shequ, $row, $task);
        }
        
        // 同步商品
        $synced_count = syncProducts($shequ, $row, $task);
        $total_synced += $synced_count['synced'];
        $total_updated += $synced_count['updated'];
        $total_deleted += $synced_count['deleted'];
        
        $task->updateProgress("站点同步完成: 新增{$synced_count['synced']}, 更新{$synced_count['updated']}, 删除{$synced_count['deleted']}");
        echo "站点同步完成: 新增{$synced_count['synced']}, 更新{$synced_count['updated']}, 删除{$synced_count['deleted']}<br/>";
    }
    
    $task->updateProgress("同步任务完成: 总计新增{$total_synced}, 更新{$total_updated}, 删除{$total_deleted}");
    echo "同步任务完成: 总计新增{$total_synced}, 更新{$total_updated}, 删除{$total_deleted}<br/>";
    echo "同步任务结束时间: " . date('Y-m-d H:i:s') . "<br/>";
    
} catch(Exception $e) {
    $task->updateProgress("同步任务异常: " . $e->getMessage());
    echo "同步任务异常: " . $e->getMessage() . "<br/>";
} finally {
    // 清理任务
    $task->cleanup();
    
    // 更新同步结束时间
    $DB->exec("REPLACE INTO pre_config SET k='last_sync_end_time',v='" . date('Y-m-d H:i:s') . "'");
}

/**
 * 同步分类信息
 */
function syncCategories($shequ, $config, $task) {
    global $DB, $date, $conf;
    
    try {
        // 使用 third_call 函数调用插件方法
        $categories = third_call($shequ['type'], $shequ, 'class_list');
        
        // 检查分类列表是否为数组
        if(!is_array($categories)) {
            $task->updateProgress("获取分类列表失败: {$categories}");
            echo "获取分类列表失败: {$categories}<br/>";
            return;
        }
        
        if(empty($categories)) {
            $task->updateProgress("未获取到分类数据");
            echo "未获取到分类数据<br/>";
            return;
        }
        
        $added = 0;
        $updated = 0;
        
        foreach($categories as $cat) {
            // 检查分类是否已存在
            $existing_cat = $DB->getRow("SELECT * FROM pre_class WHERE `name`=? AND shequ_id=?", [$cat['name'], $shequ['id']]);
            
            $data = [
                'name' => $cat['name'],
                'shequ_id' => $shequ['id'],
                'sort' => $cat['sort'] ?? 0,
                'addtime' => $existing_cat ? $existing_cat['addtime'] : $date,
                'uptime' => $date
            ];
            
            if($existing_cat) {
                // 更新分类
                if($config['sync_sort'] && $existing_cat['sort'] != $data['sort']) {
                    $DB->update('pre_class', $data, ['id' => $existing_cat['id']]);
                    $updated++;
                }
            } elseif($config['add_class']) {
                // 新增分类
                $data['fid'] = 0;
                $data['status'] = 1;
                $DB->insert('pre_class', $data);
                $added++;
            }
        }
        
        $task->updateProgress("分类同步完成: 新增{$added}, 更新{$updated}");
        echo "分类同步完成: 新增{$added}, 更新{$updated}<br/>";
        
    } catch(Exception $e) {
        $task->updateProgress("分类同步失败: " . $e->getMessage());
        echo "分类同步失败: " . $e->getMessage() . "<br/>";
    }
}

/**
 * 同步商品信息
 */
function syncProducts($shequ, $config, $task) {
    global $DB, $date, $conf;
    
    $synced = 0;
    $updated = 0;
    $deleted = 0;
    
    try {
        // 使用 third_call 函数调用插件方法获取商品列表
        $products = third_call($shequ['type'], $shequ, 'goods_list');
        
        // 检查商品列表是否为数组
        if(!is_array($products)) {
            $task->updateProgress("获取商品列表失败: {$products}");
            echo "获取商品列表失败: {$products}<br/>";
            return ['synced' => 0, 'updated' => 0, 'deleted' => 0];
        }
        
        if(empty($products)) {
            $task->updateProgress("未获取到商品数据");
            echo "未获取到商品数据<br/>";
            return ['synced' => 0, 'updated' => 0, 'deleted' => 0];
        }
        
        $shequ_product_ids = [];
        
        foreach($products as $product) {
            // 检查任务超时
            $task->checkTimeout();
            
            $shequ_product_ids[] = $product['id'];
            // 使用 pre_tools 表而非 pre_goods 表
            $existing_product = $DB->getRow("SELECT * FROM pre_tools WHERE is_curl=2 AND shequ=? AND goods_id=?", [$shequ['id'], $product['id']]);
            
            if(!$existing_product) {
                continue;
            }
            
            // 构建商品数据
            $price = $product['price'];
            
            // 如果需要同步价格，调用goods_info获取完整信息
            if($config['sync_price']) {
                $product_detail = third_call($shequ['type'], $shequ, 'goods_info', [$product['id']]);
                if(is_array($product_detail) && isset($product_detail['price'])) {
                    $price = $product_detail['price'];
                }
            }
            
            // 处理加价模板
            if($config['markup_template']) {
                $markup_template = $DB->getRow("SELECT * FROM pre_price WHERE id=?", [$config['markup_template']]);
                if($markup_template) {
                    $price = calculateMarkupPrice($price, $markup_template);
                }
            }
            
            // 检查是否有自定义价格记录
            $has_custom_price = $DB->getColumn("SELECT COUNT(*) FROM pre_site_price WHERE tid='{$existing_product['tid']}'");
            
            // 构建更新数据
            $update_data = [
                'close' => $product['close'],
                'stock' => $product['stock'] ?? 9999,
                'uptime' => $date
            ];
            
            // 只有当勾选了价格同步选项时才同步价格
            if($config['sync_price']) {
                $update_data['price'] = $price;
            }
            
            // 同步商品名称
            if($config['sync_name'] && isset($product['name'])) {
                $update_data['name'] = $product['name'];
            }
            
            // 同步商品图片
            if($config['sync_image'] && isset($product['shopimg']) && !empty($product['shopimg'])) {
                $update_data['shopimg'] = $product['shopimg'];
            }
            
            // 同步商品简介
            if($config['sync_desc']) {
                // 调用 goods_info 方法获取商品详情，包括简介
                $product_info = third_call($shequ['type'], $shequ, 'goods_info', [$product['id']]);
                if(is_array($product_info)) {
                    // 检查商品详情中是否有 desc 或 content 字段
                    $desc_content = '';
                    if(isset($product_info['desc'])) {
                        $desc_content = $product_info['desc'];
                    } elseif(isset($product_info['content'])) {
                        $desc_content = $product_info['content'];
                    } elseif(isset($product_info['info'])) {
                        $desc_content = $product_info['info'];
                    } elseif(isset($product_info['description'])) {
                        $desc_content = $product_info['description'];
                    }
                    
                    if(!empty($desc_content)) {
                        $update_data['desc'] = $desc_content;
                    }
                }
            }
            
            // 更新商品价格
            if($config['sync_price']) {
                if($has_custom_price > 0) {
                    // 更新自定义价格表 - 使用参数化查询防止SQL注入
                    $DB->exec("UPDATE pre_site_price SET price = ?, update_time = NOW() WHERE tid = ?", [$price, $existing_product['tid']]);
                }
            }
            
            // 更新商品信息
            // 确保 update_data 数组不为空
            if(!empty($update_data)) {
                // 构建SQL更新语句
                $set_clause = [];
                $params = [];
                foreach($update_data as $field => $value) {
                    $set_clause[] = "`{$field}` = ?";
                    $params[] = $value;
                }
                $params[] = $existing_product['tid'];
                
                $sql = "UPDATE pre_tools SET " . implode(', ', $set_clause) . " WHERE tid = ?";
                
                // 执行SQL更新
                $stmt = $DB->query($sql, $params);
                if($stmt !== false) {
                    $rowCount = $stmt->rowCount();
                    
                    // 只有当实际更新了数据时，才增加更新计数
                    if($rowCount > 0) {
                        $updated++;
                    }
                }
            }
            
            $task->updateProgress("更新商品: {$product['name']}");
        }
        
        // 处理下架商品
        if($config['delete_rule'] > 0) {
            $deleted_count = handleDeletedProducts($shequ['id'], $shequ_product_ids, $config['delete_rule'], $task);
            $deleted += $deleted_count;
        }
        
    } catch(Exception $e) {
        $task->updateProgress("商品同步失败: " . $e->getMessage());
        echo "商品同步失败: " . $e->getMessage() . "<br/>";
    }
    
    return ['synced' => $synced, 'updated' => $updated, 'deleted' => $deleted];
}

/**
 * 处理下架商品
 */
function handleDeletedProducts($shequ_id, $active_product_ids, $delete_rule, $task) {
    global $DB, $date;
    
    $count = 0;
    // 使用 pre_tools 表而非 pre_goods 表
    $query = "SELECT tid, name FROM pre_tools WHERE is_curl=2 AND shequ=? AND active=1";
    $params = [$shequ_id];
    
    if(!empty($active_product_ids)) {
        // 使用参数化查询处理IN子句，防止SQL注入
        $placeholders = implode(',', array_fill(0, count($active_product_ids), '?'));
        $query .= " AND goods_id NOT IN ({$placeholders})";
        $params = array_merge($params, $active_product_ids);
    }
    
    $products = $DB->query($query, $params);
    
    while($product = $products->fetch()) {
        if($delete_rule == 1) {
            // 下架商品
            $DB->update('pre_tools', ['close' => 1, 'uptime' => $date], ['tid' => $product['tid']]);
            $task->updateProgress("下架商品: {$product['name']}");
        } elseif($delete_rule == 2) {
            // 删除商品
            $DB->delete('pre_tools', ['tid' => $product['tid']]);
            $task->updateProgress("删除商品: {$product['name']}");
        }
        $count++;
    }
    
    return $count;
}

/**
 * 根据加价模板计算价格
 */
function calculateMarkupPrice($base_price, $markup_template) {
    $price = $base_price;
    
    if($markup_template['type'] == 1) {
        // 固定金额加价
        $price += $markup_template['value'];
    } elseif($markup_template['type'] == 2) {
        // 百分比加价
        $price = $price * (1 + $markup_template['value'] / 100);
    }
    
    // 价格精度处理
    $price = round($price, 2);
    
    return $price;
}

/**
 * 保存远程图片到本地
 */
function saveRemoteImage($url) {
    try {
        $img_dir = SYS_ROOT . 'assets/upload/image/';
        $img_url = $conf['local'] . 'assets/upload/image/';
        
        // 创建目录
        if(!is_dir($img_dir)) {
            mkdir($img_dir, 0755, true);
        }
        
        // 获取文件名和扩展名
        $path_info = pathinfo($url);
        $ext = isset($path_info['extension']) ? '.' . $path_info['extension'] : '.jpg';
        $filename = md5($url . time()) . $ext;
        $filepath = $img_dir . $filename;
        $fileurl = $img_url . $filename;
        
        // 下载图片
        $img_data = @file_get_contents($url);
        if($img_data) {
            @file_put_contents($filepath, $img_data);
            if(file_exists($filepath)) {
                return $fileurl;
            }
        }
        
        return false;
    } catch(Exception $e) {
        return false;
    }
}
?>