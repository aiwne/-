<?php
session_start();
$error = '';
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
// 检查是否已初始化配置（通过配置文件是否存在判断）
if (!file_exists('config.php')) {
    header('Location: install.php');
    exit();
}
// 修复：先检查db_connect.php文件是否存在，不存在则跳转到安装页面
if (!file_exists('db_connect.php')) {
    $_SESSION['error'] = '数据库连接文件缺失，请重新完成安装';
    header('Location: install.php');
    exit();
}
// 引入数据库连接文件
require_once 'db_connect.php';

// 获取网站设置
$websiteSettings = [
    'site_title' => '卡密验证系统',
    'site_logo_url' => '',
    'warm_reminder_title' => '温馨提示！',
    'warm_reminder_content' => '请保管好卡密内容，确保保存妥当，在此感谢你的关顾[爱心]',
    'warm_reminder_date' => date('Y-m-d'),
    'footer_text' => '© 2025 卡密验证系统 - by Lucky 版权所有 1.0',
    'verify_page_title' => '卡密验证',
    'verify_page_subtitle' => '请输入您的卡密进行验证'
];

// 初始化公告变量
$announcementContent = '暂无公告';
$announcementTime = '2025-9-10';

try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 从数据库读取网站设置
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        'site_title', 'site_logo_url', 'warm_reminder_title', 'warm_reminder_content',
        'warm_reminder_date', 'footer_text', 'verify_page_title', 'verify_page_subtitle'
    ]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($rows as $row) {
        if (isset($websiteSettings[$row['setting_key']])) {
            $websiteSettings[$row['setting_key']] = $row['setting_value'];
        }
    }
    
    // 查询最新公告
    $stmt = $pdo->query("SELECT content, updated_at FROM announcements ORDER BY updated_at DESC LIMIT 1");
    $announcement = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($announcement) {
        $announcementContent = $announcement['content']; // 不转义HTML，支持富文本显示
        $announcementTime = htmlspecialchars($announcement['updated_at']);
    }
} catch(PDOException $e) {
    // 数据库错误时保持默认设置和公告
    error_log("读取网站设置失败：" . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($websiteSettings['verify_page_title']); ?> - <?php echo htmlspecialchars($websiteSettings['site_title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/common.css" rel="stylesheet">
    <style>
        /* 超现代化富文本公告样式 */
        .announcement-content {
            line-height: 1.8;
            color: #2d3748;
            font-size: 15px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        
        .announcement-content p {
            margin: 12px 0;
            color: #4a5568;
            font-weight: 400;
        }
        
        .announcement-content h1, .announcement-content h2, .announcement-content h3, 
        .announcement-content h4, .announcement-content h5, .announcement-content h6 {
            margin: 20px 0 12px 0;
            font-weight: 700;
            color: #1a202c;
            letter-spacing: -0.025em;
        }
        
        .announcement-content h1 { 
            font-size: 1.4em; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .announcement-content h2 { font-size: 1.25em; color: #2d3748; }
        .announcement-content h3 { font-size: 1.15em; color: #2d3748; }
        
        .announcement-content strong {
            font-weight: 700;
            color: #1a202c;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .announcement-content em {
            font-style: italic;
            color: #718096;
            font-weight: 500;
        }
        
        .announcement-content u {
            text-decoration: underline;
            text-decoration-color: #667eea;
            text-decoration-thickness: 2px;
        }
        
        .announcement-content s {
            text-decoration: line-through;
            color: #a0aec0;
        }
        
        /* 行内代码样式 - 超现代化设计 */
        .announcement-content code {
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            color: #e53e3e;
            padding: 4px 8px;
            border-radius: 8px;
            font-family: 'JetBrains Mono', 'Fira Code', 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
            font-size: 0.9em;
            font-weight: 600;
            border: 1px solid #e2e8f0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        
        .announcement-content code::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 8px;
            z-index: -1;
        }
        
        /* 代码块样式 - 超专业代码编辑器风格 */
        .announcement-content pre {
            background: linear-gradient(135deg, #1a202c 0%, #2d3748 50%, #1a202c 100%);
            color: #e2e8f0;
            padding: 20px;
            border-radius: 16px;
            margin: 16px 0;
            overflow-x: auto;
            font-family: 'JetBrains Mono', 'Fira Code', 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace;
            font-size: 0.9em;
            line-height: 1.7;
            border: 1px solid #4a5568;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2), 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        
        .announcement-content pre::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 50px;
            background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
            border-radius: 16px 16px 0 0;
            border-bottom: 1px solid #4a5568;
        }
        
        .announcement-content pre::after {
            content: '● ● ●';
            position: absolute;
            top: 15px;
            left: 20px;
            color: #fc8181;
            font-size: 14px;
            letter-spacing: 6px;
            font-weight: bold;
        }
        
        .announcement-content pre code {
            background: none;
            color: inherit;
            padding: 0;
            border-radius: 0;
            border: none;
            box-shadow: none;
            display: block;
            margin-top: 25px;
            font-weight: 400;
        }
        
        /* 引用样式 - 超现代化设计 */
        .announcement-content blockquote {
            border-left: 5px solid #667eea;
            padding: 20px 24px;
            margin: 20px 0;
            color: #4a5568;
            font-style: italic;
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border-radius: 0 16px 16px 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        
        .announcement-content blockquote::before {
            content: '"';
            position: absolute;
            top: -10px;
            left: 16px;
            font-size: 3em;
            color: #667eea;
            font-weight: bold;
            opacity: 0.3;
        }
        
        .announcement-content blockquote::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            border-radius: 0 16px 16px 0;
            z-index: -1;
        }
        
        /* 链接样式 */
        .announcement-content a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .announcement-content a:hover {
            color: #5a67d8;
            border-bottom-color: #5a67d8;
            transform: translateY(-1px);
        }
        
        /* 列表样式 */
        .announcement-content ul, .announcement-content ol {
            margin: 16px 0;
            padding-left: 28px;
        }
        
        .announcement-content li {
            margin: 8px 0;
            color: #4a5568;
            font-weight: 400;
        }
        
        .announcement-content ul li {
            list-style-type: none;
            position: relative;
        }
        
        .announcement-content ul li::before {
            content: '▶';
            color: #667eea;
            font-weight: bold;
            position: absolute;
            left: -20px;
            font-size: 0.8em;
        }
        
        .announcement-content ol li {
            color: #4a5568;
            font-weight: 400;
        }
        
        /* 分割线样式 */
        .announcement-content hr {
            border: none;
            height: 3px;
            background: linear-gradient(90deg, transparent 0%, #e2e8f0 25%, #667eea 50%, #e2e8f0 75%, transparent 100%);
            margin: 24px 0;
            border-radius: 2px;
        }
        
        /* 确保富文本内容正确显示 */
        .announcement-content * {
            max-width: 100%;
        }
        
        /* 滚动条样式 */
        .announcement-content::-webkit-scrollbar {
            width: 8px;
        }
        
        .announcement-content::-webkit-scrollbar-track {
            background: #f7fafc;
            border-radius: 4px;
        }
        
        .announcement-content::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 4px;
        }
        
        .announcement-content::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        }
        
        /* 响应式调整 */
        @media (max-width: 640px) {
            .announcement-content {
                font-size: 14px;
            }
            
            .announcement-content pre {
                font-size: 0.85em;
                padding: 16px;
            }
            
            .announcement-content code {
                font-size: 0.85em;
                padding: 3px 6px;
            }
            
            .announcement-content blockquote {
                padding: 16px 20px;
            }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <div class="text-center mb-6">
            <h1 class="text-3xl font-bold text-gray-800"><?php echo htmlspecialchars($websiteSettings['verify_page_title']); ?></h1>
            <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($websiteSettings['verify_page_subtitle']); ?></p>
        </div>
        
        <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <i class="fa fa-exclamation-circle mr-2"></i><?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <form action="verify.php" method="post" class="space-y-4" data-validate id="verifyForm">
            <div>
                <label for="card_code" class="block text-gray-700 mb-2">卡密 <span class="text-red-500">*</span></label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                        <i class="fa fa-key"></i>
                    </span>
                    <input type="text" id="card_code" name="card_code" 
                           class="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 form-control"
                           placeholder="请输入卡密（如：D44U-P9V4-5H7B-2EQG）" required autocomplete="off" maxlength="100">
                </div>
                <p class="mt-1 text-xs text-gray-500">支持格式：D44U-P9V4-5H7B-2EQG、D44U P9V4 5H7B 2EQG、D44U.P9V4.5H7B.2EQG 等</p>
            </div>
            
            <button type="submit" id="submitBtn"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 flex items-center justify-center btn-effect">
                <i class="fa fa-check-circle mr-2"></i>验证卡密
            </button>
        </form>
        
        <div class="mt-8">
            <div class="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                <!-- 公告头部 -->
                <div class="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4">
                    <div class="flex items-center">
                        <div class="bg-white bg-opacity-20 p-2 rounded-xl mr-3">
                            <i class="fa fa-bullhorn text-white text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white">系统公告</h3>
                        </div>
                    </div>
                </div>
                
                <!-- 公告内容 -->
                <div class="p-6">
                    <div class="announcement-content">
                        <?php echo $announcementContent; ?>
                    </div>
                </div>
                
                <!-- 公告底部 -->
                <div class="bg-gray-50 px-6 py-4 border-t border-gray-100">
                    <div class="flex items-center justify-between text-sm text-gray-600">
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                            <span>发布时间：<?php echo $announcementTime; ?></span>
                        </div>
                        <div class="flex items-center">
                            <i class="fa fa-shield text-green-500 mr-1"></i>
                            <span class="text-green-600 font-medium">系统消息</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 页脚版权信息 -->
        <div class="mt-6 text-center text-sm text-gray-500">
            <p><?php echo htmlspecialchars($websiteSettings['footer_text']); ?></p>
        </div>
    </div>
    
    <!-- 引入通用JavaScript -->
    <script src="assets/js/common.js"></script>
    
    <!-- 页面特定JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('verifyForm');
            const submitBtn = document.getElementById('submitBtn');
            const cardInput = document.getElementById('card_code');
            
            // 表单提交处理
            form.addEventListener('submit', function(e) {
                let cardCode = cardInput.value.trim();
                
                if (!cardCode) {
                    e.preventDefault();
                    showNotification('请输入卡密代码', 'error');
                    cardInput.focus();
                    return false;
                }
                
                // 保持卡密原始格式，不进行清理
                // cardCode = cleanCardCode(cardCode);
                
                // 保持输入框中的原始值
                // cardInput.value = cardCode;
                
                // 禁用提交按钮防止重复提交
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>验证中...';
                
                // 如果3秒后还没跳转，恢复按钮状态
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fa fa-check-circle mr-2"></i>验证卡密';
                }, 3000);
            });
            
            // 输入框实时验证（保持原始格式）
            cardInput.addEventListener('input', function(e) {
                // 保持原始格式，不进行任何转换
                // e.target.value = e.target.value.toUpperCase();
            });
            
            // 自动聚焦到输入框
            cardInput.focus();
            
            // 卡密格式清理函数
            function cleanCardCode(cardCode) {
                // 移除所有非字母数字字符（包括空格、点、连字符等分隔符）
                return cardCode.replace(/[^A-Z0-9]/g, '');
            }
            
            // 显示通知函数
            function showNotification(message, type = 'info') {
                const notification = document.createElement('div');
                notification.className = `fixed top-4 right-4 z-50 p-4 rounded-md shadow-lg transition-all duration-300 transform translate-x-full`;
                
                const typeClasses = {
                    success: 'bg-green-500 text-white',
                    error: 'bg-red-500 text-white',
                    warning: 'bg-yellow-500 text-white',
                    info: 'bg-blue-500 text-white'
                };
                
                notification.className += ` ${typeClasses[type] || typeClasses.info}`;
                notification.innerHTML = `<i class="fa fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'} mr-2"></i>${message}`;
                
                document.body.appendChild(notification);
                
                // 显示动画
                setTimeout(() => {
                    notification.classList.remove('translate-x-full');
                }, 100);
                
                // 自动隐藏
                setTimeout(() => {
                    notification.classList.add('translate-x-full');
                    setTimeout(() => {
                        notification.remove();
                    }, 300);
                }, 3000);
            }
        });
    </script>
</body>
</html>