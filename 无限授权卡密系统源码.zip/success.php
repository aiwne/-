<?php
session_start();
// 检查是否有验证成功的内容
if (!isset($_SESSION['card_content'])) {
    header('Location: index.php');
    exit;
}

$content = $_SESSION['card_content'];
// 清除会话中的内容，防止刷新页面再次显示
unset($_SESSION['card_content']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>验证成功</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-xl p-8 w-full max-w-2xl">
        <div class="text-center mb-6">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-500 mb-4">
                <i class="fa fa-check text-3xl"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-800">验证成功</h1>
            <p class="text-gray-600 mt-2">您的卡密验证成功，以下是相关内容</p>
        </div>
        
        <div class="bg-gray-50 p-6 rounded-lg border border-gray-200 mb-6">
            <?php echo nl2br(htmlspecialchars($content)); ?>
        </div>
        
        <div class="text-center">
            <a href="index.php" 
               class="inline-flex items-center px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition duration-300">
                <i class="fa fa-home mr-2"></i>返回首页
            </a>
        </div>
    </div>
</body>
</html>
