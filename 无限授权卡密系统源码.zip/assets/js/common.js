/**
 * 通用JavaScript功能
 * 提供跨页面共享的交互功能
 */

// 防止重复初始化
if (window.commonJSInitialized) {
    console.log('通用JavaScript已初始化，跳过重复加载');
} else {
    window.commonJSInitialized = true;
    
    // 等待DOM加载完成
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
}

function init() {
    console.log('初始化通用JavaScript功能...');
    
    // 初始化侧边栏
    initSidebar();
    
    // 初始化通用事件
    initCommonEvents();
    
    // 初始化工具提示
    initTooltips();
    
    // 初始化表单验证
    initFormValidation();
    
    console.log('通用JavaScript功能初始化完成');
}

/**
 * 初始化侧边栏功能
 */
function initSidebar() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    
    if (!mobileMenuBtn || !sidebar || !sidebarOverlay) {
        console.warn('侧边栏元素未找到，跳过侧边栏初始化');
        return;
    }
    
    console.log('初始化侧边栏功能...');
    
    // 切换侧边栏显示状态
    function toggleSidebar(e) {
        e.preventDefault();
        e.stopPropagation();
        
        console.log('切换侧边栏状态');
        
        sidebar.classList.toggle('sidebar-visible');
        sidebar.classList.toggle('sidebar-hidden');
        sidebarOverlay.classList.toggle('active');
        document.body.classList.toggle('overflow-hidden');
        
        // 添加调试信息
        console.log('侧边栏状态:', {
            visible: sidebar.classList.contains('sidebar-visible'),
            hidden: sidebar.classList.contains('sidebar-hidden'),
            overlayActive: sidebarOverlay.classList.contains('active')
        });
    }
    
    // 移除可能存在的旧事件监听器
    mobileMenuBtn.removeEventListener('click', toggleSidebar);
    sidebarOverlay.removeEventListener('click', toggleSidebar);
    
    // 绑定事件
    mobileMenuBtn.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);
    
    // 确保移动端菜单按钮可见和可点击
    mobileMenuBtn.style.pointerEvents = 'auto';
    mobileMenuBtn.style.zIndex = '9999';
    
    // 窗口大小变化时自动调整
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) { // lg断点
            sidebar.classList.add('sidebar-visible');
            sidebar.classList.remove('sidebar-hidden');
            sidebarOverlay.classList.remove('active');
            document.body.classList.remove('overflow-hidden');
        } else if (!sidebar.classList.contains('sidebar-visible')) {
            sidebar.classList.add('sidebar-hidden');
        }
    });
    
    console.log('侧边栏功能初始化完成');
}

/**
 * 初始化通用事件
 */
function initCommonEvents() {
    // 确认删除对话框
    document.addEventListener('click', function(e) {
        const deleteLink = e.target.closest('.delete-confirm');
        if (deleteLink) {
            const message = deleteLink.getAttribute('data-confirm') || '确定要删除吗？此操作不可恢复！';
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        }
    });
    
    // 自动隐藏提示消息
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });
    
    // 复制到剪贴板功能
    document.addEventListener('click', function(e) {
        const copyBtn = e.target.closest('.copy-btn');
        if (copyBtn) {
            e.preventDefault();
            const text = copyBtn.getAttribute('data-copy') || copyBtn.textContent;
            copyToClipboard(text, copyBtn);
        }
    });
}

/**
 * 初始化工具提示
 */
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

/**
 * 显示工具提示
 */
function showTooltip(e) {
    const text = e.target.getAttribute('data-tooltip');
    if (!text) return;
    
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltiptext';
    tooltip.textContent = text;
    tooltip.id = 'tooltip-' + Date.now();
    
    e.target.classList.add('tooltip');
    e.target.appendChild(tooltip);
}

/**
 * 隐藏工具提示
 */
function hideTooltip(e) {
    const tooltip = e.target.querySelector('.tooltiptext');
    if (tooltip) {
        tooltip.remove();
    }
    e.target.classList.remove('tooltip');
}

/**
 * 初始化表单验证
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
                return false;
            }
        });
    });
}

/**
 * 验证表单
 */
function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, '此字段为必填项');
            isValid = false;
        } else {
            clearFieldError(field);
        }
    });
    
    // 验证邮箱
    const emailFields = form.querySelectorAll('input[type="email"]');
    emailFields.forEach(field => {
        if (field.value && !isValidEmail(field.value)) {
            showFieldError(field, '请输入有效的邮箱地址');
            isValid = false;
        }
    });
    
    // 验证密码
    const passwordFields = form.querySelectorAll('input[type="password"]');
    passwordFields.forEach(field => {
        if (field.value && field.value.length < 6) {
            showFieldError(field, '密码长度至少6位');
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * 显示字段错误
 */
function showFieldError(field, message) {
    clearFieldError(field);
    
    field.classList.add('error');
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error text-red-500 text-sm mt-1';
    errorDiv.textContent = message;
    
    field.parentNode.appendChild(errorDiv);
}

/**
 * 清除字段错误
 */
function clearFieldError(field) {
    field.classList.remove('error');
    
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

/**
 * 验证邮箱格式
 */
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

/**
 * 复制到剪贴板
 */
function copyToClipboard(text, button) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text)
            .then(() => {
                showCopySuccess(button);
            })
            .catch(err => {
                console.error('复制失败:', err);
                fallbackCopy(text, button);
            });
    } else {
        fallbackCopy(text, button);
    }
}

/**
 * 降级复制方法
 */
function fallbackCopy(text, button) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.top = '-999px';
    textarea.style.left = '-999px';
    document.body.appendChild(textarea);
    
    textarea.select();
    textarea.setSelectionRange(0, 99999);
    
    try {
        const successful = document.execCommand('copy');
        showCopySuccess(button, successful);
    } catch (err) {
        console.error('复制失败:', err);
        showCopyError(button);
    } finally {
        document.body.removeChild(textarea);
    }
}

/**
 * 显示复制成功提示
 */
function showCopySuccess(button, success = true) {
    if (!button) return;
    
    const originalHTML = button.innerHTML;
    const originalClasses = button.className;
    
    if (success) {
        button.innerHTML = '<i class="fa fa-check mr-1"></i>已复制';
        button.className = originalClasses.replace('bg-blue-600', 'bg-green-600');
    } else {
        button.innerHTML = '<i class="fa fa-times mr-1"></i>复制失败';
        button.className = originalClasses.replace('bg-blue-600', 'bg-red-600');
    }
    
    setTimeout(() => {
        button.innerHTML = originalHTML;
        button.className = originalClasses;
    }, 2000);
}

/**
 * 显示复制错误提示
 */
function showCopyError(button) {
    showCopySuccess(button, false);
}

/**
 * 显示通知消息
 */
function showNotification(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-md shadow-lg transition-all duration-300 transform translate-x-full`;
    
    const typeClasses = {
        success: 'bg-green-500 text-white',
        error: 'bg-red-500 text-white',
        warning: 'bg-yellow-500 text-white',
        info: 'bg-blue-500 text-white'
    };
    
    notification.className += ` ${typeClasses[type] || typeClasses.info}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // 显示动画
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // 自动隐藏
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, duration);
}

/**
 * 防抖函数
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * 节流函数
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// 导出常用函数到全局作用域
window.showNotification = showNotification;
window.copyToClipboard = copyToClipboard;
window.debounce = debounce;
window.throttle = throttle;
