// 后台管理页面交互脚本

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 侧边栏菜单激活状态
    const currentUrl = window.location.pathname.split('/').pop();
    const menuLinks = document.querySelectorAll('.sidebar-menu-link');
    
    menuLinks.forEach(link => {
        const linkUrl = link.getAttribute('href').split('/').pop();
        if (linkUrl === currentUrl) {
            link.classList.add('active');
        }
    });
    
    // 确认删除对话框
    const deleteForms = document.querySelectorAll('.delete-form');
    deleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const cardCode = this.getAttribute('data-card-code');
            if (!confirm(`确定要删除卡密 ${cardCode} 吗？此操作不可恢复！`)) {
                e.preventDefault();
                return false;
            }
        });
    });
    
    // 批量操作处理
    const batchActionForm = document.getElementById('batchActionForm');
    if (batchActionForm) {
        const batchActionSelect = document.getElementById('batchAction');
        const checkboxes = document.querySelectorAll('input[name="card_ids[]"]');
        
        batchActionForm.addEventListener('submit', function(e) {
            // 检查是否选择了操作
            if (!batchActionSelect.value) {
                alert('请选择要执行的操作');
                e.preventDefault();
                return false;
            }
            
            // 检查是否选择了卡密
            const selectedCount = document.querySelectorAll('input[name="card_ids[]"]:checked').length;
            if (selectedCount === 0) {
                alert('请至少选择一个卡密');
                e.preventDefault();
                return false;
            }
            
            // 确认删除操作
            if (batchActionSelect.value === 'delete' && 
                !confirm(`确定要删除选中的 ${selectedCount} 个卡密吗？此操作不可恢复！`)) {
                e.preventDefault();
                return false;
            }
            
            // 确认标记为已使用
            if (batchActionSelect.value === 'mark_used' && 
                !confirm(`确定要将选中的 ${selectedCount} 个卡密标记为已使用吗？`)) {
                e.preventDefault();
                return false;
            }
            
            // 确认标记为未使用
            if (batchActionSelect.value === 'mark_unused' && 
                !confirm(`确定要将选中的 ${selectedCount} 个卡密标记为未使用吗？`)) {
                e.preventDefault();
                return false;
            }
        });
        
        // 全选/取消全选
        const selectAll = document.getElementById('selectAll');
        if (selectAll) {
            selectAll.addEventListener('change', function() {
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        }
    }
    
    // 批量生成卡密表单处理
    const batchGenerateForm = document.getElementById('batchGenerateForm');
    if (batchGenerateForm) {
        batchGenerateForm.addEventListener('submit', function(e) {
            const countInput = document.getElementById('generateCount');
            const count = parseInt(countInput.value);
            
            // 验证数量
            if (isNaN(count) || count <= 0 || count > 1000) {
                alert('请输入1-1000之间的数字');
                e.preventDefault();
                countInput.focus();
                return false;
            }
            
            // 确认生成
            if (!confirm(`确定要生成 ${count} 个卡密吗？`)) {
                e.preventDefault();
                return false;
            }
            
            // 添加加载状态
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>生成中...';
        });
    }
    
    // 搜索表单提交
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', function() {
            const searchInput = document.getElementById('searchKeyword');
            // 如果搜索关键词为空，清除参数
            if (!searchInput.value.trim()) {
                const url = new URL(window.location);
                url.searchParams.delete('keyword');
                window.location = url.toString();
                return false;
            }
            return true;
        });
    }
    
    // 切换卡密状态
    const toggleStatusLinks = document.querySelectorAll('.toggle-status');
    toggleStatusLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const cardId = this.getAttribute('data-id');
            const currentStatus = this.getAttribute('data-status');
            const newStatus = currentStatus === '1' ? '0' : '1';
            const statusText = newStatus === '1' ? '已使用' : '未使用';
            
            if (!confirm(`确定要将此卡密状态改为${statusText}吗？`)) {
                e.preventDefault();
                return false;
            }
        });
    });
});
    