// 前台页面交互脚本

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 卡密验证表单处理
    const validationForm = document.getElementById('validationForm');
    if (validationForm) {
        validationForm.addEventListener('submit', function(e) {
            const cardInput = document.getElementById('cardCode');
            const errorMsg = document.getElementById('errorMessage');
            
            // 简单验证
            if (!cardInput.value.trim()) {
                e.preventDefault();
                showError(errorMsg, '请输入卡密');
                return false;
            }
            
            // 清除之前的错误
            hideError(errorMsg);
            
            // 添加加载状态
            const submitBtn = validationForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>验证中...';
            
            // 表单提交后会由PHP处理，这里只是添加加载状态
            return true;
        });
    }
    
    // 显示错误信息
    function showError(element, message) {
        element.textContent = message;
        element.classList.remove('hidden');
        element.classList.add('alert-danger');
        
        // 5秒后自动隐藏错误信息
        setTimeout(() => {
            hideError(element);
        }, 5000);
    }
    
    // 隐藏错误信息
    function hideError(element) {
        element.textContent = '';
        element.classList.add('hidden');
        element.classList.remove('alert-danger');
    }
    
    // 复制内容功能
    const copyBtn = document.getElementById('copyContentBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const contentElement = document.getElementById('cardContent');
            const textToCopy = contentElement.textContent;
            
            navigator.clipboard.writeText(textToCopy).then(() => {
                // 显示复制成功提示
                const originalText = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fa fa-check mr-2"></i>已复制';
                copyBtn.classList.remove('bg-blue-600');
                copyBtn.classList.add('bg-green-600');
                
                setTimeout(() => {
                    copyBtn.innerHTML = originalText;
                    copyBtn.classList.remove('bg-green-600');
                    copyBtn.classList.add('bg-blue-600');
                }, 2000);
            }).catch(err => {
                console.error('复制失败: ', err);
                alert('复制失败，请手动复制');
            });
        });
    }
});
    