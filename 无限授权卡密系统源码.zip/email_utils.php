<?php
/**
 * 邮件发送工具类（适配数据库配置）
 */
require 'vendor/PHPMailer/src/PHPMailer.php';
require 'vendor/PHPMailer/src/SMTP.php';
require 'vendor/PHPMailer/src/Exception.php';
require_once 'db_connect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class EmailUtils {
    private $config;
    private $db;

    /**
     * 构造函数，初始化配置和数据库连接
     */
    public function __construct() {
        // 从配置文件加载邮件设置（现在从数据库读取）
        $this->config = require 'config.php';
        $this->config = $this->config['email'];
        
        // 初始化数据库连接
        try {
            $this->db = Database::getInstance();
        } catch (Exception $e) {
            error_log("数据库连接初始化失败: " . $e->getMessage());
            $this->db = null;
        }
    }

    /**
     * 发送卡密使用通知邮件
     * @param string $to 接收邮件地址
     * @param array $cardInfo 卡密信息数组
     * @return array [是否成功, 错误信息/成功信息]
     */
    public function sendCardUsedNotification($to, $cardInfo) {
        $cardId = $cardInfo['card_id'] ?? '未知';
        error_log("发送卡密通知 - 卡密ID: $cardId, 卡密代码: " . ($cardInfo['card_code'] ?? '未知'));
        
        // 验证接收邮箱
        if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $error = "无效的接收邮件地址: $to";
            error_log("邮件错误: $error");
            return [false, $error];
        }

        // 初始化分类信息
        $categoryName = "未获取到分类";
        
        // 尝试多种方式获取分类名称
        if (!empty($cardInfo['category_id'])) {
            // 1. 优先使用直接提供的category_id
            $categoryName = $this->getCategoryNameById($cardInfo['category_id']);
        } elseif (!empty($cardInfo['card_id'])) {
            // 2. 若无category_id，通过card_id查询cards表获取category_id
            $categoryId = $this->getCategoryIdFromCard($cardInfo['card_id']);
            if ($categoryId) {
                $categoryName = $this->getCategoryNameById($categoryId);
            } else {
                error_log("卡密ID $cardId 未关联任何分类");
                $categoryName = "未关联分类";
            }
        }

        // 将分类信息添加到卡密信息中
        $cardInfo['category_name'] = $categoryName;

        // 初始化PHPMailer
        $mail = new PHPMailer(true);

        try {
            // 服务器配置 - 使用从数据库读取的配置
            $mail->isSMTP();                                           
            $mail->Host       = $this->config['smtp_host'];              
            $mail->SMTPAuth   = true;                                   
            $mail->Username   = $this->config['smtp_username'];          
            $mail->Password   = $this->config['smtp_password'];          
            
            // 设置加密方式
            if ($this->config['smtp_encryption'] === 'tls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($this->config['smtp_encryption'] === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = false;
            }
            
            $mail->Port       = $this->config['smtp_port'];              

            // 发件人设置
            $mail->setFrom($this->config['from_email'], $this->config['from_name']);
            $mail->addAddress($to);                                      
            $mail->addReplyTo($this->config['from_email'], '管理员回复');  

            // 邮件内容
            $mail->isHTML(true);                                         
            $mail->Subject = "卡密使用通知 - " . ($cardInfo['card_code'] ?? '未知卡密'); 
            
            $mail->Body    = $this->buildEmailContent($cardInfo);
            $mail->AltBody = $this->buildPlainTextContent($cardInfo);    

            // 发送邮件
            $result = $mail->send();
            
            if ($result) {
                $message = "邮件已成功发送至: $to";
                error_log("邮件成功: $message");
                return [true, $message];
            } else {
                $error = "邮件发送失败，未知错误";
                error_log("邮件错误: $error");
                return [false, $error];
            }
        } catch (Exception $e) {
            $error = "邮件发送失败: " . $mail->ErrorInfo . " (异常: " . $e->getMessage() . ")";
            error_log("邮件错误: $error");
            return [false, $error];
        }
    }

    /**
     * 从cards表通过卡密ID获取分类ID
     * @param int $cardId 卡密ID
     * @return int|bool 分类ID或false
     */
    private function getCategoryIdFromCard($cardId) {
        if (empty($cardId) || !is_numeric($cardId) || !$this->db) {
            return false;
        }

        try {
            $pdo = $this->db->getPdo();
            $stmt = $pdo->prepare("SELECT category_id FROM cards WHERE id = :card_id LIMIT 1");
            $stmt->bindParam(':card_id', $cardId, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 验证结果是否有效
            if ($result && isset($result['category_id']) && $result['category_id'] > 0) {
                return (int)$result['category_id'];
            }
            return false;
        } catch (PDOException $e) {
            error_log("从cards表查询分类ID失败: " . $e->getMessage() . " (卡密ID: $cardId)");
            return false;
        }
    }

    /**
     * 从categories表通过分类ID获取分类名称
     * @param int $categoryId 分类ID
     * @return string 分类名称
     */
    private function getCategoryNameById($categoryId) {
        // 验证分类ID有效性
        if (empty($categoryId) || !is_numeric($categoryId) || $categoryId < 1) {
            return "无效分类ID";
        }

        // 验证数据库连接
        if (!$this->db) {
            return "数据库连接失败";
        }

        try {
            $pdo = $this->db->getPdo();
            $stmt = $pdo->prepare("SELECT name FROM categories WHERE id = :category_id LIMIT 1");
            $stmt->bindParam(':category_id', $categoryId, PDO::PARAM_INT);
            $stmt->execute();
            
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 检查查询结果
            if ($category && !empty($category['name'])) {
                return trim($category['name']);
            }
            
            error_log("categories表中未找到ID为 $categoryId 的分类");
            return "分类不存在 (ID: $categoryId)";
        } catch (PDOException $e) {
            error_log("从categories表查询分类名称失败: " . $e->getMessage() . " (分类ID: $categoryId)");
            return "分类查询错误";
        }
    }

    /**
     * 构建HTML邮件内容
     */
    private function buildEmailContent($cardInfo) {
        $cardId = htmlspecialchars($cardInfo['card_id'] ?? '未知卡密ID');
        $cardCode = htmlspecialchars($cardInfo['card_code'] ?? '未知');
        $categoryName = htmlspecialchars($cardInfo['category_name'] ?? '未获取到分类');
        $usedAt = htmlspecialchars($cardInfo['used_at'] ?? '未知时间');
        $deviceInfo = htmlspecialchars($cardInfo['device_info'] ?? '未知设备');

        return '
        <html>
        <head>
            <title>卡密使用通知</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #f5f5f5; padding: 10px 20px; border-radius: 5px 5px 0 0; }
                .content { padding: 20px; border: 1px solid #eee; border-top: none; border-radius: 0 0 5px 5px; }
                .info-item { margin-bottom: 10px; }
                .label { font-weight: bold; display: inline-block; width: 100px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>卡密使用通知</h2>
                </div>
                <div class="content">
                    <p>您好，以下卡密已被使用：</p>
                    <div class="info-item">
                        <span class="label">卡密ID：</span>
                        <span>' . $cardId . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">卡密代码：</span>
                        <span>' . $cardCode . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">卡密分类：</span>
                        <span>' . $categoryName . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">使用时间：</span>
                        <span>' . $usedAt . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">使用设备：</span>
                        <span>' . $deviceInfo . '</span>
                    </div>
                    <p>如果这不是您本人操作，请及时检查账户安全。</p>
                </div>
            </div>
        </body>
        </html>
        ';
    }

    /**
     * 构建纯文本邮件内容（备用）
     */
    private function buildPlainTextContent($cardInfo) {
        $cardId = $cardInfo['card_id'] ?? '未知卡密ID';
        $cardCode = $cardInfo['card_code'] ?? '未知';
        $categoryName = $cardInfo['category_name'] ?? '未获取到分类';
        $usedAt = $cardInfo['used_at'] ?? '未知时间';
        $deviceInfo = $cardInfo['device_info'] ?? '未知设备';

        return "卡密使用通知\n\n" .
               "卡密ID：" . $cardId . "\n" .
               "卡密代码：" . $cardCode . "\n" .
               "卡密分类：" . $categoryName . "\n" .
               "使用时间：" . $usedAt . "\n" .
               "使用设备：" . $deviceInfo . "\n\n" .
               "如果这不是您本人操作，请及时检查账户安全。";
    }
}
?>
    