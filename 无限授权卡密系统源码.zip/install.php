<?php
// 初始化会话（用于保存安装步骤和配置）
session_start();
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
ini_set('display_errors', 1);

// 核心配置：安装锁定文件路径、步骤定义
define('INSTALL_LOCK', __DIR__ . '/install.lock');
define('LOG_DIR', __DIR__ . '/logs'); // 对应db_connect.php的日志目录
$steps = ['环境检测', '数据库配置', '创建数据表', '管理员设置', '邮件配置（可选）', '安装完成'];

// 1. 检查是否已安装（通过lock文件）
if (file_exists(INSTALL_LOCK)) {
    die('
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>已安装 - 卡密验证系统</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container mt-3 px-3">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">安装提示</h5>
                </div>
                <div class="card-body">
                    <p class="text-danger">系统已完成安装，禁止重复执行安装程序！</p>
                    <p>若需重新安装，请先删除根目录下的 <code>install.lock</code> 文件。</p>
                    <a href="index.php" class="btn btn-primary w-100">前往系统首页</a>
                </div>
            </div>
        </div>
    </body>
    </html>');
}

// 检查并创建config.php文件（若不存在）
$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    $configContent = <<<'PHP'
<?php
/**
 * 系统配置文件
 * 所有敏感配置集中管理
 */

// 引入数据库连接类（根据实际路径调整）
require_once __DIR__ . '/db_connect.php';

// 初始化空邮件配置
$emailConfig = [];

// 从数据库获取邮件配置
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT * FROM email_settings LIMIT 1");
    $dbConfig = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 若数据库有配置，使用数据库配置
    if ($dbConfig) {
        $emailConfig = $dbConfig;
    }
} catch (PDOException $e) {
    // 数据库查询失败时，使用空配置（可记录错误日志）
    error_log("获取邮件配置失败: " . $e->getMessage());
}

return [
    // 数据库配置（保持不变）
    'database' => [
        'host' => 'localhost',
        'dbname' => 'db_name',
        'username' => 'db_user',
        'password' => 'db_password',
        'charset' => 'utf8mb4'
    ],
    
    // 邮件配置（仅从数据库获取）
    'email' => $emailConfig,
    
    // 系统设置（保持不变）
    'system' => [
        'name' => '卡密验证系统',
        'version' => '1.0.0',
        'timezone' => 'Asia/Shanghai'
    ]
];
?>
PHP;
    // 写入配置文件并设置权限
    file_put_contents($configPath, $configContent);
    chmod($configPath, 0644);
}

// 2. 处理步骤提交逻辑
$currentStep = isset($_SESSION['step']) ? (int)$_SESSION['step'] : 0;
$error = '';
$success = '';

// 步骤1：环境检测提交（自动通过，仅展示结果）
if (isset($_POST['step1_submit'])) {
    $_SESSION['step'] = 1;
    header('Location: install.php');
    exit;
}

// 步骤2：数据库配置提交（测试连接并保存配置）
if (isset($_POST['step2_submit'])) {
    $dbConfig = [
        'host' => trim($_POST['db_host']),
        'name' => trim($_POST['db_name']),
        'user' => trim($_POST['db_user']),
        'pass' => trim($_POST['db_pass']),
        'charset' => 'utf8mb4'
    ];

    // 验证输入（数据库为核心配置，仍必填）
    if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['user'])) {
        $error = '数据库主机、数据库名、用户名不能为空！';
    } else {
        // 测试PDO连接（参考db_connect.php的连接逻辑）
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['name']};charset={$dbConfig['charset']}";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];

        try {
            $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], $options);
            $_SESSION['db_config'] = $dbConfig; // 保存数据库配置到会话

            // 检查并创建db_connect.php（核心修改点）
            $dbConnectPath = __DIR__ . '/db_connect.php';
            if (!file_exists($dbConnectPath)) {
                // 构造db_connect.php内容，使用用户输入的数据库配置作为默认值
                $dbConnectContent = <<<'PHP'
<?php
/**
 * 数据库连接类
 * 采用单例模式确保只有一个数据库连接实例
 * 支持环境变量配置，提高安全性
 */
class Database {
    // 单例实例
    private static $instance = null;
    // PDO对象
    private $pdo;
    
    // 私有构造函数，防止外部实例化
    private function __construct() {
        // 从环境变量获取配置（优先）或使用默认值
        $host = getenv('DB_HOST') ?: 'DEFAULT_HOST';
        $dbname = getenv('DB_NAME') ?: 'DEFAULT_NAME';
        $username = getenv('DB_USER') ?: 'DEFAULT_USER';
        $password = getenv('DB_PASS') ?: 'DEFAULT_PASS';
        $charset = 'utf8mb4'; // 支持emoji等特殊字符
        
        // DSN配置
        $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
        
        // 连接选项
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // 错误模式：抛出异常
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,      // 默认获取模式：关联数组
            PDO::ATTR_EMULATE_PREPARES   => false,                 // 禁用模拟预处理语句
            PDO::ATTR_PERSISTENT         => false,                 // 不使用持久连接
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES $charset"   // 初始化字符集
        ];
        
        try {
            // 创建PDO实例
            $this->pdo = new PDO($dsn, $username, $password, $options);
            
            // 设置连接超时（MySQL默认8小时，这里缩短为1小时）
            $this->pdo->exec("SET SESSION wait_timeout = 3600");
        } catch (PDOException $e) {
            // 记录错误日志（生产环境）
            $this->logError($e->getMessage());
            
            // 开发环境显示详细错误，生产环境显示友好提示
            if (getenv('APP_ENV') === 'development') {
                die("数据库连接失败: " . $e->getMessage());
            } else {
                die("服务暂时无法连接，请稍后再试");
            }
        }
    }
    
    // 防止克隆
    private function __clone() {}
    
    // 防止反序列化
    private function __wakeup() {}
    
    // 获取单例实例
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    // 获取PDO对象
    public function getPdo() {
        return $this->pdo;
    }
    
    // 执行查询并返回结果
    public function query($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            $this->logError($e->getMessage() . " | SQL: $sql");
            throw $e; // 重新抛出异常，让调用者处理
        }
    }
    
    // 记录错误日志
    private function logError($message) {
        $logDir = __DIR__ . '/logs';
        // 确保日志目录存在
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/db_errors_' . date('Y-m-d') . '.log';
        $logMessage = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
        
        // 写入日志
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
    
    // 关闭连接
    public function close() {
        self::$instance = null;
        $this->pdo = null;
    }
}

// 使用示例：
// $db = Database::getInstance();
// $pdo = $db->getPdo();
// 或者直接执行查询：
// $stmt = $db->query("SELECT * FROM cards WHERE id = ?", [$id]);
?>
PHP;

                // 替换默认配置为用户输入的值
                $dbConnectContent = str_replace(
                    ['DEFAULT_HOST', 'DEFAULT_NAME', 'DEFAULT_USER', 'DEFAULT_PASS'],
                    [$dbConfig['host'], $dbConfig['name'], $dbConfig['user'], $dbConfig['pass']],
                    $dbConnectContent
                );

                // 写入文件并设置权限
                file_put_contents($dbConnectPath, $dbConnectContent);
                chmod($dbConnectPath, 0644);
            }

            $_SESSION['step'] = 2;
            header('Location: install.php');
            exit;
        } catch (PDOException $e) {
            $error = "数据库连接失败：" . $e->getMessage();
        }
    }
}

// 步骤3：创建数据表（执行SQL，基于图片中的表结构，调整email_settings字段为非必填）
if (isset($_POST['step3_submit'])) {
    if (!isset($_SESSION['db_config'])) {
        $error = '请先完成数据库配置！';
    } else {
        $dbConfig = $_SESSION['db_config'];
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['name']};charset={$dbConfig['charset']}";
        $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

        try {
            $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], $options);
            // 数据表创建SQL（调整email_settings字段为允许NULL，适配可选配置）
            $sqls = [
                // admins表：管理员
                "CREATE TABLE IF NOT EXISTS `admins` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `username` varchar(50) NOT NULL,
                    `password` varchar(255) NOT NULL,
                    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `username` (`username`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // settings表：系统设置
                "CREATE TABLE IF NOT EXISTS `settings` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `setting_key` varchar(50) NOT NULL,
                    `setting_value` text,
                    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `setting_key` (`setting_key`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // announcements表：公告
                "CREATE TABLE IF NOT EXISTS `announcements` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `content` text NOT NULL,
                    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // categories表：卡密分类（先创建，供cards表关联）
                "CREATE TABLE IF NOT EXISTS `categories` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `name` varchar(50) NOT NULL,
                    `description` text,
                    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `name` (`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // cards表：卡密（关联categories表，支持使用次数和有效时间）
                "CREATE TABLE IF NOT EXISTS `cards` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `card_code` varchar(100) NOT NULL,
                    `content` text,
                    `max_uses` int(11) NOT NULL DEFAULT 1 COMMENT '最大使用次数',
                    `current_uses` int(11) NOT NULL DEFAULT 0 COMMENT '当前使用次数',
                    `valid_until` datetime NULL DEFAULT NULL COMMENT '有效期至',
                    `first_use_ip` varchar(45) NULL DEFAULT NULL COMMENT '首次使用IP',
                    `last_use_ip` varchar(45) NULL DEFAULT NULL COMMENT '最后使用IP',
                    `use_history` text NULL DEFAULT NULL COMMENT '使用历史记录(JSON格式)',
                    `is_used` tinyint(1) NOT NULL DEFAULT 0,
                    `used_at` timestamp NULL DEFAULT NULL,
                    `device_info` text,
                    `is_banned` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否被封禁',
                    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    `used` tinyint(1) NOT NULL DEFAULT 0,
                    `category_id` int(11) DEFAULT NULL,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `card_code` (`card_code`),
                    KEY `category_id` (`category_id`),
                    KEY `idx_valid_until` (`valid_until`),
                    KEY `idx_max_uses` (`max_uses`),
                    KEY `idx_current_uses` (`current_uses`),
                    KEY `idx_first_use_ip` (`first_use_ip`),
                    KEY `idx_is_banned` (`is_banned`),
                    CONSTRAINT `cards_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // email_settings表：邮件配置（关键字段改为允许NULL，适配可选配置）
                "CREATE TABLE IF NOT EXISTS `email_settings` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `smtp_host` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `smtp_port` int(11) DEFAULT NULL,      -- 改为可选（允许NULL）
                    `smtp_username` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `smtp_password` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `smtp_encryption` varchar(10) DEFAULT 'tls',
                    `from_email` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `from_name` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `admin_notify_email` varchar(255) DEFAULT NULL,  -- 改为可选（允许NULL）
                    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                // card_usage_logs表：卡密使用记录表（用于详细记录使用历史）
                "CREATE TABLE IF NOT EXISTS `card_usage_logs` (
                    `id` int(11) NOT NULL AUTO_INCREMENT,
                    `card_id` int(11) NOT NULL,
                    `use_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `use_ip` varchar(45) NOT NULL,
                    `device_info` text NULL,
                    `user_agent` text NULL,
                    PRIMARY KEY (`id`),
                    KEY `idx_card_id` (`card_id`),
                    KEY `idx_use_time` (`use_time`),
                    CONSTRAINT `fk_card_usage_logs_card_id` FOREIGN KEY (`card_id`) REFERENCES `cards` (`id`) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='卡密使用记录表';"
            ];

            // 执行所有SQL
            $createdTables = [];
            foreach ($sqls as $index => $sql) {
                try {
                    $pdo->exec($sql);
                    // 提取表名用于显示
                    if (preg_match('/CREATE TABLE.*?`(\w+)`/', $sql, $matches)) {
                        $createdTables[] = $matches[1];
                    }
                } catch (PDOException $e) {
                    throw new PDOException("创建数据表失败（第" . ($index + 1) . "个）：" . $e->getMessage());
                }
            }

            $success = '所有数据表创建成功！已创建：' . implode('、', $createdTables);
            $_SESSION['step'] = 3;
            header('Location: install.php');
            exit;
        } catch (PDOException $e) {
            $error = "创建数据表失败：" . $e->getMessage();
        }
    }
}

// 步骤4：管理员账号设置（插入初始管理员，核心配置仍必填）
if (isset($_POST['step4_submit'])) {
    if (!isset($_SESSION['db_config'])) {
        $error = '请先完成数据库配置！';
    } else {
        $adminUser = trim($_POST['admin_user']);
        $adminPwd = trim($_POST['admin_pwd']);
        $adminPwd2 = trim($_POST['admin_pwd2']);

        // 验证输入（管理员为核心配置，仍必填）
        if (empty($adminUser) || strlen($adminUser) < 3) {
            $error = '管理员用户名不能为空且长度至少3位！';
        } elseif (empty($adminPwd) || strlen($adminPwd) < 6) {
            $error = '管理员密码不能为空且长度至少6位！';
        } elseif ($adminPwd !== $adminPwd2) {
            $error = '两次输入的密码不一致！';
        } else {
            $dbConfig = $_SESSION['db_config'];
            $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['name']};charset={$dbConfig['charset']}";
            $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

            try {
                $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], $options);
                // 密码加密（PHP推荐方式）
                $hashedPwd = password_hash($adminPwd, PASSWORD_DEFAULT);
                // 插入初始管理员（避免重复插入）
                $stmt = $pdo->prepare("INSERT IGNORE INTO `admins` (`username`, `password`) VALUES (?, ?)");
                $stmt->execute([$adminUser, $hashedPwd]);

                $success = '管理员账号创建成功！';
                $_SESSION['admin_user'] = $adminUser; // 保存用户名用于后续提示
                $_SESSION['step'] = 4;
                header('Location: install.php');
                exit;
            } catch (PDOException $e) {
                $error = "创建管理员失败：" . $e->getMessage();
            }
        }
    }
}

// 步骤5：邮件配置提交（改为可选，支持跳过或部分填写）
if (isset($_POST['step5_submit']) || isset($_POST['step5_skip'])) {
    // 无论是否填写邮件，都可进入下一步（跳过逻辑）
    if (isset($_POST['step5_skip'])) {
        $_SESSION['email_config_status'] = '未配置';
        $_SESSION['step'] = 5;
        header('Location: install.php');
        exit;
    }

    // 若填写邮件，则验证必填逻辑（部分填写时需验证格式）
    $emailConfig = [
        'smtp_host' => trim($_POST['smtp_host']),
        'smtp_port' => empty($_POST['smtp_port']) ? null : (int)$_POST['smtp_port'],
        'smtp_user' => trim($_POST['smtp_user']),
        'smtp_pass' => trim($_POST['smtp_pass']),
        'smtp_enc' => trim($_POST['smtp_enc']) ?: 'tls',
        'from_email' => trim($_POST['from_email']),
        'from_name' => trim($_POST['from_name']),
        'admin_notify' => trim($_POST['admin_notify'])
    ];

    // 验证规则：若填写任一核心字段（SMTP主机/端口/发件邮箱），则需完整填写核心组
    $hasSmtpConfig = !empty($emailConfig['smtp_host']) || !empty($emailConfig['smtp_port']) || !empty($emailConfig['from_email']);
    if ($hasSmtpConfig) {
        if (empty($emailConfig['smtp_host'])) {
            $error = '已填写邮件相关配置，请补充SMTP主机！';
        } elseif (empty($emailConfig['smtp_port']) || !is_numeric($emailConfig['smtp_port'])) {
            $error = '已填写邮件相关配置，请补充有效的SMTP端口！';
        } elseif (empty($emailConfig['from_email']) || !filter_var($emailConfig['from_email'], FILTER_VALIDATE_EMAIL)) {
            $error = '已填写邮件相关配置，请补充有效的发件邮箱！';
        }
    }

    if (empty($error)) {
        $dbConfig = $_SESSION['db_config'];
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['name']};charset={$dbConfig['charset']}";
        $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

        try {
            $pdo = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], $options);
            // 仅当有邮件配置时才插入（避免空记录）
            if ($hasSmtpConfig) {
                $stmt = $pdo->prepare("
                    INSERT IGNORE INTO `email_settings` (
                        `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, 
                        `smtp_encryption`, `from_email`, `from_name`, `admin_notify_email`
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $emailConfig['smtp_host'], $emailConfig['smtp_port'], $emailConfig['smtp_user'],
                    $emailConfig['smtp_pass'], $emailConfig['smtp_enc'], $emailConfig['from_email'],
                    $emailConfig['from_name'], $emailConfig['admin_notify']
                ]);
                $_SESSION['email_config_status'] = '已配置（SMTP主机：' . $emailConfig['smtp_host'] . '）';
                $success = '邮件配置保存成功！';
            } else {
                $_SESSION['email_config_status'] = '未配置（可后续在系统后台补充）';
                $success = '已跳过邮件配置，可后续在系统后台补充！';
            }

            // 生成.env文件（仅包含数据库配置，与邮件无关）
            $envContent = "DB_HOST={$dbConfig['host']}\n";
            $envContent .= "DB_NAME={$dbConfig['name']}\n";
            $envContent .= "DB_USER={$dbConfig['user']}\n";
            $envContent .= "DB_PASS={$dbConfig['pass']}\n";
            $envContent .= "APP_ENV=production\n";
            file_put_contents(__DIR__ . '/.env', $envContent);
            chmod(__DIR__ . '/.env', 0600); // 权限锁定（仅所有者可读写）

            // 生成logs目录（对应db_connect.php的日志逻辑）
            if (!is_dir(LOG_DIR)) {
                mkdir(LOG_DIR, 0755, true);
                chmod(LOG_DIR, 0755);
            }

            $_SESSION['step'] = 5;
            header('Location: install.php');
            exit;
        } catch (PDOException $e) {
            $error = "保存邮件配置失败：" . $e->getMessage();
        }
    }
}

// 步骤6：安装完成（生成lock文件）
if (isset($_POST['step6_submit'])) {
    // 生成安装锁定文件
    file_put_contents(INSTALL_LOCK, "Installed at: " . date('Y-m-d H:i:s'));
    chmod(INSTALL_LOCK, 0644);
    // 清空会话（避免残留配置）
    session_destroy();
    header('Location: install.php?complete=1');
    exit;
}

// 安装完成页面（单独处理，显示邮件配置状态）
if (isset($_GET['complete'])) {
    die('
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>安装完成 - 卡密验证系统</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container mt-3 px-3">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title mb-0">安装成功！</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        <h5 class="alert-heading">🎉 卡密验证系统安装成功！</h5>
                        <p class="mb-0">系统已成功安装，您现在可以开始使用强大的卡密管理功能了！</p>
                    </div>
                    
                    <div class="alert alert-info" role="alert">
                        <h6 class="alert-heading">✨ 新功能特性</h6>
                        <ul class="mb-0">
                            <li><strong>使用次数控制：</strong> 支持设置卡密最大使用次数（1-999次）</li>
                            <li><strong>有效时间控制：</strong> 支持设置卡密有效期，过期自动失效</li>
                            <li><strong>IP绑定功能：</strong> 首次使用时自动绑定用户IP，防止恶意分享</li>
                            <li><strong>智能状态显示：</strong> 未使用、使用中、已用完、已过期四种状态</li>
                            <li><strong>使用记录追踪：</strong> 详细记录每次使用的时间和IP信息</li>
                        </ul>
                    </div>
                    
                    <div class="list-group mb-3">
                        <div class="list-group-item">
                            <strong>🔒 安全提示：</strong> 请立即删除根目录下的 <code>install.php</code> 文件，防止恶意访问！
                        </div>
                        <div class="list-group-item">
                            <strong>👤 登录信息：</strong> 使用您创建的管理员账号登录系统后台
                        </div>
                        <div class="list-group-item">
                            <strong>📧 邮件配置：</strong> ' . (isset($_SESSION['email_config_status']) ? $_SESSION['email_config_status'] : '未配置') . '，可在后台【邮箱配置】中修改
                        </div>
                        <div class="list-group-item">
                            <strong>📚 使用指南：</strong> 建议先创建分类，然后添加测试卡密体验新功能
                        </div>
                    </div>
                    <div class="d-grid gap-2">
                        <a href="admin/login.php" class="btn btn-success btn-lg">
                            <i class="fa fa-sign-in-alt me-2"></i>前往管理员登录
                        </a>
                        <a href="index.php" class="btn btn-primary">
                            <i class="fa fa-home me-2"></i>前往系统首页
                        </a>
                    </div>
                    
                    <hr class="my-4">
                    
                    <div class="text-center">
                        <h6 class="text-muted">🚀 快速开始指南</h6>
                        <div class="row text-start">
                            <div class="col-md-6">
                                <ol class="small">
                                    <li>登录管理后台</li>
                                    <li>创建卡密分类</li>
                                    <li>添加测试卡密</li>
                                </ol>
                            </div>
                            <div class="col-md-6">
                                <ol class="small" start="4">
                                    <li>设置使用次数和有效期</li>
                                    <li>测试卡密验证功能</li>
                                    <li>查看使用记录和状态</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>');
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $steps[$currentStep]; ?> - 卡密验证系统安装</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* 基础响应式调整 */
        body {
            padding-bottom: 2rem;
        }
        
        .container {
            max-width: 100%;
            padding-left: 0.75rem;
            padding-right: 0.75rem;
        }
        
        /* 步骤指示器优化 */
        .step-indicator {
            margin-bottom: 1.5rem;
            overflow-x: auto;
            padding-bottom: 0.5rem;
            white-space: nowrap;
        }
        
        .step-item {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            line-height: 36px;
            margin: 0 4px;
        }
        
        .step-item + span {
            margin-right: 8px;
            font-size: 0.9rem;
        }
        
        /* 表单元素优化 */
        .form-control {
            font-size: 1rem;
            padding: 0.6rem 0.75rem;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        label {
            font-size: 0.95rem;
            margin-bottom: 0.35rem;
        }
        
        .form-text {
            font-size: 0.85rem;
            padding-top: 0.25rem;
        }
        
        /* 按钮优化 */
        .btn {
            padding: 0.5rem 1rem;
            font-size: 0.95rem;
        }
        
        .btn + .btn {
            margin-top: 0.75rem;
        }
        
        /* 卡片和提示优化 */
        .card {
            border-radius: 0.5rem;
        }
        
        .card-header {
            padding: 0.75rem 1rem;
        }
        
        .card-body {
            padding: 1rem;
        }
        
        .alert {
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        
        /* 表格优化 */
        .table {
            font-size: 0.9rem;
        }
        
        .table td {
            padding: 0.75rem 0.5rem;
        }
        
        /* 响应式按钮组 */
        .btn-group-vertical-mobile {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }
        
        @media (min-width: 576px) {
            .btn-group-vertical-mobile {
                flex-direction: row;
            }
            
            .btn + .btn {
                margin-top: 0;
                margin-left: 0.5rem;
            }
        }
        
        /* 步骤标题优化 */
        h5.card-title {
            font-size: 1.1rem;
        }
        
        h6.mb-3 {
            font-size: 1rem;
            margin-bottom: 1rem !important;
        }
        
        /* 列表组优化 */
        .list-group-item {
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-3">
        <div class="card shadow-sm">
            <!-- 步骤指示器 -->
            <div class="card-header">
                <h5 class="card-title mb-3">卡密验证系统安装向导</h5>
                <div class="step-indicator">
                    <?php foreach ($steps as $key => $step): ?>
                        <span class="step-item <?php echo $key == $currentStep ? 'active' : ($key < $currentStep ? 'done' : ''); ?>">
                            <?php echo $key + 1; ?>
                        </span>
                        <span><?php echo $step; ?></span>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 错误/成功提示 -->
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger" role="alert"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success" role="alert"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- 步骤1：环境检测 -->
                <?php if ($currentStep == 0): ?>
                    <h6 class="mb-3">环境检测结果</h6>
                    <table class="table table-bordered">
                        <tr>
                            <td width="30%">PHP版本要求</td>
                            <td>
                                <?php 
                                $phpVersion = phpversion();
                                if (version_compare($phpVersion, '7.0.0', '>=')) {
                                    echo "<span class='text-success'>已满足（当前：{$phpVersion}）</span>";
                                } else {
                                    echo "<span class='text-danger'>不满足（需≥7.0，当前：{$phpVersion}）</span>";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>PDO扩展</td>
                            <td>
                                <?php echo extension_loaded('pdo_mysql') ? "<span class='text-success'>已启用</span>" : "<span class='text-danger'>未启用（必需）</span>"; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>JSON扩展</td>
                            <td>
                                <?php echo extension_loaded('json') ? "<span class='text-success'>已启用</span>" : "<span class='text-danger'>未启用（用于使用记录存储）</span>"; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>DateTime扩展</td>
                            <td>
                                <?php echo class_exists('DateTime') ? "<span class='text-success'>已启用</span>" : "<span class='text-danger'>未启用（用于时间处理）</span>"; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>日志目录权限</td>
                            <td>
                                <?php 
                                if (is_dir(LOG_DIR)) {
                                    $writable = is_writable(LOG_DIR) ? "<span class='text-success'>可写</span>" : "<span class='text-danger'>不可写</span>";
                                    echo "目录存在，{$writable}";
                                } else {
                                    $parentWritable = is_writable(dirname(LOG_DIR)) ? "<span class='text-success'>可创建</span>" : "<span class='text-danger'>不可创建（父目录无权限）</span>";
                                    echo "目录不存在，{$parentWritable}";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td>根目录权限</td>
                            <td>
                                <?php echo is_writable(__DIR__) ? "<span class='text-success'>可写（用于生成配置文件）</span>" : "<span class='text-danger'>不可写（需手动创建.env文件）</span>"; ?>
                            </td>
                        </tr>
                    </table>
                    <form method="post" action="install.php">
                        <button type="submit" name="step1_submit" class="btn btn-primary w-100">进入下一步：数据库配置</button>
                    </form>
                <?php endif; ?>

                <!-- 步骤2：数据库配置 -->
                <?php if ($currentStep == 1): ?>
                    <h6 class="mb-3">数据库连接配置 <span class="text-danger">(核心配置，必填)</span></h6>
                    <form method="post" action="install.php">
                        <div class="form-group">
                            <label for="db_host" class="form-label">数据库主机</label>
                            <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                            <div class="form-text">默认：localhost，远程数据库填写IP或域名</div>
                        </div>
                        <div class="form-group">
                            <label for="db_name" class="form-label">数据库名</label>
                            <input type="text" class="form-control" id="db_name" name="db_name" value="card_validation" required>
                            <div class="form-text">需提前在MySQL中创建该数据库</div>
                        </div>
                        <div class="form-group">
                            <label for="db_user" class="form-label">数据库用户名</label>
                            <input type="text" class="form-control" id="db_user" name="db_user" required>
                        </div>
                        <div class="form-group">
                            <label for="db_pass" class="form-label">数据库密码</label>
                            <input type="password" class="form-control" id="db_pass" name="db_pass">
                            <div class="form-text">若数据库无密码，留空即可</div>
                        </div>
                        <button type="submit" name="step2_submit" class="btn btn-primary w-100">测试连接并下一步</button>
                    </form>
                <?php endif; ?>

                <!-- 步骤3：创建数据表 -->
                <?php if ($currentStep == 2): ?>
                    <h6 class="mb-3">创建系统数据表</h6>
                    <p class="text-muted">系统将自动创建以下数据表：</p>
                    <div class="row">
                        <div class="col-md-6">
                            <ul class="list-unstyled">
                                <li><strong>admins</strong> - 管理员账号</li>
                                <li><strong>settings</strong> - 系统设置</li>
                                <li><strong>announcements</strong> - 公告管理</li>
                                <li><strong>categories</strong> - 卡密分类</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-unstyled">
                                <li><strong>cards</strong> - 卡密数据（支持使用次数、有效期、IP绑定）</li>
                                <li><strong>email_settings</strong> - 邮件配置</li>
                                <li><strong>card_usage_logs</strong> - 使用记录追踪</li>
                            </ul>
                        </div>
                    </div>
                    <div class="alert alert-info mt-3" role="alert">
                        <small><strong>新功能支持：</strong> 数据表已优化，支持卡密使用次数控制、有效时间管理、IP绑定等高级功能。</small>
                    </div>
                    <form method="post" action="install.php">
                        <button type="submit" name="step3_submit" class="btn btn-primary w-100">开始创建数据表</button>
                    </form>
                <?php endif; ?>

                <!-- 步骤4：管理员设置 -->
                <?php if ($currentStep == 3): ?>
                    <h6 class="mb-3">创建初始管理员账号 <span class="text-danger">(核心配置，必填)</span></h6>
                    <form method="post" action="install.php">
                        <div class="form-group">
                            <label for="admin_user" class="form-label">管理员用户名</label>
                            <input type="text" class="form-control" id="admin_user" name="admin_user" minlength="3" required>
                        </div>
                        <div class="form-group">
                            <label for="admin_pwd" class="form-label">管理员密码</label>
                            <input type="password" class="form-control" id="admin_pwd" name="admin_pwd" minlength="6" required>
                        </div>
                        <div class="form-group">
                            <label for="admin_pwd2" class="form-label">确认密码</label>
                            <input type="password" class="form-control" id="admin_pwd2" name="admin_pwd2" required>
                        </div>
                        <button type="submit" name="step4_submit" class="btn btn-primary w-100">创建账号并下一步</button>
                    </form>
                <?php endif; ?>

                <!-- 步骤5：邮件配置（可选） -->
                <?php if ($currentStep == 4): ?>
                    <h6 class="mb-3">邮件服务配置 <span class="optional-badge">可选</span></h6>
                    <div class="alert alert-info mb-4" role="alert">
                        邮件配置用于系统通知（如卡密使用提醒、管理员通知），<strong>可跳过（后续在后台【系统设置】中补充）</strong>；若填写，请确保核心字段完整（SMTP主机、端口、发件邮箱）。
                    </div>
                    <form method="post" action="install.php">
                        <div class="form-group">
                            <label for="smtp_host" class="form-label">SMTP主机</label>
                            <input type="text" class="form-control" id="smtp_host" name="smtp_host" placeholder="例如：smtp.qq.com（可选）">
                        </div>
                        <div class="form-group">
                            <label for="smtp_port" class="form-label">SMTP端口</label>
                            <input type="number" class="form-control" id="smtp_port" name="smtp_port" placeholder="例如：587（TLS）、465（SSL）（可选）">
                        </div>
                        <div class="form-group">
                            <label for="smtp_enc" class="form-label">加密方式</label>
                            <select class="form-select" id="smtp_enc" name="smtp_enc">
                                <option value="tls">TLS</option>
                                <option value="ssl">SSL</option>
                                <option value="">无（不推荐）</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="smtp_user" class="form-label">SMTP用户名</label>
                            <input type="text" class="form-control" id="smtp_user" name="smtp_user" placeholder="通常为发件邮箱地址（可选）">
                        </div>
                        <div class="form-group">
                            <label for="smtp_pass" class="form-label">SMTP密码/授权码</label>
                            <input type="password" class="form-control" id="smtp_pass" name="smtp_pass" placeholder="QQ邮箱用授权码（可选）">
                        </div>
                        <div class="form-group">
                            <label for="from_email" class="form-label">发件邮箱</label>
                            <input type="email" class="form-control" id="from_email" name="from_email" placeholder="例如：xxx@qq.com（可选）">
                        </div>
                        <div class="form-group">
                            <label for="from_name" class="form-label">发件人名称</label>
                            <input type="text" class="form-control" id="from_name" name="from_name" value="卡密验证系统" placeholder="可选">
                        </div>
                        <div class="form-group">
                            <label for="admin_notify" class="form-label">管理员通知邮箱</label>
                            <input type="email" class="form-control" id="admin_notify" name="admin_notify" placeholder="接收系统通知的邮箱（可选）">
                        </div>
                        <!-- 按钮组 - 在手机上垂直排列，在大屏幕上水平排列 -->
                        <div class="btn-group-vertical-mobile">
                            <button type="submit" name="step5_submit" class="btn btn-primary flex-fill">保存邮件配置并下一步</button>
                            <button type="submit" name="step5_skip" class="btn btn-secondary flex-fill">跳过邮件配置，直接下一步</button>
                        </div>
                    </form>
                <?php endif; ?>

                <!-- 步骤6：安装完成 -->
                <?php if ($currentStep == 5): ?>
                    <h6 class="mb-3">安装配置确认</h6>
                    <div class="list-group mb-3">
                        <div class="list-group-item">
                            <strong>数据库配置</strong>：已保存至 .env 文件（权限：0600）
                        </div>
                        <div class="list-group-item">
                            <strong>管理员账号</strong>：<?php echo $_SESSION['admin_user']; ?>（密码已加密存储）
                        </div>
                        <div class="list-group-item">
                            <strong>邮件配置</strong>：<?php echo isset($_SESSION['email_config_status']) ? $_SESSION['email_config_status'] : '未配置'; ?>
                        </div>
                        <div class="list-group-item">
                            <strong>日志目录</strong>：已创建（权限：0755）
                        </div>
                    </div>
                    <form method="post" action="install.php">
                        <div class="alert alert-warning" role="alert">
                            点击"确认完成"后，系统将生成安装锁定文件，禁止重复安装！
                        </div>
                        <button type="submit" name="step6_submit" class="btn btn-success w-100">确认完成安装</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>