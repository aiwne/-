<?php
// 验证登录状态
require_once 'auth.php';
require_once '../db_connect.php';

$message = '';
$messageType = '';
$announcementContent = '';
$announcementTime = '';

// 获取当前用户信息
$adminUsername = $_SESSION['admin_username'];
$currentPassword = '';

// 获取当前公告
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 获取用户信息
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = :username");
    $stmt->execute([':username' => $adminUsername]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        throw new Exception("未找到管理员信息");
    }
    
    // 查询当前公告（从新表查询）
    $stmt = $pdo->prepare("SELECT * FROM announcements ORDER BY updated_at DESC LIMIT 1");
    $stmt->execute();
    $announcement = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($announcement) {
        $announcementContent = $announcement['content'];
        $announcementTime = $announcement['updated_at'];
    } else {
        // 初始化公告时间
        $announcementTime = date('Y-m-d H:i:s');
    }
} catch (PDOException $e) {
    $message = "数据库操作失败: " . $e->getMessage();
    $messageType = 'error';
    error_log("个人设置页面错误: " . $e->getMessage());
}

// 处理密码修改表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    // CSRF保护
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = "操作失败：无效的请求令牌";
        $messageType = 'error';
    } else {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // 验证密码
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $message = "请填写所有密码字段";
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = "新密码和确认密码不匹配";
            $messageType = 'error';
        } elseif (strlen($newPassword) < 6) {
            $message = "新密码长度不能少于6个字符";
            $messageType = 'error';
        } else {
            try {
                // 验证当前密码
                if (!password_verify($currentPassword, $admin['password'])) {
                    $message = "当前密码不正确";
                    $messageType = 'error';
                } else {
                    // 更新密码
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE admins SET password = :password WHERE username = :username");
                    $stmt->execute([
                        ':password' => $hashedPassword,
                        ':username' => $adminUsername
                    ]);
                    
                    $message = "密码已成功更新";
                    $messageType = 'success';
                    
                    // 记录日志
                    error_log("管理员 {$adminUsername} 修改了密码");
                }
            } catch (PDOException $e) {
                $message = "更新密码失败: " . $e->getMessage();
                $messageType = 'error';
                error_log("修改密码错误: " . $e->getMessage());
            }
        }
    }
}

// 处理公告设置表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_announcement') {
    // CSRF保护
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = "操作失败：无效的请求令牌";
        $messageType = 'error';
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getPdo();
            
            $content = $_POST['announcement_content'];
            $currentTime = date('Y-m-d H:i:s');
            
            // 检查公告是否已存在（从新表查询）
            $stmt = $pdo->prepare("SELECT * FROM announcements LIMIT 1");
            $stmt->execute();
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing) {
                // 更新公告（更新新表）
                $stmt = $pdo->prepare("UPDATE announcements SET content = :content, updated_at = :updated_at WHERE id = :id");
                $stmt->execute([
                    ':content' => $content,
                    ':updated_at' => $currentTime,
                    ':id' => $existing['id']
                ]);
            } else {
                // 插入新公告（插入新表）
                $stmt = $pdo->prepare("INSERT INTO announcements (content, updated_at) VALUES (:content, :updated_at)");
                $stmt->execute([
                    ':content' => $content,
                    ':updated_at' => $currentTime
                ]);
            }
            
            $message = "公告已成功更新";
            $messageType = 'success';
            $announcementContent = $content;
            $announcementTime = $currentTime;
            
            // 记录日志
            error_log("管理员 {$adminUsername} 更新了系统公告");
            
        } catch (PDOException $e) {
            $message = "更新公告失败: " . $e->getMessage();
            $messageType = 'error';
            error_log("更新公告错误: " . $e->getMessage());
        }
    }
}

// 生成CSRF令牌
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人设置 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .mobile-menu-btn {
                @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
            }
            .btn-effect {
                @apply transition-all duration-200 transform hover:scale-105 active:scale-95;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($adminUsername); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <!-- 主容器 -->
    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
         <main class="flex-1 overflow-y-auto p-6 lg:pl-64 transition-all duration-300">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6">个人设置</h2>
                
                <?php if (!empty($message)): ?>
                    <div class="mb-6 p-4 rounded-md <?php 
                        echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                    ?>">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <?php if ($messageType === 'success'): ?>
                                    <i class="fa fa-check-circle text-green-500"></i>
                                <?php else: ?>
                                    <i class="fa fa-times-circle text-red-500"></i>
                                <?php endif; ?>
                            </div>
                            <div class="ml-3">
                                <p><?php echo $message; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- 密码修改区域 -->
                <div class="bg-white shadow rounded-lg p-6 max-w-2xl mb-8">
                    <h3 class="text-lg font-medium text-gray-800 mb-4">修改密码</h3>
                    <form method="post" class="space-y-4">
                        <input type="hidden" name="action" value="change_password">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        
                        <div>
                            <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">当前密码</label>
                            <input type="password" id="current_password" name="current_password" required
                                   class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                        </div>
                        
                        <div>
                            <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">新密码</label>
                            <input type="password" id="new_password" name="new_password" required
                                   minlength="6"
                                   class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                            <p class="mt-1 text-xs text-gray-500">密码长度至少6个字符</p>
                        </div>
                        
                        <div>
                            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">确认新密码</label>
                            <input type="password" id="confirm_password" name="confirm_password" required
                                   minlength="6"
                                   class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                        </div>
                        
                        <div class="pt-2">
                            <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                <i class="fa fa-save mr-2"></i>更新密码
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- 公告设置区域 -->
                <div class="bg-white shadow rounded-lg p-6 max-w-2xl">
                    <h3 class="text-lg font-medium text-gray-800 mb-4">系统公告设置</h3>
                    <form method="post" class="space-y-4">
                        <input type="hidden" name="action" value="update_announcement">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        
                        <div>
                            <label for="announcement_content" class="block text-sm font-medium text-gray-700 mb-1">公告内容</label>
                            <div class="border border-gray-300 rounded-md overflow-hidden">
                                <!-- 文本格式工具栏 -->
                                <div class="bg-gray-50 p-2 border-b border-gray-300 flex flex-wrap gap-1">
                                    <!-- 基础格式 -->
                                    <div class="flex items-center gap-1">
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('bold')" title="粗体 (Ctrl+B)">
                                            <i class="fa fa-bold"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('italic')" title="斜体 (Ctrl+I)">
                                            <i class="fa fa-italic"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('underline')" title="下划线 (Ctrl+U)">
                                            <i class="fa fa-underline"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('strikeThrough')" title="删除线">
                                            <i class="fa fa-strikethrough"></i>
                                        </button>
                                    </div>
                                    
                                    <span class="h-5 border-r border-gray-300 mx-1"></span>
                                    
                                    <!-- 代码格式 -->
                                    <div class="flex items-center gap-1">
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertInlineCode()" title="行内代码">
                                            <i class="fa fa-code"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertCodeBlock()" title="代码块">
                                            <i class="fa fa-file-code-o"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertPreBlock()" title="预格式化文本">
                                            <i class="fa fa-terminal"></i>
                                        </button>
                                    </div>
                                    
                                    <span class="h-5 border-r border-gray-300 mx-1"></span>
                                    
                                    <!-- 列表格式 -->
                                    <div class="flex items-center gap-1">
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('insertUnorderedList')" title="无序列表">
                                            <i class="fa fa-list-ul"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('insertOrderedList')" title="有序列表">
                                            <i class="fa fa-list-ol"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertQuote()" title="引用">
                                            <i class="fa fa-quote-left"></i>
                                        </button>
                                    </div>
                                    
                                    <span class="h-5 border-r border-gray-300 mx-1"></span>
                                    
                                    <!-- 对齐格式 -->
                                    <div class="flex items-center gap-1">
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('justifyLeft')" title="左对齐">
                                            <i class="fa fa-align-left"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('justifyCenter')" title="居中对齐">
                                            <i class="fa fa-align-center"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="formatText('justifyRight')" title="右对齐">
                                            <i class="fa fa-align-right"></i>
                                        </button>
                                    </div>
                                    
                                    <span class="h-5 border-r border-gray-300 mx-1"></span>
                                    
                                    <!-- 特殊格式 -->
                                    <div class="flex items-center gap-1">
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertLink()" title="插入链接">
                                            <i class="fa fa-link"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertLineBreak()" title="换行">
                                            <i class="fa fa-level-down"></i>
                                        </button>
                                        <button type="button" class="text-gray-700 hover:text-gray-900 hover:bg-gray-200 p-1.5 rounded" 
                                                onclick="insertHorizontalRule()" title="分割线">
                                            <i class="fa fa-minus"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- 富文本编辑区域 -->
                                <div id="announcement_editor" class="w-full px-4 py-2 min-h-[150px] focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                     contenteditable="true"><?php echo $announcementContent; ?></div>
                                <textarea id="announcement_content" name="announcement_content" class="hidden"><?php echo htmlspecialchars($announcementContent); ?></textarea>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">
                                支持富文本格式、代码块、行内代码、链接等，可使用快捷键 Ctrl+B/I/U，支持多种代码编写
                            </p>
                        </div>
                        
                        <div class="text-sm text-gray-600">
                            <p>上次更新时间: <?php echo date('Y-m-d H:i', strtotime($announcementTime)); ?></p>
                        </div>
                        
                        <div class="flex items-center space-x-4 pt-2">
                            <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                <i class="fa fa-save mr-2"></i>保存公告
                            </button>
                            <button type="button" 
                                    class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect"
                                    onclick="clearAnnouncement()">
                                <i class="fa fa-eraser mr-2"></i>清空内容
                            </button>
                        </div>
                    </form>
                </div>
                
                <div class="mt-8 bg-blue-50 border border-blue-100 rounded-lg p-4 max-w-2xl">
                    <h3 class="text-sm font-medium text-blue-800 flex items-center">
                        <i class="fa fa-info-circle mr-2"></i>安全提示
                    </h3>
                    <div class="mt-2 text-sm text-blue-700">
                        <p>• 请定期更换您的密码以保障账户安全</p>
                        <p>• 密码应包含字母、数字和特殊符号，长度不少于6位</p>
                        <p>• 请勿与他人共享您的管理员账户</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // 移动端侧边栏控制
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);
            
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('active');
            }
            
            // 富文本编辑功能
            const editor = document.getElementById('announcement_editor');
            const hiddenInput = document.getElementById('announcement_content');
            
            // 同步编辑器内容到隐藏输入框
            editor.addEventListener('input', function() {
                hiddenInput.value = editor.innerHTML;
            });
            
            // 格式化文本
            window.formatText = function(command) {
                document.execCommand(command, false, null);
                editor.focus();
                // 同步内容
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入行内代码
            window.insertInlineCode = function() {
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const codeElement = document.createElement('code');
                    codeElement.style.cssText = 'background-color: #f1f5f9; color: #e11d48; padding: 2px 4px; border-radius: 3px; font-family: monospace; font-size: 0.9em;';
                    
                    if (selection.toString()) {
                        codeElement.textContent = selection.toString();
                        range.deleteContents();
                        range.insertNode(codeElement);
                    } else {
                        codeElement.textContent = '代码';
                        range.insertNode(codeElement);
                        // 选中插入的文本
                        const newRange = document.createRange();
                        newRange.selectNodeContents(codeElement);
                        selection.removeAllRanges();
                        selection.addRange(newRange);
                    }
                }
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入代码块
            window.insertCodeBlock = function() {
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const preElement = document.createElement('pre');
                    const codeElement = document.createElement('code');
                    
                    preElement.style.cssText = 'background-color: #1e293b; color: #e2e8f0; padding: 12px; border-radius: 6px; margin: 8px 0; overflow-x: auto; font-family: "Courier New", monospace; font-size: 0.9em; line-height: 1.4;';
                    codeElement.style.cssText = 'color: inherit; background: none; padding: 0; border-radius: 0;';
                    
                    if (selection.toString()) {
                        codeElement.textContent = selection.toString();
                    } else {
                        codeElement.textContent = '// 在这里输入代码\nconsole.log("Hello World");';
                    }
                    
                    preElement.appendChild(codeElement);
                    range.deleteContents();
                    range.insertNode(preElement);
                    
                    // 在代码块后添加换行
                    const br = document.createElement('br');
                    preElement.parentNode.insertBefore(br, preElement.nextSibling);
                }
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入预格式化文本
            window.insertPreBlock = function() {
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const preElement = document.createElement('pre');
                    
                    preElement.style.cssText = 'background-color: #f8fafc; color: #334155; padding: 12px; border: 1px solid #e2e8f0; border-radius: 6px; margin: 8px 0; overflow-x: auto; font-family: "Courier New", monospace; font-size: 0.9em; line-height: 1.4; white-space: pre-wrap;';
                    
                    if (selection.toString()) {
                        preElement.textContent = selection.toString();
                    } else {
                        preElement.textContent = '预格式化文本\n保持空格和换行';
                    }
                    
                    range.deleteContents();
                    range.insertNode(preElement);
                    
                    // 在预格式化块后添加换行
                    const br = document.createElement('br');
                    preElement.parentNode.insertBefore(br, preElement.nextSibling);
                }
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入引用
            window.insertQuote = function() {
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const blockquoteElement = document.createElement('blockquote');
                    
                    blockquoteElement.style.cssText = 'border-left: 4px solid #3b82f6; padding-left: 12px; margin: 8px 0; color: #64748b; font-style: italic; background-color: #f8fafc; padding: 8px 12px; border-radius: 0 6px 6px 0;';
                    
                    if (selection.toString()) {
                        blockquoteElement.textContent = selection.toString();
                    } else {
                        blockquoteElement.textContent = '引用内容';
                    }
                    
                    range.deleteContents();
                    range.insertNode(blockquoteElement);
                    
                    // 在引用后添加换行
                    const br = document.createElement('br');
                    blockquoteElement.parentNode.insertBefore(br, blockquoteElement.nextSibling);
                }
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入链接
            window.insertLink = function() {
                const url = prompt('请输入链接地址:', 'https://');
                if (url && url !== 'https://') {
                    const selection = window.getSelection();
                    if (selection.rangeCount > 0) {
                        const range = selection.getRangeAt(0);
                        const linkElement = document.createElement('a');
                        
                        linkElement.href = url;
                        linkElement.target = '_blank';
                        linkElement.style.cssText = 'color: #3b82f6; text-decoration: underline;';
                        
                        if (selection.toString()) {
                            linkElement.textContent = selection.toString();
                        } else {
                            linkElement.textContent = url;
                        }
                        
                        range.deleteContents();
                        range.insertNode(linkElement);
                    }
                }
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入换行
            window.insertLineBreak = function() {
                document.execCommand('insertHTML', false, '<br>');
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 插入分割线
            window.insertHorizontalRule = function() {
                const hr = document.createElement('hr');
                hr.style.cssText = 'border: none; border-top: 2px solid #e2e8f0; margin: 16px 0;';
                document.execCommand('insertHTML', false, hr.outerHTML);
                editor.focus();
                hiddenInput.value = editor.innerHTML;
            }
            
            // 清空公告内容
            window.clearAnnouncement = function() {
                if (confirm('确定要清空公告内容吗？')) {
                    editor.innerHTML = '';
                    hiddenInput.value = '';
                }
            }
            
            // 支持快捷键
            editor.addEventListener('keydown', function(e) {
                // Ctrl+B 粗体
                if (e.ctrlKey && e.key === 'b') {
                    e.preventDefault();
                    formatText('bold');
                }
                // Ctrl+I 斜体
                if (e.ctrlKey && e.key === 'i') {
                    e.preventDefault();
                    formatText('italic');
                }
                // Ctrl+U 下划线
                if (e.ctrlKey && e.key === 'u') {
                    e.preventDefault();
                    formatText('underline');
                }
            });
        });
    </script>
</body>
</html>