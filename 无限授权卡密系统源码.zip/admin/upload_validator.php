<?php
/**
 * 文件上传验证类
 * 提供统一的文件上传验证和错误处理
 */
class UploadValidator {
    
    // 支持的文件类型
    const ALLOWED_TYPES = [
        'text/csv',
        'text/plain',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    // 支持的文件扩展名
    const ALLOWED_EXTENSIONS = ['csv', 'txt', 'xlsx', 'xls'];
    
    // 最大文件大小（10MB）
    const MAX_FILE_SIZE = 10 * 1024 * 1024;
    
    /**
     * 验证上传文件
     */
    public static function validateFile($file) {
        $errors = [];
        
        // 检查文件是否上传成功
        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = self::getUploadErrorMessage($file['error'] ?? UPLOAD_ERR_NO_FILE);
            return ['valid' => false, 'errors' => $errors];
        }
        
        // 检查文件大小
        if ($file['size'] > self::MAX_FILE_SIZE) {
            $errors[] = "文件大小超过 " . self::formatFileSize(self::MAX_FILE_SIZE) . " 限制";
        }
        
        // 检查文件类型
        $fileType = self::getMimeType($file['tmp_name']);
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($fileType, self::ALLOWED_TYPES) && !in_array($fileExtension, self::ALLOWED_EXTENSIONS)) {
            $errors[] = "不支持的文件类型，请上传CSV、TXT或Excel文件";
        }
        
        // 检查文件是否为空
        if ($file['size'] === 0) {
            $errors[] = "文件为空";
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors,
            'file_type' => $fileType,
            'file_extension' => $fileExtension
        ];
    }
    
    /**
     * 获取上传错误信息
     */
    private static function getUploadErrorMessage($errorCode) {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
                return "文件大小超过服务器限制";
            case UPLOAD_ERR_FORM_SIZE:
                return "文件大小超过表单限制";
            case UPLOAD_ERR_PARTIAL:
                return "文件只上传了部分";
            case UPLOAD_ERR_NO_FILE:
                return "没有选择文件";
            case UPLOAD_ERR_NO_TMP_DIR:
                return "缺少临时文件夹";
            case UPLOAD_ERR_CANT_WRITE:
                return "文件写入失败";
            case UPLOAD_ERR_EXTENSION:
                return "文件上传被扩展程序阻止";
            default:
                return "未知的上传错误";
        }
    }
    
    /**
     * 格式化文件大小
     */
    public static function formatFileSize($bytes) {
        if ($bytes === 0) return '0 Bytes';
        $k = 1024;
        $sizes = ['Bytes', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes) / log($k));
        return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
    }
    
    /**
     * 验证CSV文件内容
     */
    public static function validateCsvContent($filePath) {
        $errors = [];
        $warnings = [];
        $lineCount = 0;
        $validLineCount = 0;
        
        // 直接读取文件内容，避免复杂的文件指针操作
        $content = file_get_contents($filePath);
        if ($content === false) {
            $errors[] = "无法读取文件内容";
            return ['valid' => false, 'errors' => $errors, 'warnings' => $warnings];
        }
        
        // 移除BOM
        if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
            $content = substr($content, 3);
        }
        
        // 按行分割
        $lines = explode("\n", $content);
        
        // 检测格式：检查第一行是否包含逗号
        $isCsvFormat = false;
        if (!empty($lines[0]) && strpos($lines[0], ',') !== false) {
            $isCsvFormat = true;
        }
        
        // 调试信息
        error_log("文件格式检测：第一行='" . trim($lines[0] ?? '') . "', CSV格式=" . ($isCsvFormat ? '是' : '否'));
        error_log("总行数：" . count($lines));
        error_log("文件内容：" . substr($content, 0, 500));
        
        foreach ($lines as $lineIndex => $line) {
            $lineCount++;
            $line = trim($line);
            
            // 跳过空行
            if (empty($line)) {
                continue;
            }
            
            // 跳过注释行
            if (strpos($line, '#') === 0) {
                continue;
            }
            
            if ($isCsvFormat) {
                // CSV格式：解析CSV行
                $data = str_getcsv($line, ',');
                
                // 验证卡密代码
                if (empty($data[0])) {
                    $errors[] = "第 {$lineCount} 行：卡密代码不能为空";
                    continue;
                }
                
                $cardCode = trim($data[0]);
                if (strlen($cardCode) < 3) {
                    $warnings[] = "第 {$lineCount} 行：卡密代码过短，建议至少3个字符";
                }
                
                if (strlen($cardCode) > 100) {
                    $errors[] = "第 {$lineCount} 行：卡密代码过长，不能超过100个字符";
                    continue;
                }
                
                // 验证使用次数
                if (isset($data[2]) && !empty($data[2])) {
                    $maxUses = (int)$data[2];
                    if ($maxUses < 1 || $maxUses > 999) {
                        $warnings[] = "第 {$lineCount} 行：使用次数应在1-999之间，已自动调整为1";
                    }
                }
                
                // 验证有效期格式
                if (isset($data[3]) && !empty($data[3])) {
                    $validUntil = strtotime($data[3]);
                    if ($validUntil === false) {
                        $warnings[] = "第 {$lineCount} 行：有效期格式不正确，已忽略";
                    }
                }
                
                // 验证分类ID
                if (isset($data[4]) && !empty($data[4])) {
                    $categoryId = (int)$data[4];
                    if ($categoryId < 1) {
                        $warnings[] = "第 {$lineCount} 行：分类ID必须为正整数，已忽略";
                    }
                }
            } else {
                // 纯文本格式：整行作为卡密代码
                $cardCode = $line;
                
                error_log("处理纯文本行 {$lineCount}: '{$cardCode}' (长度: " . strlen($cardCode) . ")");
                
                if (strlen($cardCode) < 3) {
                    $warnings[] = "第 {$lineCount} 行：卡密代码过短，建议至少3个字符";
                    error_log("卡密代码过短，但仍算作有效");
                }
                
                if (strlen($cardCode) > 100) {
                    $errors[] = "第 {$lineCount} 行：卡密代码过长，不能超过100个字符";
                    error_log("卡密代码过长，跳过");
                    continue;
                }
                
                error_log("卡密代码有效: '{$cardCode}'");
            }
            
            $validLineCount++;
            error_log("有效行数增加到: {$validLineCount}");
        }
        
        if ($validLineCount === 0) {
            $errors[] = "文件中没有找到有效的卡密数据";
            $errors[] = "调试信息：总行数={$lineCount}，CSV格式=" . ($isCsvFormat ? '是' : '否');
            $errors[] = "文件内容预览：" . substr($content, 0, 200);
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors,
            'warnings' => $warnings,
            'line_count' => $lineCount,
            'valid_line_count' => $validLineCount,
            'is_csv_format' => $isCsvFormat
        ];
    }
    
    /**
     * 清理和标准化卡密数据
     */
    public static function sanitizeCardData($card) {
        return [
            'card_code' => trim($card['card_code']),
            'content' => trim($card['content'] ?? ''),
            'max_uses' => max(1, min(999, (int)($card['max_uses'] ?? 1))),
            'valid_until' => self::parseValidUntil($card['valid_until'] ?? null),
            'category_id' => self::parseCategoryId($card['category_id'] ?? null)
        ];
    }
    
    /**
     * 解析有效期
     */
    private static function parseValidUntil($validUntil) {
        if (empty($validUntil)) {
            return null;
        }
        
        $timestamp = strtotime($validUntil);
        return $timestamp !== false ? date('Y-m-d H:i:s', $timestamp) : null;
    }
    
    /**
     * 解析分类ID
     */
    private static function parseCategoryId($categoryId) {
        if (empty($categoryId)) {
            return null;
        }
        
        $id = (int)$categoryId;
        return $id > 0 ? $id : null;
    }
    
    /**
     * 获取文件MIME类型（兼容性处理）
     */
    public static function getMimeType($filePath) {
        $mimeType = 'application/octet-stream';
        
        // 优先使用mime_content_type函数
        if (function_exists('mime_content_type')) {
            $mimeType = mime_content_type($filePath);
        }
        // 如果mime_content_type不可用，使用finfo
        elseif (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($filePath);
        }
        
        // 如果检测为application/octet-stream，尝试用扩展名判断
        if ($mimeType === 'application/octet-stream') {
            $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            $mimeTypes = [
                'csv' => 'text/csv',
                'txt' => 'text/plain',
                'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'xls' => 'application/vnd.ms-excel'
            ];
            $mimeType = $mimeTypes[$extension] ?? 'text/plain'; // 默认为text/plain
        }
        
        return $mimeType;
    }
}
?>
