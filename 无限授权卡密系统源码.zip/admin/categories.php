<?php
/**
 * 分类管理页面（修复删除功能版）
 */
require_once 'auth.php'; // 权限验证
require_once '../db_connect.php'; // 数据库连接

// 初始化消息变量
$message = '';
$messageType = '';

// 处理URL参数中的消息
if (isset($_GET['message']) && isset($_GET['type'])) {
    $message = urldecode($_GET['message']);
    $messageType = $_GET['type'];
}

// 处理删除分类请求
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $categoryId = (int)$_GET['id'];
    
    try {
        $db = Database::getInstance();
        $pdo = $db->getPdo();
        $pdo->beginTransaction(); // 开启事务
        
        // 步骤1: 查询该分类下的卡密数量
        $stmt = $pdo->prepare("SELECT COUNT(*) AS card_count FROM cards WHERE category_id = :category_id");
        $stmt->bindValue(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $cardCount = (int)$result['card_count'];
        
        // 步骤2: 执行分类删除（外键会自动处理关联卡密）
        $deleteStmt = $pdo->prepare("DELETE FROM categories WHERE id = :id");
        $deleteStmt->bindValue(':id', $categoryId, PDO::PARAM_INT);
        $deleteStmt->execute();
        
        // 验证是否真的删除成功
        if ($deleteStmt->rowCount() === 0) {
            throw new Exception("分类不存在或已被删除");
        }
        
        $pdo->commit(); // 提交事务
        
        // 生成提示消息
        if ($cardCount > 0) {
            $message = "分类删除成功！该分类下的 {$cardCount} 个卡密已自动标记为「未分类」";
        } else {
            $message = "分类删除成功！";
        }
        $messageType = 'success';
        
    } catch (PDOException $e) {
        $pdo->rollBack(); // 回滚事务
        $message = "删除失败：数据库错误 - " . $e->getMessage();
        $messageType = 'error';
        error_log("分类删除数据库错误: " . $e->getMessage());
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "删除失败：" . $e->getMessage();
        $messageType = 'error';
    }
    
    // 重定向避免刷新重复提交
    header("Location: categories.php?message=" . urlencode($message) . "&type=" . $messageType);
    exit;
}

// 获取所有分类（带卡密数量统计）
$categories = [];
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 关联查询每个分类下的卡密数量
    $stmt = $pdo->query("
        SELECT c.id, c.name, c.description, c.created_at, 
               COUNT(k.id) AS card_count
        FROM categories c
        LEFT JOIN cards k ON c.id = k.category_id
        GROUP BY c.id
        ORDER BY c.name ASC
    ");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "获取分类列表失败: " . $e->getMessage();
    $messageType = 'error';
    error_log("获取分类列表错误: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分类管理 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible { transform: translateX(0); }
            .sidebar-hidden { transform: translateX(-100%); }
            .btn-action { @apply px-3 py-1 rounded text-sm transition-colors; }
            .btn-edit { @apply bg-blue-100 text-blue-800 hover:bg-blue-200; }
            .btn-delete { @apply bg-red-100 text-red-800 hover:bg-red-200; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700 lg:hidden">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密分类管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                    <a href="categories.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                      <a href="bark_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                <div>
                    <h2 class="text-2xl font-semibold text-gray-800">分类管理</h2>
                    <p class="mt-1 text-gray-600">管理卡密的分类，可添加、编辑和删除分类</p>
                </div>
                <a href="category_edit.php" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                    <i class="fa fa-plus mr-2"></i>添加新分类
                </a>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 分类列表 -->
            <div class="bg-white shadow overflow-hidden sm:rounded-lg">
                <?php if (empty($categories)): ?>
                    <!-- 空状态 -->
                    <div class="p-8 text-center">
                        <i class="fa fa-folder-open text-gray-300 text-5xl mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900">暂无分类</h3>
                        <p class="mt-1 text-gray-500">还没有创建任何分类，点击下方按钮添加</p>
                        <div class="mt-6">
                            <a href="category_edit.php" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                                <i class="fa fa-plus mr-2"></i>添加第一个分类
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- 分类表格 -->
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">分类名称</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">卡密数量</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">创建时间</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">描述</th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($categories as $category): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($category['name']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                <?php echo $category['card_count']; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('Y-m-d H:i', strtotime($category['created_at'])); ?>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-500">
                                            <?php echo empty($category['description']) ? '<span class="text-gray-400">无描述</span>' : htmlspecialchars($category['description']); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <a href="category_edit.php?id=<?php echo $category['id']; ?>" class="btn-action btn-edit mr-2">
                                                <i class="fa fa-pencil mr-1"></i>编辑
                                            </a>
                                            <a href="?action=delete&id=<?php echo $category['id']; ?>" 
                                               class="btn-action btn-delete"
                                               onclick="return confirm('确定要删除分类「<?php echo htmlspecialchars($category['name']); ?>」吗？\n该分类下的 <?php echo $category['card_count']; ?> 个卡密将被标记为未分类。')">
                                                <i class="fa fa-trash mr-1"></i>删除
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        // 侧边栏切换功能
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            // 切换侧边栏显示状态
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('hidden');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化时自动调整
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) { // lg断点
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.add('hidden');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('sidebar-hidden');
                }
            });
        });
    </script>
</body>
</html>
    