<?php
/**
 * 添加卡密页面（带分类功能）
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化变量
$message = '';
$messageType = '';
$cardCode = '';
$content = '';
$categoryId = '';
$maxUses = 1;
$validUntil = '';

// 初始化表单数据
$formData = [
    'card_code' => $cardCode,
    'content' => $content,
    'category_id' => $categoryId,
    'max_uses' => $maxUses,
    'valid_until' => $validUntil
];
// 生成随机卡密
function generateCardCode($length = 16) {
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return implode('-', str_split($code, 4));
}
// 处理变量替换
function replaceVariables($content, $sequenceNumber, $cardCode) {
    $variables = [
        '{NUM}' => $sequenceNumber,
        '{CODE}' => $cardCode,
        '{DATE}' => date('Y-m-d'),
        '{DATETIME}' => date('Y-m-d H:i:s')
    ];
    return strtr($content, $variables);
}

// 获取所有分类
$categories = [];
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "获取分类列表失败: " . $e->getMessage();
    $messageType = 'error';
    error_log("获取分类列表错误: " . $e->getMessage());
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardCode = trim($_POST['card_code'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $categoryId = isset($_POST['category_id']) && is_numeric($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $maxUses = isset($_POST['max_uses']) && is_numeric($_POST['max_uses']) ? max(1, (int)$_POST['max_uses']) : 1;
    $validUntil = !empty($_POST['valid_until']) ? $_POST['valid_until'] : null;
    
    if (empty($cardCode)) {
        $message = "请输入卡密代码";
        $messageType = 'warning';
    } elseif (empty($content)) {
        $message = "请输入卡密内容";
        $messageType = 'warning';
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getPdo();
            
            // 检查卡密是否已存在
            $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_code = :card_code");
            $stmt->bindValue(':card_code', $cardCode, PDO::PARAM_STR);
            $stmt->execute();
            
            if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                $message = "该卡密代码已存在，请更换";
                $messageType = 'warning';
            } else {
                // 验证有效时间
                if ($validUntil && !strtotime($validUntil)) {
                    $message = "有效时间格式不正确";
                    $messageType = 'warning';
                } else {
                    // 插入新卡密（包含分类ID、使用次数、有效时间）
                    $stmt = $pdo->prepare("
                        INSERT INTO cards (card_code, content, category_id, max_uses, current_uses, valid_until, used, created_at)
                        VALUES (:card_code, :content, :category_id, :max_uses, 0, :valid_until, 0, NOW())
                    ");
                    $stmt->bindValue(':card_code', $cardCode, PDO::PARAM_STR);
                    $stmt->bindValue(':content', $content, PDO::PARAM_STR);
                    $stmt->bindValue(':category_id', $categoryId, $categoryId ? PDO::PARAM_INT : PDO::PARAM_NULL);
                    $stmt->bindValue(':max_uses', $maxUses, PDO::PARAM_INT);
                    $stmt->bindValue(':valid_until', $validUntil ? date('Y-m-d H:i:s', strtotime($validUntil)) : null, $validUntil ? PDO::PARAM_STR : PDO::PARAM_NULL);
                    $stmt->execute();
                
                    $message = "卡密添加成功";
                    $messageType = 'success';
                    $cardCode = '';
                    $content = '';
                    $categoryId = '';
                    $maxUses = 1;
                    $validUntil = '';
                    
                    // 更新表单数据
                    $formData = [
                        'card_code' => $cardCode,
                        'content' => $content,
                        'category_id' => $categoryId,
                        'max_uses' => $maxUses,
                        'valid_until' => $validUntil
                    ];
                }
            }
        } catch (PDOException $e) {
            $message = "添加卡密失败: " . $e->getMessage();
            $messageType = 'error';
            error_log("添加卡密错误: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加卡密 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .mobile-menu-btn {
                @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 - 移动端默认隐藏，桌面端显示 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>

                    <a href="bark_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                   <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto p-2 lg:pl-64 transition-all duration-300">
            <div class="px-1 sm:px-2 lg:px-3 py-2">
                <div class="mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">添加新卡密</h2>
                <p class="mt-1 text-gray-600">请填写卡密信息，带 <span class="text-red-500">*</span> 为必填项</p>
            </div>
             <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                    <i class="fa <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-2xl">
                <div class="px-4 py-5 sm:px-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">卡密信息</h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">
                        填写卡密代码和对应的内容，添加后可以在卡密列表中管理
                    </p>
                    
                    <div class="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-md">
                        <h4 class="text-sm font-medium text-blue-800 flex items-center">
                            <i class="fa fa-info-circle mr-2"></i>支持的变量
                             
                        </h4>
                        <ul class="mt-2 text-sm text-blue-700 space-y-1 ml-6 list-disc">
                          <li><code>这个暂无</code> - 自动生成的序号</li>
                        </ul>
                    </div>
                </div>
                
                <div class="border-t border-gray-200 px-4 py-5 sm:p-6">
                    <form method="post" class="space-y-6">
                        <div class="col-span-6 sm:col-span-4">
                            <label for="card_code" class="block text-sm font-medium text-gray-700 mb-1">卡密代码</label>
                            <div class="space-y-3">
                                <!-- 卡密代码输入框和操作按钮 -->
                                <div class="flex">
                                    <input type="text" name="card_code" id="card_code" required
                                           value="<?php echo htmlspecialchars($formData['card_code']); ?>"
                                           class="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           placeholder="点击生成按钮自动生成卡密代码">
                                    <div class="ml-2 flex space-x-1">
                                        <button type="button" id="generate-btn" 
                                                class="px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 transition-colors"
                                                title="生成新卡密">
                                            <i class="fa fa-refresh"></i>
                                        </button>
                                        <button type="button" id="copy-btn" 
                                                class="px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 transition-colors"
                                                title="复制到剪贴板">
                                            <i class="fa fa-copy"></i>
                                        </button>
                                        <button type="button" id="clear-btn" 
                                                class="px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 transition-colors"
                                                title="清空输入框">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- 生成选项 -->
                                <div class="bg-gray-50 p-3 rounded-md">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-sm font-medium text-gray-700">生成选项</span>
                                        <div class="flex space-x-1">
                                            <button type="button" id="auto-generate-btn" 
                                                    class="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors">
                                                <i class="fa fa-magic mr-1"></i>自动生成
                                            </button>
                                            <button type="button" id="preview-btn" 
                                                    class="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors">
                                                <i class="fa fa-eye mr-1"></i>预览
                                            </button>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-3">
                                        <div>
                                            <label for="code_length" class="block text-xs text-gray-600 mb-1">长度</label>
                                            <select id="code_length" class="w-full text-xs px-2 py-1 border border-gray-300 rounded">
                                                <option value="12">12位</option>
                                                <option value="16" selected>16位</option>
                                                <option value="20">20位</option>
                                                <option value="24">24位</option>
                                                <option value="32">32位</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label for="code_format" class="block text-xs text-gray-600 mb-1">格式</label>
                                            <select id="code_format" class="w-full text-xs px-2 py-1 border border-gray-300 rounded">
                                                <option value="dash" selected>带分隔符 (XXXX-XXXX-XXXX-XXXX)</option>
                                                <option value="plain">纯文本 (XXXXXXXXXXXXXXXX)</option>
                                                <option value="space">空格分隔 (XXXX XXXX XXXX XXXX)</option>
                                                <option value="dot">点分隔 (XXXX.XXXX.XXXX.XXXX)</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <label class="flex items-center text-xs text-gray-600">
                                            <input type="checkbox" id="include_lowercase" class="mr-1">
                                            包含小写字母
                                        </label>
                                        <label class="flex items-center text-xs text-gray-600">
                                            <input type="checkbox" id="exclude_similar" class="mr-1" checked>
                                            排除相似字符 (0O1I)
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- 预览区域 -->
                                <div id="preview-area" class="hidden bg-white border border-gray-200 rounded-md p-3">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="text-sm font-medium text-gray-700">生成预览</span>
                                        <button type="button" id="close-preview-btn" 
                                                class="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors">
                                            <i class="fa fa-times mr-1"></i>关闭
                                        </button>
                                    </div>
                                    <div id="preview-codes" class="space-y-1 max-h-32 overflow-y-auto">
                                        <!-- 预览代码将在这里显示 -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <label for="content" class="block text-sm font-medium text-gray-700 mb-1">卡密内容</label>
                      <textarea id="content" name="content" rows="6" required
                                      class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                      placeholder="自己自定义内容"><?php echo htmlspecialchars($formData['content']); ?></textarea>
                        </div>

            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                         ($messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                ?> fade-in">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 
                             ($messageType === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle');
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
                        
                        <!-- 新增分类选择 -->
                        <div class="mb-4">
                            <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">
                                卡密分类
                            </label>
                            <select name="category_id" id="category_id" 
                                    class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">-- 请选择分类（可选） --</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" 
                                        <?php echo $categoryId == $category['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="mt-1 text-sm text-gray-500">
                                选择卡密所属分类，如需管理分类请<a href="categories.php" class="text-blue-600 hover:underline">点击这里</a>
                            </p>
                        </div>

                        <!-- 使用次数和有效时间 -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="max_uses" class="block text-sm font-medium text-gray-700 mb-1">
                                    最大使用次数 <span class="text-red-500">*</span>
                                </label>
                                <input type="number" name="max_uses" id="max_uses" 
                                       value="<?php echo $maxUses; ?>" min="1" max="999"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="mt-1 text-sm text-gray-500">设置卡密可使用的最大次数，1表示一次性使用</p>
                            </div>
                            
                            <div>
                                <label for="valid_until" class="block text-sm font-medium text-gray-700 mb-1">
                                    有效期至（可选）
                                </label>
                                <input type="datetime-local" name="valid_until" id="valid_until" 
                                       value="<?php echo $validUntil; ?>"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <p class="mt-1 text-sm text-gray-500">设置卡密的有效期，留空表示永久有效</p>
                            </div>
                        </div>
                        
                        <div class="flex justify-end gap-3 pt-4 border-t border-gray-200">
                            <a href="cards_list.php" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                取消
                            </a>
                            <button type="submit" class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <i class="fa fa-save mr-1"></i>保存卡密
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏切换功能
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            // 切换侧边栏显示状态
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('active');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化时自动调整
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) { // lg断点
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.remove('active');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('sidebar-hidden');
                }
            });

            // 表单自动聚焦
            document.getElementById('card_code').focus();
        });
        // 卡密生成功能
        function generateCardCode() {
            const length = parseInt(document.getElementById('code_length').value);
            const format = document.getElementById('code_format').value;
            const includeLowercase = document.getElementById('include_lowercase').checked;
            const excludeSimilar = document.getElementById('exclude_similar').checked;
            
            // 字符集配置
            let chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            if (includeLowercase) {
                chars += 'abcdefghijklmnopqrstuvwxyz';
            }
            if (excludeSimilar) {
                chars = chars.replace(/[0O1I]/g, '');
            }
            
            // 生成随机字符串
            let code = '';
            for (let i = 0; i < length; i++) {
                code += chars[Math.floor(Math.random() * chars.length)];
            }
            
            // 格式化
            switch (format) {
                case 'dash':
                    code = code.match(/.{4}/g).join('-');
                    break;
                case 'space':
                    code = code.match(/.{4}/g).join(' ');
                    break;
                case 'dot':
                    code = code.match(/.{4}/g).join('.');
                    break;
                case 'plain':
                default:
                    // 保持原样
                    break;
            }
            
            document.getElementById('card_code').value = code;
            
            // 添加生成成功提示
            showGenerateSuccess();
        }
        
        // 显示生成成功提示
        function showGenerateSuccess() {
            const input = document.getElementById('card_code');
            const originalBg = input.style.backgroundColor;
            input.style.backgroundColor = '#d4edda';
            input.style.borderColor = '#c3e6cb';
            
            setTimeout(() => {
                input.style.backgroundColor = originalBg;
                input.style.borderColor = '';
            }, 1000);
        }
        
        // 自动生成功能
        function autoGenerate() {
            // 随机选择长度和格式
            const lengths = [12, 16, 20, 24, 32];
            const formats = ['dash', 'plain', 'space', 'dot'];
            
            document.getElementById('code_length').value = lengths[Math.floor(Math.random() * lengths.length)];
            document.getElementById('code_format').value = formats[Math.floor(Math.random() * formats.length)];
            
            // 随机选择是否包含小写字母
            document.getElementById('include_lowercase').checked = Math.random() > 0.5;
            
            generateCardCode();
        }
        
        // 复制到剪贴板功能
        function copyToClipboard() {
            const input = document.getElementById('card_code');
            input.select();
            input.setSelectionRange(0, 99999); // 移动端兼容
            
            try {
                document.execCommand('copy');
                showCopySuccess();
            } catch (err) {
                // 现代浏览器使用 Clipboard API
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(input.value).then(() => {
                        showCopySuccess();
                    }).catch(() => {
                        showCopyError();
                    });
                } else {
                    showCopyError();
                }
            }
        }
        
        // 清空输入框
        function clearInput() {
            document.getElementById('card_code').value = '';
            document.getElementById('card_code').focus();
        }
        
        // 显示复制成功提示
        function showCopySuccess() {
            const btn = document.getElementById('copy-btn');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="fa fa-check text-green-600"></i>';
            btn.classList.add('bg-green-100', 'border-green-300');
            
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.classList.remove('bg-green-100', 'border-green-300');
            }, 1500);
        }
        
        // 显示复制失败提示
        function showCopyError() {
            const btn = document.getElementById('copy-btn');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="fa fa-times text-red-600"></i>';
            btn.classList.add('bg-red-100', 'border-red-300');
            
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.classList.remove('bg-red-100', 'border-red-300');
            }, 1500);
        }
        
        // 预览功能
        function showPreview() {
            const previewArea = document.getElementById('preview-area');
            const previewCodes = document.getElementById('preview-codes');
            
            // 生成10个预览代码
            let previewHTML = '';
            for (let i = 0; i < 10; i++) {
                const code = generatePreviewCode();
                previewHTML += `
                    <div class="flex items-center justify-between py-1 px-2 bg-gray-50 rounded text-xs">
                        <span class="font-mono text-gray-700">${code}</span>
                        <button type="button" class="text-blue-600 hover:text-blue-800" onclick="selectPreviewCode('${code}')">
                            <i class="fa fa-check"></i>
                        </button>
                    </div>
                `;
            }
            
            previewCodes.innerHTML = previewHTML;
            previewArea.classList.remove('hidden');
        }
        
        // 生成预览代码（不更新输入框）
        function generatePreviewCode() {
            const length = parseInt(document.getElementById('code_length').value);
            const format = document.getElementById('code_format').value;
            const includeLowercase = document.getElementById('include_lowercase').checked;
            const excludeSimilar = document.getElementById('exclude_similar').checked;
            
            // 字符集配置
            let chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            if (includeLowercase) {
                chars += 'abcdefghijklmnopqrstuvwxyz';
            }
            if (excludeSimilar) {
                chars = chars.replace(/[0O1I]/g, '');
            }
            
            // 生成随机字符串
            let code = '';
            for (let i = 0; i < length; i++) {
                code += chars[Math.floor(Math.random() * chars.length)];
            }
            
            // 格式化
            switch (format) {
                case 'dash':
                    code = code.match(/.{4}/g).join('-');
                    break;
                case 'space':
                    code = code.match(/.{4}/g).join(' ');
                    break;
                case 'dot':
                    code = code.match(/.{4}/g).join('.');
                    break;
                case 'plain':
                default:
                    // 保持原样
                    break;
            }
            
            return code;
        }
        
        // 选择预览代码
        function selectPreviewCode(code) {
            document.getElementById('card_code').value = code;
            document.getElementById('preview-area').classList.add('hidden');
            showGenerateSuccess();
        }
        
        // 关闭预览
        function closePreview() {
            document.getElementById('preview-area').classList.add('hidden');
        }
        
        // 绑定事件
        document.getElementById('generate-btn').addEventListener('click', generateCardCode);
        document.getElementById('auto-generate-btn').addEventListener('click', autoGenerate);
        document.getElementById('copy-btn').addEventListener('click', copyToClipboard);
        document.getElementById('clear-btn').addEventListener('click', clearInput);
        document.getElementById('preview-btn').addEventListener('click', showPreview);
        document.getElementById('close-preview-btn').addEventListener('click', closePreview);
        
        // 页面加载时自动生成一个卡密
        document.addEventListener('DOMContentLoaded', function() {
            if (!document.getElementById('card_code').value) {
                generateCardCode();
            }
        });

        // 变量点击插入
        document.querySelectorAll('code').forEach(el => {
            el.addEventListener('click', function() {
                const textarea = document.getElementById('content');
                const variable = this.textContent;
                const start = textarea.selectionStart;
                const end = textarea.selectionEnd;
                textarea.value = textarea.value.substring(0, start) + variable + textarea.value.substring(end);
                textarea.focus();
                textarea.selectionStart = textarea.selectionEnd = start + variable.length;
            });
        });

    </script>
                </div>
            </main>
        </div>
    </body>
    </html>
<?php
unset($message, $messageType, $cardCode, $content, $categoryId, $categories, $db, $pdo, $stmt);
?>
    