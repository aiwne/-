<?php
session_start();
// 检查是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    $_SESSION['error'] = '请先登录';
    header('Location: login.php');
    exit;
}

// 检查是否提供了卡密ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = '无效的卡密ID';
    header('Location: card_list.php');
    exit;
}

$card_id = intval($_GET['id']);
require '../db_connect.php';

// 获取卡密信息
try {
    $stmt = $pdo->prepare("SELECT * FROM cards WHERE id = :id");
    $stmt->bindParam(':id', $card_id, PDO::PARAM_INT);
    $stmt->execute();
    $card = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$card) {
        $_SESSION['error'] = '卡密不存在';
        header('Location: card_list.php');
        exit;
    }
} catch(PDOException $e) {
    $_SESSION['error'] = '获取卡密信息失败: ' . $e->getMessage();
    header('Location: card_list.php');
    exit;
}

$error = '';
$success = '';
$card_code = $card['card_code'];
$content = $card['content'];
$is_used = $card['is_used'];

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_code = trim($_POST['card_code']);
    $content = trim($_POST['content']);
    $is_used = isset($_POST['is_used']) ? 1 : 0;
    
    if (empty($card_code)) {
        $error = '请输入卡密';
    } elseif (empty($content)) {
        $error = '请输入卡密对应的内容';
    } else {
        try {
            // 检查卡密是否已存在（排除当前卡密）
            $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_code = :card_code AND id != :id");
            $stmt->bindParam(':card_code', $card_code);
            $stmt->bindParam(':id', $card_id, PDO::PARAM_INT);
            $stmt->execute();
            
            if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                $error = '该卡密已存在';
            } else {
                // 更新卡密信息
                $update_data = [
                    ':card_code' => $card_code,
                    ':content' => $content,
                    ':is_used' => $is_used,
                    ':id' => $card_id
                ];
                
                // 如果从未使用变为已使用，更新使用时间
                if ($is_used == 1 && $card['is_used'] == 0) {
                    $sql = "UPDATE cards SET card_code = :card_code, content = :content, is_used = :is_used, used_at = NOW() WHERE id = :id";
                } 
                // 如果从已使用变为未使用，清空使用时间
                elseif ($is_used == 0 && $card['is_used'] == 1) {
                    $sql = "UPDATE cards SET card_code = :card_code, content = :content, is_used = :is_used, used_at = NULL WHERE id = :id";
                } 
                // 其他情况不修改使用时间
                else {
                    $sql = "UPDATE cards SET card_code = :card_code, content = :content, is_used = :is_used WHERE id = :id";
                }
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($update_data);
                
                $_SESSION['success'] = '卡密更新成功';
                header('Location: card_list.php');
                exit;
            }
        } catch(PDOException $e) {
            $error = '更新卡密失败: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡密管理系统 - 编辑卡密</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <div class="bg-gray-800 text-white w-64 flex-shrink-0 hidden md:block">
            <div class="p-4 border-b border-gray-700">
                <h1 class="text-xl font-bold">卡密管理系统</h1>
            </div>
            <nav class="p-4 space-y-2">
                <a href="index.php" class="flex items-center px-4 py-2 rounded hover:bg-gray-700 transition duration-200">
                    <i class="fa fa-tachometer mr-3"></i> 仪表盘
                </a>
                <a href="card_list.php" class="flex items-center px-4 py-2 rounded bg-blue-600 text-white">
                    <i class="fa fa-key mr-3"></i> 卡密管理
                </a>
                <a href="add_card.php" class="flex items-center px-4 py-2 rounded hover:bg-gray-700 transition duration-200">
                    <i class="fa fa-plus-circle mr-3"></i> 添加卡密
                </a>
                <a href="logout.php" class="flex items-center px-4 py-2 rounded hover:bg-gray-700 transition duration-200 text-red-300 hover:text-red-100">
                    <i class="fa fa-sign-out mr-3"></i> 退出登录
                </a>
            </nav>
        </div>
        
        <!-- 主内容区 -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- 顶部导航 -->
            <header class="bg-white shadow-sm py-4 px-6">
                <div class="flex justify-between items-center">
                    <h2 class="text-xl font-semibold text-gray-800">编辑卡密</h2>
                    <div class="flex items-center">
                        <span class="text-gray-600 mr-4">欢迎，<?php echo $_SESSION['admin_username']; ?></span>
                        <button class="md:hidden text-gray-600 focus:outline-none">
                            <i class="fa fa-bars text-xl"></i>
                        </button>
                    </div>
                </div>
            </header>
            
            <!-- 内容区 -->
            <main class="flex-1 overflow-y-auto p-6">
                <div class="bg-white rounded-lg shadow overflow-hidden max-w-3xl mx-auto">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="font-semibold text-gray-800">卡密信息编辑</h3>
                    </div>
                    
                    <?php if ($error): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded m-6">
                        <i class="fa fa-exclamation-circle mr-2"></i><?php echo $error; ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="post" class="p-6 space-y-4">
                        <div>
                            <label for="card_code" class="block text-gray-700 mb-2">卡密</label>
                            <input type="text" id="card_code" name="card_code" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                                   value="<?php echo htmlspecialchars($card_code); ?>" required>
                        </div>
                        
                        <div>
                            <label for="content" class="block text-gray-700 mb-2">卡密内容</label>
                            <textarea id="content" name="content" rows="5"
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                      required><?php echo htmlspecialchars($content); ?></textarea>
                        </div>
                        
                        <div>
                            <label class="flex items-center">
                                <input type="checkbox" name="is_used" value="1" 
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                       <?php echo $is_used ? 'checked' : ''; ?>>
                                <span class="ml-2 block text-gray-700">标记为已使用</span>
                            </label>
                        </div>
                        
                        <div class="pt-4 border-t border-gray-200">
                            <button type="submit" 
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">
                                <i class="fa fa-save mr-2"></i>保存修改
                            </button>
                            <a href="card_list.php" 
                               class="ml-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md transition duration-300">
                                <i class="fa fa-arrow-left mr-2"></i>取消
                            </a>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
