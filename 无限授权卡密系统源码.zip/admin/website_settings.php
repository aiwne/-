<?php
/**
 * 网站设置管理页面
 * 允许管理员自定义网站标题、LOGO、温馨提示等内容
 */
require_once 'auth.php';
require_once '../db_connect.php';

$message = '';
$messageType = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        $pdo = $db->getPdo();
        
        // 获取表单数据
        $settings = [
            'site_title' => trim($_POST['site_title'] ?? ''),
            'site_logo_url' => trim($_POST['site_logo_url'] ?? ''),
            'warm_reminder_title' => trim($_POST['warm_reminder_title'] ?? ''),
            'warm_reminder_content' => trim($_POST['warm_reminder_content'] ?? ''),
            'warm_reminder_date' => trim($_POST['warm_reminder_date'] ?? ''),
            'footer_text' => trim($_POST['footer_text'] ?? ''),
            'verify_page_title' => trim($_POST['verify_page_title'] ?? ''),
            'verify_page_subtitle' => trim($_POST['verify_page_subtitle'] ?? '')
        ];
        
        // 验证必填字段
        if (empty($settings['site_title'])) {
            throw new Exception('网站标题不能为空');
        }
        
        if (empty($settings['warm_reminder_title'])) {
            throw new Exception('温馨提示标题不能为空');
        }
        
        if (empty($settings['warm_reminder_content'])) {
            throw new Exception('温馨提示内容不能为空');
        }
        
        // 开始事务
        $pdo->beginTransaction();
        
        // 保存设置到数据库
        foreach ($settings as $key => $value) {
            // 先删除现有设置
            $stmt = $pdo->prepare("DELETE FROM settings WHERE setting_key = ?");
            $stmt->execute([$key]);
            
            // 插入新设置
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
            $stmt->execute([$key, $value]);
        }
        
        // 提交事务
        $pdo->commit();
        
        $message = '网站设置保存成功！';
        $messageType = 'success';
        
    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $message = '保存失败：' . $e->getMessage();
        $messageType = 'error';
    }
}

// 获取当前设置
$currentSettings = [
    'site_title' => '卡密验证系统',
    'site_logo_url' => '',
    'warm_reminder_title' => '温馨提示！',
    'warm_reminder_content' => '请保管好卡密内容，确保保存妥当，在此感谢你的关顾[爱心]',
    'warm_reminder_date' => date('Y-m-d'),
    'footer_text' => '© 2025 卡密验证系统 - by Lucky 版权所有 1.0',
    'verify_page_title' => '卡密验证',
    'verify_page_subtitle' => '以下是你的卡密信息'
];

try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 从数据库读取设置
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        'site_title', 'site_logo_url', 'warm_reminder_title', 'warm_reminder_content',
        'warm_reminder_date', 'footer_text', 'verify_page_title', 'verify_page_subtitle'
    ]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($rows as $row) {
        if (isset($currentSettings[$row['setting_key']])) {
            $currentSettings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch (Exception $e) {
    error_log("读取网站设置失败：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网站设置 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .mobile-menu-btn {
                @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 - 移动端默认隐藏，桌面端显示 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope mr-3"></i>邮箱配置
                    </a>
                    <a href="website_settings.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cog mr-3"></i>网站设置
                    </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区域 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
           
                <h2 class="text-2xl font-semibold text-gray-800 mb-6">网站设置</h2>

                <?php if (!empty($message)): ?>
                    <div class="mb-6 p-4 rounded-md <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                        <i class="fa <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-8">
                    <!-- 基本信息设置 -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
                            <i class="fa fa-info-circle mr-2 text-blue-600"></i>基本信息
                        </h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="site_title" class="block text-sm font-medium text-gray-700 mb-2">网站标题 *</label>
                                <input type="text" id="site_title" name="site_title" 
                                       value="<?php echo htmlspecialchars($currentSettings['site_title']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                <p class="text-xs text-gray-500 mt-1">显示在浏览器标题栏和页面头部</p>
                            </div>
                            
                            <div>
                                <label for="site_logo_url" class="block text-sm font-medium text-gray-700 mb-2">LOGO图片URL</label>
                                <input type="url" id="site_logo_url" name="site_logo_url" 
                                       value="<?php echo htmlspecialchars($currentSettings['site_logo_url']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <p class="text-xs text-gray-500 mt-1">支持在线图片链接，留空则使用默认图标</p>
                            </div>
                        </div>
                    </div>

                    <!-- 验证页面设置 -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
                            <i class="fa fa-check-circle mr-2 text-green-600"></i>验证页面设置
                        </h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="verify_page_title" class="block text-sm font-medium text-gray-700 mb-2">验证页面标题</label>
                                <input type="text" id="verify_page_title" name="verify_page_title" 
                                       value="<?php echo htmlspecialchars($currentSettings['verify_page_title']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label for="verify_page_subtitle" class="block text-sm font-medium text-gray-700 mb-2">验证页面副标题</label>
                                <input type="text" id="verify_page_subtitle" name="verify_page_subtitle" 
                                       value="<?php echo htmlspecialchars($currentSettings['verify_page_subtitle']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                    </div>

                    <!-- 温馨提示设置 -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
                            <i class="fa fa-bullhorn mr-2 text-yellow-600"></i>温馨提示设置
                        </h3>
                        
                        <div class="space-y-6">
                            <div>
                                <label for="warm_reminder_title" class="block text-sm font-medium text-gray-700 mb-2">温馨提示标题 *</label>
                                <input type="text" id="warm_reminder_title" name="warm_reminder_title" 
                                       value="<?php echo htmlspecialchars($currentSettings['warm_reminder_title']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            </div>
                            
                            <div>
                                <label for="warm_reminder_content" class="block text-sm font-medium text-gray-700 mb-2">温馨提示内容 *</label>
                                <textarea id="warm_reminder_content" name="warm_reminder_content" rows="4"
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" required><?php echo htmlspecialchars($currentSettings['warm_reminder_content']); ?></textarea>
                                <p class="text-xs text-gray-500 mt-1">支持HTML标签，如 [爱心] 等特殊字符</p>
                            </div>
                            
                            <div>
                                <label for="warm_reminder_date" class="block text-sm font-medium text-gray-700 mb-2">发布时间</label>
                                <input type="date" id="warm_reminder_date" name="warm_reminder_date" 
                                       value="<?php echo htmlspecialchars($currentSettings['warm_reminder_date']); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                    </div>

                    <!-- 页脚设置 -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
                            <i class="fa fa-copyright mr-2 text-gray-600"></i>页脚设置
                        </h3>
                        
                        <div>
                            <label for="footer_text" class="block text-sm font-medium text-gray-700 mb-2">页脚文字</label>
                            <input type="text" id="footer_text" name="footer_text" 
                                   value="<?php echo htmlspecialchars($currentSettings['footer_text']); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <p class="text-xs text-gray-500 mt-1">显示在页面底部的版权信息</p>
                        </div>
                    </div>

                    <!-- 预览区域 -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
                            <i class="fa fa-eye mr-2 text-purple-600"></i>预览效果
                        </h3>
                        
                        <div class="bg-gray-50 border border-gray-200 rounded-lg p-6">
                            <div class="text-center mb-6">
                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-500 mb-4">
                                    <i class="fa fa-key text-3xl"></i>
                                </div>
                                <h2 class="text-2xl font-bold text-gray-800" id="preview-title"><?php echo htmlspecialchars($currentSettings['verify_page_title']); ?></h2>
                                <p class="text-gray-600 mt-1" id="preview-subtitle"><?php echo htmlspecialchars($currentSettings['verify_page_subtitle']); ?></p>
                            </div>
                            
                            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                                <h3 class="font-semibold text-blue-800 flex items-center mb-2" id="preview-reminder-title">
                                    <i class="fa fa-bullhorn mr-2"></i><?php echo htmlspecialchars($currentSettings['warm_reminder_title']); ?>
                                </h3>
                                <p class="text-blue-700 text-sm mb-2" id="preview-reminder-content">
                                    <?php echo htmlspecialchars($currentSettings['warm_reminder_content']); ?>
                                </p>
                                <p class="text-xs text-blue-600" id="preview-reminder-date">
                                    发布时间：<?php echo htmlspecialchars($currentSettings['warm_reminder_date']); ?>
                                </p>
                            </div>
                            
                            <div class="text-center text-sm text-gray-500" id="preview-footer">
                                <?php echo htmlspecialchars($currentSettings['footer_text']); ?>
                            </div>
                        </div>
                    </div>

                    <!-- 提交按钮 -->
                    <div class="flex justify-end space-x-4">
                        <button type="button" onclick="resetForm()" 
                                class="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition duration-200">
                            <i class="fa fa-undo mr-2"></i>重置
                        </button>
                        <button type="submit" 
                                class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200">
                            <i class="fa fa-save mr-2"></i>保存设置
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
        // 侧边栏切换功能
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');

            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('active');
                document.body.classList.toggle('overflow-hidden');
            }

            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化时自动调整
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) {
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.remove('active');
                    document.body.classList.remove('overflow-hidden');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('sidebar-hidden');
                }
            });
        });

        // 实时预览功能
        function updatePreview() {
            document.getElementById('preview-title').textContent = document.getElementById('verify_page_title').value;
            document.getElementById('preview-subtitle').textContent = document.getElementById('verify_page_subtitle').value;
            document.getElementById('preview-reminder-title').innerHTML = '<i class="fa fa-bullhorn mr-2"></i>' + document.getElementById('warm_reminder_title').value;
            document.getElementById('preview-reminder-content').textContent = document.getElementById('warm_reminder_content').value;
            document.getElementById('preview-reminder-date').textContent = '发布时间：' + document.getElementById('warm_reminder_date').value;
            document.getElementById('preview-footer').textContent = document.getElementById('footer_text').value;
        }

        // 为所有输入框添加实时预览
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = ['verify_page_title', 'verify_page_subtitle', 'warm_reminder_title', 
                          'warm_reminder_content', 'warm_reminder_date', 'footer_text'];
            
            inputs.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    element.addEventListener('input', updatePreview);
                }
            });
        });

        // 重置表单
        function resetForm() {
            if (confirm('确定要重置所有设置吗？')) {
                document.querySelector('form').reset();
                updatePreview();
            }
        }
    </script>
</body>
</html>