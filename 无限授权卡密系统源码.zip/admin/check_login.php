<?php
session_start();
require_once '../db_connect.php'; // 引入数据库连接类

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // 验证输入
    if (empty($username) || empty($password)) {
        $message = "请输入用户名和密码";
    } else {
        try {
            // 获取数据库连接
            $db = Database::getInstance();
            $pdo = $db->getPdo();

            // 关键检查：确保PDO对象存在
            if (!$pdo) {
                throw new Exception("数据库连接失败，无法获取PDO实例");
            }

            // 查询管理员信息
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = :username LIMIT 1");
            $stmt->execute([':username' => $username]);
            $admin = $stmt->fetch();

            // 验证管理员和密码
            if ($admin && password_verify($password, $admin['password'])) {
                // 登录成功，记录会话
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_id'] = $admin['id'];
                
                // 重定向到后台首页
                header('Location: dashboard.php');
                exit;
            } else {
                $message = "用户名或密码不正确";
            }
        } catch (PDOException $e) {
            // 数据库错误处理
            $message = "数据库错误：" . $e->getMessage();
            // 记录详细错误日志（生产环境使用）
            error_log("登录验证数据库错误：" . $e->getMessage() . " 堆栈跟踪：" . $e->getTraceAsString());
        } catch (Exception $e) {
            // 其他错误处理
            $message = "系统错误：" . $e->getMessage();
            error_log("登录验证错误：" . $e->getMessage() . " 堆栈跟踪：" . $e->getTraceAsString());
        }
    }

    // 错误信息存入会话，跳转回登录页
    $_SESSION['login_error'] = $message;
    header('Location: login.php');
    exit;
} else {
    // 非POST请求直接跳转
    header('Location: login.php');
    exit;
}
?>
    