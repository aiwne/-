<?php
require_once '../includes/admin_auth.php';
require_once '../db_connect.php';

// 检查管理员权限
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 处理表单提交
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 接收并验证表单数据
    $data = [
        'smtp_host' => trim($_POST['smtp_host'] ?? ''),
        'smtp_port' => (int)($_POST['smtp_port'] ?? 587),
        'smtp_encryption' => $_POST['smtp_encryption'] ?? 'tls',
        'smtp_username' => trim($_POST['smtp_username'] ?? ''),
        'smtp_password' => trim($_POST['smtp_password'] ?? ''),
        'from_email' => trim($_POST['from_email'] ?? ''),
        'from_name' => trim($_POST['from_name'] ?? ''),
        'admin_notify_email' => trim($_POST['admin_notify_email'] ?? '')
    ];

    // 简单验证
    if (empty($data['smtp_host']) || empty($data['smtp_username']) || empty($data['from_email']) || empty($data['admin_notify_email'])) {
        $message = "请填写所有必填项";
        $messageType = 'error';
    } elseif (!filter_var($data['from_email'], FILTER_VALIDATE_EMAIL) || !filter_var($data['admin_notify_email'], FILTER_VALIDATE_EMAIL)) {
        $message = "请输入有效的邮箱地址";
        $messageType = 'error';
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getPdo();
            
            // 检查是否有配置记录，有则更新，无则插入
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM email_settings");
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $stmt = $pdo->prepare("
                    UPDATE email_settings SET 
                        smtp_host = :smtp_host,
                        smtp_port = :smtp_port,
                        smtp_encryption = :smtp_encryption,
                        smtp_username = :smtp_username,
                        smtp_password = :smtp_password,
                        from_email = :from_email,
                        from_name = :from_name,
                        admin_notify_email = :admin_notify_email,
                        updated_at = NOW()
                    LIMIT 1
                ");
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO email_settings (
                        smtp_host, smtp_port, smtp_encryption, smtp_username, 
                        smtp_password, from_email, from_name, admin_notify_email, updated_at
                    ) VALUES (
                        :smtp_host, :smtp_port, :smtp_encryption, :smtp_username,
                        :smtp_password, :from_email, :from_name, :admin_notify_email, NOW()
                    )
                ");
            }
            
            $stmt->execute($data);
            $message = "邮箱配置保存成功";
            $messageType = 'success';
        } catch (PDOException $e) {
            $message = "保存失败: " . $e->getMessage();
            $messageType = 'error';
            error_log("邮箱配置保存错误: " . $e->getMessage());
        }
    }
}

// 获取当前配置
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT * FROM email_settings LIMIT 1");
    $emailConfig = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 如果没有配置，设置默认值
    if (!$emailConfig) {
        $emailConfig = [
            'smtp_host' => 'smtp.qq.com',
            'smtp_port' => 587,
            'smtp_encryption' => 'tls',
            'smtp_username' => '',
            'smtp_password' => '',
            'from_email' => '',
            'from_name' => '卡密验证系统',
            'admin_notify_email' => ''
        ];
    }
} catch (PDOException $e) {
    $message = "获取配置失败: " . $e->getMessage();
    $messageType = 'error';
    $emailConfig = [];
    error_log("邮箱配置获取错误: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>邮箱配置 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .mobile-menu-btn {
                @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 - 移动端默认隐藏，桌面端显示 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                   <a href="email_settings.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">邮箱配置</h2>
                <p class="mt-1 text-gray-600">配置系统邮件发送参数，用于卡密使用通知等功能</p>
            </div>

            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                         ($messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 
                             ($messageType === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle');
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 邮箱配置表单 -->
            <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-2xl">
                <div class="px-4 py-5 sm:px-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">邮箱参数设置</h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">
                        配置SMTP服务器信息，用于系统发送邮件通知
                    </p>
                </div>
                
                <div class="border-t border-gray-200 px-4 py-5 sm:p-6">
                    <form method="post" action="email_settings.php" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                            <div class="col-span-1 md:col-span-2">
                                <label for="smtp_host" class="block text-gray-700 font-medium mb-2">
                                    SMTP服务器 <span class="text-red-500">*</span>
                                </label>
                                <input type="text" id="smtp_host" name="smtp_host" 
                                       value="<?php echo htmlspecialchars($emailConfig['smtp_host'] ?? ''); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="text-gray-500 text-sm mt-1">例如: smtp.qq.com, smtp.gmail.com</p>
                            </div>

                            <div>
                                <label for="smtp_port" class="block text-gray-700 font-medium mb-2">
                                    SMTP端口 <span class="text-red-500">*</span>
                                </label>
                                <input type="number" id="smtp_port" name="smtp_port" 
                                       value="<?php echo htmlspecialchars($emailConfig['smtp_port'] ?? '587'); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="text-gray-500 text-sm mt-1">通常为: 587(TLS), 465(SSL)</p>
                            </div>

                            <div>
                                <label for="smtp_encryption" class="block text-gray-700 font-medium mb-2">
                                    加密方式 <span class="text-red-500">*</span>
                                </label>
                                <select id="smtp_encryption" name="smtp_encryption" 
                                        class="form-select w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        required>
                                    <option value="tls" <?php echo (isset($emailConfig['smtp_encryption']) && $emailConfig['smtp_encryption'] === 'tls') ? 'selected' : ''; ?>>TLS</option>
                                    <option value="ssl" <?php echo (isset($emailConfig['smtp_encryption']) && $emailConfig['smtp_encryption'] === 'ssl') ? 'selected' : ''; ?>>SSL</option>
                                    <option value="none" <?php echo (isset($emailConfig['smtp_encryption']) && $emailConfig['smtp_encryption'] === 'none') ? 'selected' : ''; ?>>无加密</option>
                                </select>
                            </div>

                            <div class="col-span-1 md:col-span-2">
                                <label for="smtp_username" class="block text-gray-700 font-medium mb-2">
                                    SMTP用户名 <span class="text-red-500">*</span>
                                </label>
                                <input type="email" id="smtp_username" name="smtp_username" 
                                       value="<?php echo htmlspecialchars($emailConfig['smtp_username'] ?? ''); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="text-gray-500 text-sm mt-1">通常为发件人邮箱地址</p>
                            </div>

                            <div class="col-span-1 md:col-span-2">
                                <label for="smtp_password" class="block text-gray-700 font-medium mb-2">
                                    SMTP密码/授权码 <span class="text-red-500">*</span>
                                </label>
                                <input type="password" id="smtp_password" name="smtp_password" 
                                       value="<?php echo htmlspecialchars($emailConfig['smtp_password'] ?? ''); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="text-gray-500 text-sm mt-1">通常为邮箱第三方登录授权码，而非登录密码</p>
                            </div>

                            <div class="col-span-1 md:col-span-2">
                                <label for="from_email" class="block text-gray-700 font-medium mb-2">
                                    发件人邮箱 <span class="text-red-500">*</span>
                                </label>
                                <input type="email" id="from_email" name="from_email" 
                                       value="<?php echo htmlspecialchars($emailConfig['from_email'] ?? ''); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                            </div>

                            <div class="col-span-1 md:col-span-2">
                                <label for="from_name" class="block text-gray-700 font-medium mb-2">
                                    发件人名称
                                </label>
                                <input type="text" id="from_name" name="from_name" 
                                       value="<?php echo htmlspecialchars($emailConfig['from_name'] ?? '卡密验证系统'); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <p class="text-gray-500 text-sm mt-1">显示在收件人邮件中的发件人名称</p>
                            </div>

                            <div class="col-span-1 md:col-span-2">
                                <label for="admin_notify_email" class="block text-gray-700 font-medium mb-2">
                                    管理员通知邮箱 <span class="text-red-500">*</span>
                                </label>
                                <input type="email" id="admin_notify_email" name="admin_notify_email" 
                                       value="<?php echo htmlspecialchars($emailConfig['admin_notify_email'] ?? ''); ?>"
                                       class="form-input w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none transition-shadow focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <p class="text-gray-500 text-sm mt-1">接收卡密使用通知的邮箱地址</p>
                            </div>
                        </div>

                        <div class="flex justify-end gap-3 pt-4 border-t border-gray-200">
                            <a href="dashboard.php" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                <i class="fa fa-arrow-left mr-1"></i>返回
                            </a>
                            <button type="submit" 
                                    class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <i class="fa fa-save mr-1"></i>保存配置
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏切换功能
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            // 切换侧边栏显示状态
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('active');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化时自动调整
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) { // lg断点
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.remove('active');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('sidebar-hidden');
                }
            });

            // 表单自动聚焦
            document.getElementById('smtp_host').focus();
        });
    </script>
            </div>
        </main>
    </div>
</body>
</html>
<?php
unset($emailConfig, $message, $messageType, $db, $pdo, $stmt);
?>