<?php
/**
 * 通用侧边栏组件
 * 用于所有管理后台页面
 */
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!-- 移动端菜单按钮 -->
<button id="mobileMenuBtn" class="mobile-menu-btn">
    <i class="fa fa-bars"></i>
</button>

<!-- 侧边栏 -->
<aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
    <div class="h-full pb-4">
        <nav class="px-2 space-y-1">
            <a href="dashboard.php" class="sidebar-menu-link <?php echo $currentPage === 'dashboard.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-tachometer mr-3"></i>仪表盘
            </a>
            <a href="cards_list.php" class="sidebar-menu-link <?php echo $currentPage === 'cards_list.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-list-alt mr-3"></i>卡密管理
            </a>
            <a href="card_search.php" class="sidebar-menu-link <?php echo $currentPage === 'card_search.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-search mr-3"></i>卡密查询
            </a>
            <a href="card_add.php" class="sidebar-menu-link <?php echo $currentPage === 'card_add.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-plus-circle mr-3"></i>添加卡密
            </a>
            <a href="card_upload.php" class="sidebar-menu-link <?php echo $currentPage === 'card_upload.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-upload mr-3"></i>卡密上传
            </a>
            <a href="card_export.php" class="sidebar-menu-link <?php echo $currentPage === 'card_export.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-download mr-3"></i>卡密导出
            </a>
            <a href="categories.php" class="sidebar-menu-link <?php echo $currentPage === 'categories.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-tags mr-3"></i>分类管理
            </a>
            <a href="batch_generate.php" class="sidebar-menu-link <?php echo $currentPage === 'batch_generate.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cubes mr-3"></i>批量生成
            </a>
            <a href="bark_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'bark_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-bell mr-3"></i>Bark通知设置
            </a>
            <a href="email_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'email_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
            </a>
            <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
            <a href="profile.php" class="sidebar-menu-link <?php echo $currentPage === 'profile.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-user mr-3"></i>个人设置
            </a>
        </nav>
    </div>
</aside>

<!-- 侧边栏遮罩 -->
<div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"></div>
