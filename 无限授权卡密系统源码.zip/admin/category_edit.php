<?php
/**
 * 分类添加/编辑页面
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化变量
$message = '';
$messageType = '';
$id = 0;
$name = '';
$description = '';
$isEdit = false;

// 检查是否是编辑模式
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $isEdit = true;
    
    try {
        $db = Database::getInstance();
        $pdo = $db->getPdo();
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $category = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$category) {
            $message = "分类不存在或已被删除";
            $messageType = 'error';
            $isEdit = false;
        } else {
            $name = $category['name'];
            $description = $category['description'];
        }
    } catch (PDOException $e) {
        $message = "获取分类信息失败: " . $e->getMessage();
        $messageType = 'error';
        error_log("获取分类信息错误: " . $e->getMessage());
    }
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    
    if (empty($name)) {
        $message = "请输入分类名称";
        $messageType = 'warning';
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getPdo();
            
            // 检查分类名称是否已存在（排除当前编辑的分类）
            $checkStmt = $pdo->prepare("
                SELECT id FROM categories 
                WHERE name = :name 
                " . ($isEdit ? "AND id != :id" : "") . " 
                LIMIT 1
            ");
            $checkParams = [':name' => $name];
            if ($isEdit) {
                $checkParams[':id'] = $id;
            }
            $checkStmt->execute($checkParams);
            
            if ($checkStmt->fetch(PDO::FETCH_ASSOC)) {
                $message = "该分类名称已存在，请更换";
                $messageType = 'warning';
            } else {
                if ($isEdit) {
                    // 更新分类
                    $stmt = $pdo->prepare("
                        UPDATE categories 
                        SET name = :name, 
                            description = :description,
                            updated_at = NOW()
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':name' => $name,
                        ':description' => $description,
                        ':id' => $id
                    ]);
                    $message = "分类更新成功";
                } else {
                    // 添加新分类
                    $stmt = $pdo->prepare("
                        INSERT INTO categories (name, description, created_at, updated_at)
                        VALUES (:name, :description, NOW(), NOW())
                    ");
                    $stmt->execute([
                        ':name' => $name,
                        ':description' => $description
                    ]);
                    $message = "分类添加成功";
                    // 清空表单，方便继续添加
                    $name = '';
                    $description = '';
                }
                $messageType = 'success';
            }
        } catch (PDOException $e) {
            $message = ($isEdit ? "更新分类" : "添加分类") . "失败: " . $e->getMessage();
            $messageType = 'error';
            error_log(($isEdit ? "更新分类" : "添加分类") . "错误: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $isEdit ? '编辑分类' : '添加分类'; ?> - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .mobile-menu-btn {
                @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 - 移动端默认隐藏，桌面端显示 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="categories.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto p-6 lg:pl-64 transition-all duration-300">
            <div class="mb-6">
                <h2 class="text-2xl font-semibold text-gray-800"><?php echo $isEdit ? '编辑分类' : '添加新分类'; ?></h2>
                <p class="mt-1 text-gray-600">请填写分类信息，带 <span class="text-red-500">*</span> 为必填项</p>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                         ($messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                ?> fade-in">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 
                             ($messageType === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle');
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($isEdit && $messageType === 'error'): ?>
                <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-2xl p-6 text-center">
                    <a href="categories.php" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                        <i class="fa fa-arrow-left mr-2"></i>返回分类列表
                    </a>
                </div>
            <?php else: ?>
                <!-- 分类表单 -->
                <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-2xl">
                    <div class="px-4 py-5 sm:p-6">
                        <form method="post">
                            <div class="mb-4">
                                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">
                                    分类名称 <span class="text-red-500">*</span>
                                </label>
                                <input type="text" name="name" id="name" 
                                       value="<?php echo htmlspecialchars($name); ?>"
                                       placeholder="请输入分类名称"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <p class="mt-1 text-sm text-gray-500">分类名称用于区分不同类型的卡密，如"月度会员"、"年度会员"等</p>
                            </div>
                            
                            <div class="mb-4">
                                <label for="description" class="block text-sm font-medium text-gray-700 mb-1">
                                    分类描述
                                </label>
                                <textarea name="description" id="description" rows="3" 
                                          placeholder="请输入分类描述（可选）"
                                          class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($description); ?></textarea>
                                <p class="mt-1 text-sm text-gray-500">描述该分类的用途或包含的卡密类型</p>
                            </div>
                            
                            <div class="flex justify-end gap-3 pt-4 border-t border-gray-200">
                                <a href="categories.php" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                    取消
                                </a>
                                <button type="submit" class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <i class="fa fa-save mr-1"></i><?php echo $isEdit ? '更新分类' : '保存分类'; ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏切换功能
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            // 切换侧边栏显示状态
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('active');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化时自动调整
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) { // lg断点
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.remove('active');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('sidebar-hidden');
                }
            });

            // 表单自动聚焦
            document.getElementById('name').focus();
        });
    </script>
</body>
</html>
<?php
unset($message, $messageType, $id, $name, $description, $isEdit, $db, $pdo, $stmt, $checkStmt);
?>
    