// 卡密批量操作功能处理
(function() {
    // 确保在浏览器环境中运行
    if (typeof window === 'undefined' || typeof document === 'undefined') {
        console.error('此脚本只能在浏览器环境中运行');
        return;
    }

    // 防止重复初始化
    if (window.cardBatchActionsInitialized) {
        console.log('卡密批量操作脚本已初始化，避免重复执行');
        return;
    }
    window.cardBatchActionsInitialized = true;

    // 等待DOM完全加载
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // 初始化函数
    function init() {
        console.log('卡密批量操作脚本初始化...');
        
        // 获取所有必要元素
        const elements = {
            selectAll: document.getElementById('selectAll'),
            selectedCount: document.getElementById('selectedCount')?.querySelector('span'),
            copySelected: document.getElementById('copySelected'),
            editSelected: document.getElementById('editSelected'),
            deleteSelected: document.getElementById('deleteSelected'),
            batchForm: document.getElementById('batchDeleteForm'),
            batchIdsInput: document.getElementById('batchDeleteIds'),
            filterForm: document.getElementById('filterForm'),
            copyNotify: document.getElementById('copyNotify'),
            notifyText: document.getElementById('notifyText')
        };

        // 检查关键元素是否存在
        checkRequiredElements(elements);

        // 初始化状态
        updateSelectedState(elements);

        // 绑定事件处理程序
        bindEvents(elements);
        
        console.log('卡密批量操作脚本初始化完成');
    }

    // 检查必要元素是否存在
    function checkRequiredElements(elements) {
        const required = [
            { element: elements.selectAll, name: '全选复选框(#selectAll)' },
            { element: elements.copySelected, name: '复制选中按钮(#copySelected)' },
            { element: elements.deleteSelected, name: '删除选中按钮(#deleteSelected)' },
            { element: elements.batchForm, name: '批量删除表单(#batchDeleteForm)' },
            { element: elements.batchIdsInput, name: '批量删除ID输入框(#batchDeleteIds)' }
        ];

        required.forEach(item => {
            if (!item.element) {
                console.error(`关键元素缺失: ${item.name}，相关功能可能无法正常工作`);
            }
        });
    }

    // 只获取"卡密项"的复选框（通过 data-type="card-item" 过滤）
    // 只获取当前可见的复选框（桌面端或移动端）
    function getCardCheckboxes() {
        // 获取所有带有 data-type="card-item" 的复选框
        const allCheckboxes = document.querySelectorAll('input.card-checkbox[data-type="card-item"]');
        
        // 过滤出当前可见的复选框
        return Array.from(allCheckboxes).filter(checkbox => {
            const rect = checkbox.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0; // 可见元素
        });
    }

    // 绑定所有事件
    function bindEvents(elements) {
        // 全选/取消全选事件
        if (elements.selectAll) {
            elements.selectAll.removeEventListener('change', handleSelectAllChange);
            elements.selectAll.addEventListener('change', function(e) {
                handleSelectAllChange(e, elements);
            });
        }

        // 单个复选框事件 - 使用事件委托确保动态元素也能响应
        document.removeEventListener('change', handleCheckboxChange);
        document.addEventListener('change', function(e) {
            handleCheckboxChange(e, elements);
        });

        // 批量复制事件
        if (elements.copySelected) {
            elements.copySelected.removeEventListener('click', handleBatchCopyClick);
            elements.copySelected.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                handleBatchCopyClick(elements);
            });
        }

        // 批量删除事件
        if (elements.deleteSelected) {
            elements.deleteSelected.removeEventListener('click', handleBatchDeleteClick);
            elements.deleteSelected.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                handleBatchDeleteClick(elements);
            });
        }

        // 单个复制事件
        document.removeEventListener('click', handleSingleCopyClick);
        document.addEventListener('click', function(e) {
            handleSingleCopyClick(e, elements);
        });

        // 单个删除确认事件
        document.removeEventListener('click', handleSingleDeleteClick);
        document.addEventListener('click', function(e) {
            handleSingleDeleteClick(e);
        });

        // 筛选表单提交处理
        if (elements.filterForm) {
            elements.filterForm.removeEventListener('submit', handleFilterSubmit);
            elements.filterForm.addEventListener('submit', handleFilterSubmit);
        }
    }

    // 更新选中状态 - 只统计“卡密项”的复选框
    function updateSelectedState(elements) {
        // 获取所有“卡密项”复选框
        const checkboxes = getCardCheckboxes();
        const totalCount = checkboxes.length;
        
        // 计算选中的数量（只统计“卡密项”复选框）
        const checkedCount = Array.from(checkboxes).filter(checkbox => checkbox.checked).length;

        console.log(`卡密总数: ${totalCount}, 选中数量: ${checkedCount}`);

        // 更新计数显示
        if (elements.selectedCount) {
            elements.selectedCount.textContent = checkedCount;
        }

        // 更新按钮状态
        const isEnabled = checkedCount > 0;

        // 更新复制按钮状态
        if (elements.copySelected) {
            elements.copySelected.disabled = !isEnabled;
            if (isEnabled) {
                elements.copySelected.classList.remove('opacity-50', 'cursor-not-allowed');
            } else {
                elements.copySelected.classList.add('opacity-50', 'cursor-not-allowed');
            }
        }

        // 更新编辑按钮状态
        if (elements.editSelected) {
            elements.editSelected.disabled = !isEnabled;
            if (isEnabled) {
                elements.editSelected.classList.remove('opacity-50', 'cursor-not-allowed');
            } else {
                elements.editSelected.classList.add('opacity-50', 'cursor-not-allowed');
            }
        }

        // 更新删除按钮状态
        if (elements.deleteSelected) {
            elements.deleteSelected.disabled = !isEnabled;
            if (isEnabled) {
                elements.deleteSelected.classList.remove('opacity-50', 'cursor-not-allowed');
            } else {
                elements.deleteSelected.classList.add('opacity-50', 'cursor-not-allowed');
            }
        }

        // 更新全选框状态
        if (elements.selectAll && totalCount > 0) {
            const allChecked = checkedCount === totalCount;
            if (elements.selectAll.checked !== allChecked) {
                elements.selectAll.removeEventListener('change', handleSelectAllChange);
                elements.selectAll.checked = allChecked;
                elements.selectAll.addEventListener('change', function(e) {
                    handleSelectAllChange(e, elements);
                });
            }
        }
    }

    // 处理全选/取消全选变更 - 只操作“卡密项”的复选框
    function handleSelectAllChange(e, elements) {
        e.preventDefault();
        const isChecked = e.target.checked;
        const checkboxes = getCardCheckboxes(); // 只操作“卡密项”复选框
        
        checkboxes.forEach(checkbox => {
            if (checkbox.checked !== isChecked) {
                const tempHandler = function() {};
                checkbox.removeEventListener('change', tempHandler);
                checkbox.checked = isChecked;
                checkbox.addEventListener('change', tempHandler);
            }
        });
        
        updateSelectedState(elements);
    }

    // 处理单个复选框变更
    function handleCheckboxChange(e, elements) {
        if (e.target && e.target.classList.contains('card-checkbox') && e.target.dataset.type === 'card-item') {
            updateSelectedState(elements);
        }
    }

    // 显示复制通知
    function showCopyNotify(elements, text = '复制成功') {
        if (!elements.copyNotify || !elements.notifyText) {
            alert(text);
            return;
        }

        elements.notifyText.textContent = text;
        elements.copyNotify.classList.add('show');

        if (window.copyNotifyTimer) {
            clearTimeout(window.copyNotifyTimer);
        }

        window.copyNotifyTimer = setTimeout(() => {
            elements.copyNotify.classList.remove('show');
        }, 2000);
    }

    // 处理单个复制点击
    function handleSingleCopyClick(e, elements) {
        const copyBtn = e.target.closest('.copy-single');
        if (copyBtn) {
            e.preventDefault();
            e.stopPropagation();
            
            const code = copyBtn.getAttribute('data-code');
            if (!code) {
                showCopyNotify(elements, '复制失败：卡密为空');
                return;
            }

            if (navigator.clipboard) {
                navigator.clipboard.writeText(code)
                    .then(() => {
                        showCopyNotify(elements, '复制成功');
                    })
                    .catch(err => {
                        console.error('复制失败:', err);
                        fallbackCopy(elements, code);
                    });
            } else {
                fallbackCopy(elements, code);
            }
        }
    }

    // 处理批量复制点击
    function handleBatchCopyClick(elements) {
        const checkboxes = getCardCheckboxes();
        const checkedItems = Array.from(checkboxes).filter(checkbox => checkbox.checked);
        
        if (checkedItems.length === 0) {
            showCopyNotify(elements, '请先选择要复制的卡密');
            return;
        }

        const codeSet = new Set();
        checkedItems.forEach(item => {
            const code = item.getAttribute('data-code');
            if (code) codeSet.add(code);
        });
        
        const codes = Array.from(codeSet);

        if (codes.length > 0) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(codes.join('\n'))
                    .then(() => {
                        showCopyNotify(elements, `成功复制 ${codes.length} 个卡密`);
                    })
                    .catch(err => {
                        console.error('批量复制失败:', err);
                        fallbackCopy(elements, codes.join('\n'));
                    });
            } else {
                fallbackCopy(elements, codes.join('\n'));
            }
        }
    }

    // 复制功能降级处理
    function fallbackCopy(elements, text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.top = '-999px';
        textarea.style.left = '-999px';
        document.body.appendChild(textarea);

        textarea.select();
        textarea.setSelectionRange(0, 99999);

        try {
            const successful = document.execCommand('copy');
            showCopyNotify(elements, successful ? '复制成功' : '复制失败，请手动复制');
        } catch (err) {
            console.error('复制失败:', err);
            showCopyNotify(elements, '复制失败，请手动复制');
        } finally {
            document.body.removeChild(textarea);
        }
    }

    // 处理批量删除点击
    function handleBatchDeleteClick(elements) {
        const checkboxes = getCardCheckboxes();
        const checkedItems = Array.from(checkboxes).filter(checkbox => checkbox.checked);
        
        if (checkedItems.length === 0) {
            alert('请先选择要删除的卡密');
            return;
        }

        const ids = Array.from(new Set(
            checkedItems.map(item => item.getAttribute('data-id')).filter(Boolean)
        ));

        if (ids.length > 0) {
            if (confirm(`确定要删除选中的 ${ids.length} 个卡密吗？此操作不可恢复。`)) {
                if (elements.batchIdsInput && elements.batchForm) {
                    elements.batchIdsInput.value = ids.join(',');
                    elements.batchForm.submit();
                } else {
                    console.error('批量删除表单元素缺失');
                    alert('删除功能异常，请刷新页面重试');
                }
            }
        }
    }

    // 处理单个删除确认
    function handleSingleDeleteClick(e) {
        const deleteLink = e.target.closest('.delete-single');
        if (deleteLink) {
            if (!confirm('确定要删除该卡密吗？此操作不可恢复。')) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        }
        return true;
    }

    // 处理筛选表单提交
    function handleFilterSubmit(e) {
        let pageInput = this.querySelector('input[name="page"]');
        if (!pageInput) {
            pageInput = document.createElement('input');
            pageInput.type = 'hidden';
            pageInput.name = 'page';
            this.appendChild(pageInput);
        }
        pageInput.value = '1';
    }
})();
    