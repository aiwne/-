<?php
/**
 * 后台权限验证
 * 所有需要登录才能访问的后台页面都应包含此文件
 */
session_start();

// 检查是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // 未登录，记录提示信息并跳转至登录页
    $_SESSION['login_error'] = "请先登录后再访问该页面";
    
    // 销毁所有会话数据
    $_SESSION = [];
    
    // 如果使用基于cookie的会话，删除会话cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // 销毁会话
    session_destroy();
    
    // 跳转到登录页面
    header('Location: login.php');
    exit;
}

// 检查会话是否过期（可选：添加会话超时机制）
$sessionLifetime = 3600; // 1小时
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $sessionLifetime)) {
    $_SESSION['login_error'] = "会话已超时，请重新登录";
    
    // 销毁会话
    $_SESSION = [];
    session_destroy();
    
    header('Location: login.php');
    exit;
}

// 更新最后活动时间
$_SESSION['last_activity'] = time();

// 防止直接访问此文件
if (basename($_SERVER['PHP_SELF']) === 'auth.php') {
    header('Location: dashboard.php');
    exit;
}
?>
    