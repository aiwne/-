<?php
/**
 * Bark通知设置页面（优化保存功能版本）
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化变量
$message = '';
$messageType = '';
$barkEnabled = 0;
$barkServer = 'https://api.day.app';
$barkDeviceKey = '';
$barkIcon = ''; // 新增：自定义图标URL
$debugInfo = [];

// 确保settings表存在（优化版）
function ensureSettingsTableExists($pdo) {
    global $debugInfo;
    
    // 优化表结构定义，确保兼容性
    $sql = "CREATE TABLE IF NOT EXISTS settings (
        id INT NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(50) NOT NULL,
        setting_value TEXT,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY (id),
        UNIQUE INDEX uk_setting_key (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    try {
        // 执行表创建
        $result = $pdo->exec($sql);
        $debugInfo[] = "表创建执行结果: " . ($result === false ? "失败" : "成功或已存在");
        
        // 确保时间字段有默认值（兼容旧版本MySQL）
        $pdo->exec("ALTER TABLE settings MODIFY COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");
        $pdo->exec("ALTER TABLE settings MODIFY COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        $debugInfo[] = "时间字段默认值设置完成";
        
        return true;
    } catch (PDOException $e) {
        $debugInfo[] = "创建设置表失败: " . $e->getMessage() . " (错误代码: " . $e->getCode() . ")";
        return false;
    }
}

// 读取Bark设置（优化版）
function getBarkSettings($pdo) {
    global $debugInfo;
    $settings = [
        'bark_enabled' => 0,
        'bark_server' => 'https://api.day.app',
        'bark_device_key' => '',
        'bark_icon' => '' // 新增：自定义图标URL
    ];
    
    try {
        // 使用准备语句提高安全性和兼容性
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?)");
        $stmt->execute(['bark_enabled', 'bark_server', 'bark_device_key', 'bark_icon']);
        
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $debugInfo[] = "读取到 " . count($rows) . " 条设置记录";
        
        foreach ($rows as $row) {
            if (isset($settings[$row['setting_key']])) {
                $settings[$row['setting_key']] = $row['setting_value'];
                $debugInfo[] = "加载设置: {$row['setting_key']} = " . substr($row['setting_value'], 0, 20) . (strlen($row['setting_value']) > 20 ? '...' : '');
            }
        }
    } catch (PDOException $e) {
        $debugInfo[] = "读取设置失败: " . $e->getMessage();
    }
    
    return $settings;
}

// 保存设置（优化版：增强错误处理）
function saveSingleSetting($pdo, $key, $value) {
    global $debugInfo;
    
    try {
        // 步骤1: 删除旧记录（使用准备语句）
        $deleteStmt = $pdo->prepare("DELETE FROM settings WHERE setting_key = ?");
        $deleteSuccess = $deleteStmt->execute([$key]);
        
        if (!$deleteSuccess) {
            $errorInfo = $deleteStmt->errorInfo();
            $debugInfo[] = "删除旧设置 {$key} 失败: " . $errorInfo[2];
            return false;
        }
        $debugInfo[] = "删除旧设置 {$key}: " . ($deleteStmt->rowCount() > 0 ? "已删除" : "无旧记录");
        
        // 步骤2: 插入新记录（使用准备语句）
        $insertStmt = $pdo->prepare("
            INSERT INTO settings (setting_key, setting_value, created_at, updated_at) 
            VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ");
        $insertSuccess = $insertStmt->execute([$key, $value]);
        
        if (!$insertSuccess) {
            $errorInfo = $insertStmt->errorInfo();
            $debugInfo[] = "插入新设置 {$key} 失败: " . $errorInfo[2];
            return false;
        }
        
        $debugInfo[] = "设置 {$key} 保存成功（新记录ID: " . $pdo->lastInsertId() . "）";
        return true;
    } catch (PDOException $e) {
        $debugInfo[] = "保存设置 {$key} 异常: " . $e->getMessage() . " (错误代码: " . $e->getCode() . ")";
        return false;
    }
}

// 发送测试通知（更新：支持自定义图标）
function sendTestNotification($server, $deviceKey, $icon = '') {
    if (empty($deviceKey)) {
        return ['success' => false, 'message' => '设备密钥不能为空'];
    }
    
    if (!preg_match('/^https?:\/\//', $server)) {
        $server = 'https://' . $server;
    }
    
    $url = rtrim($server, '/') . '/' . $deviceKey . '/卡密系统测试通知/这是一条测试消息，说明Bark通知配置成功！';
    
    // 添加图标参数
    if (!empty($icon)) {
        $url .= "&icon=" . urlencode($icon);
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['success' => false, 'message' => '发送失败: ' . $error];
    }
    
    if ($httpCode != 200) {
        return ['success' => false, 'message' => "HTTP错误: {$httpCode}"];
    }
    
    $result = json_decode($response, true);
    if (isset($result['code']) && $result['code'] == 200) {
        return ['success' => true, 'message' => '测试通知发送成功'];
    } else {
        $errorMsg = isset($result['message']) ? $result['message'] : '未知错误';
        return ['success' => false, 'message' => "发送失败: {$errorMsg}"];
    }
}

// 处理表单提交（优化版）
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $debugInfo[] = "===== 开始处理表单提交 =====";
    $debugInfo[] = "提交时间: " . date('Y-m-d H:i:s');
    
    // 获取并验证表单数据
    $barkEnabled = isset($_POST['bark_enabled']) ? 1 : 0;
    $barkServer = trim($_POST['bark_server'] ?? '');
    $barkDeviceKey = trim($_POST['bark_device_key'] ?? '');
    $barkIcon = trim($_POST['bark_icon'] ?? ''); // 新增：获取自定义图标
    
    // 验证服务器地址
    if (empty($barkServer)) {
        $barkServer = 'https://api.day.app';
        $debugInfo[] = "服务器地址为空，使用默认值: {$barkServer}";
    }
    
    $debugInfo[] = "表单数据 - 启用: {$barkEnabled}, 服务器: {$barkServer}, 设备密钥长度: " . strlen($barkDeviceKey) . ", 图标URL: " . (empty($barkIcon) ? '未设置' : $barkIcon);
    
    try {
        // 验证数据库连接
        $debugInfo[] = "尝试获取数据库实例";
        $db = Database::getInstance();
        
        if (!$db) {
            throw new Exception("无法获取数据库实例");
        }
        
        $debugInfo[] = "尝试获取PDO连接";
        $pdo = $db->getPdo();
        
        if (!$pdo) {
            throw new Exception("无法建立数据库连接，请检查db_connect.php配置");
        }
        
        $debugInfo[] = "数据库连接成功 (服务器版本: " . $pdo->getAttribute(PDO::ATTR_SERVER_VERSION) . ")";
        
        // 确保表存在
        if (!ensureSettingsTableExists($pdo)) {
            throw new Exception("设置表创建/更新失败，无法继续保存");
        }
        
        // 保存设置（逐条处理并检查结果）
        $saveSuccess = true;
        $debugInfo[] = "开始保存设置...";
        
        if (!saveSingleSetting($pdo, 'bark_enabled', $barkEnabled)) {
            $saveSuccess = false;
        }
        
        if (!saveSingleSetting($pdo, 'bark_server', $barkServer)) {
            $saveSuccess = false;
        }
        
        if (!saveSingleSetting($pdo, 'bark_device_key', $barkDeviceKey)) {
            $saveSuccess = false;
        }
        
        // 新增：保存自定义图标设置
        if (!saveSingleSetting($pdo, 'bark_icon', $barkIcon)) {
            $saveSuccess = false;
        }
        
        if ($saveSuccess) {
            $message = "设置已成功保存";
            $messageType = 'success';
            
            // 处理测试通知
            if (isset($_POST['test_notification']) && $barkEnabled && !empty($barkDeviceKey)) {
                $debugInfo[] = "开始发送测试通知...";
                $testResult = sendTestNotification($barkServer, $barkDeviceKey, $barkIcon);
                
                if ($testResult['success']) {
                    $message .= "<br>" . $testResult['message'];
                } else {
                    $message .= "<br><span class='text-red-600'>测试通知失败: {$testResult['message']}</span>";
                }
                $debugInfo[] = "测试通知结果: " . ($testResult['success'] ? "成功" : "失败 - " . $testResult['message']);
            }
        } else {
            $message = "部分或全部设置保存失败，请查看下方调试信息";
            $messageType = 'error';
        }
        
        $debugInfo[] = "表单处理完成";
    } catch (Exception $e) {
        $message = "操作失败: " . $e->getMessage();
        $messageType = 'error';
        $debugInfo[] = "处理过程中发生异常: " . $e->getMessage() . " (文件: " . $e->getFile() . ", 行: " . $e->getLine() . ")";
    }
}

// 读取当前设置（优化版）
try {
    $debugInfo[] = "===== 开始加载当前设置 =====";
    
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if ($pdo) {
        $debugInfo[] = "数据库连接有效，准备加载设置";
        ensureSettingsTableExists($pdo);
        $settings = getBarkSettings($pdo);
        
        $barkEnabled = (int)$settings['bark_enabled'];
        $barkServer = $settings['bark_server'];
        $barkDeviceKey = $settings['bark_device_key'];
        $barkIcon = $settings['bark_icon']; // 新增：读取自定义图标设置
        
        $debugInfo[] = "设置加载完成 - 启用: {$barkEnabled}, 服务器: {$barkServer}, 密钥长度: " . strlen($barkDeviceKey) . ", 图标URL: " . (empty($barkIcon) ? '未设置' : $barkIcon);
    } else {
        $debugInfo[] = "数据库连接无效，使用默认设置";
        $message = "数据库连接失败，无法加载保存的设置";
        $messageType = 'warning';
    }
} catch (Exception $e) {
    $message = "加载设置失败: " . $e->getMessage();
    $messageType = 'error';
    $debugInfo[] = "加载设置异常: " . $e->getMessage();
}

// 页面输出
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bark通知设置 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible { transform: translateX(0); visibility: visible; }
            .sidebar-hidden { transform: translateX(-100%); visibility: hidden; }
            .form-input { @apply w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500; }
            .form-label { @apply block text-sm font-medium text-gray-700 mb-1; }
            .card-shadow { @apply bg-white shadow overflow-hidden sm:rounded-lg; }
            .debug-box { @apply bg-gray-900 text-gray-100 p-4 rounded-md text-sm overflow-x-auto max-h-60; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700 lg:hidden">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? '管理员'); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
       <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">Bark通知设置</h2>
                <p class="mt-1 text-gray-600">配置Bark通知，当卡密被验证时接收推送通知</p>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                         ($messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 
                             ($messageType === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle');
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 设置表单 -->
            <div class="card-shadow mb-6">
                <div class="px-4 py-5 sm:p-6">
                    <form method="post">
                        <div class="mb-6">
                            <div class="flex items-center">
                                <input type="checkbox" name="bark_enabled" id="bark_enabled" 
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                       <?php echo $barkEnabled ? 'checked' : ''; ?>>
                                <label for="bark_enabled" class="ml-2 block text-sm text-gray-700">
                                    启用Bark通知
                                </label>
                            </div>
                            <p class="mt-1 text-sm text-gray-500">
                                启用后，当卡密被验证（成功或失败）时将发送通知到您的设备
                            </p>
                        </div>
                        
                        <div class="mb-6">
                            <label for="bark_server" class="form-label">Bark服务器地址</label>
                            <input type="url" name="bark_server" id="bark_server" 
                                   value="<?php echo htmlspecialchars($barkServer); ?>"
                                   placeholder="例如: https://api.day.app"
                                   class="form-input">
                        </div>
                        
                        <div class="mb-6">
                            <label for="bark_device_key" class="form-label">设备密钥 <span class="text-red-500">*</span></label>
                            <input type="text" name="bark_device_key" id="bark_device_key" 
                                   value="<?php echo htmlspecialchars($barkDeviceKey); ?>"
                                   placeholder="从Bark应用中获取的设备密钥"
                                   class="form-input">
                        </div>
                        
                        <!-- 新增：自定义图标设置 -->
                        <div class="mb-6">
                            <label for="bark_icon" class="form-label">通知图标URL（可选）</label>
                            <input type="url" name="bark_icon" id="bark_icon" 
                                   value="<?php echo htmlspecialchars($barkIcon); ?>"
                                   placeholder="通知显示的图标URL，留空使用默认图标"
                                   class="form-input">
                            <p class="mt-1 text-sm text-gray-500">
                                请输入有效的图片URL，支持PNG、JPG等格式
                            </p>
                        </div>
                        
                        <div class="flex items-center gap-4 pt-4 border-t border-gray-200">
                            <button type="submit" name="save_settings" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                                <i class="fa fa-save mr-2"></i>保存设置
                            </button>
                            <button type="submit" name="test_notification" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                                    onclick="return confirm('确定要发送测试通知吗？请确保已填写设备密钥。')">
                                <i class="fa fa-paper-plane mr-2"></i>保存并测试
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 帮助信息 -->
            <div class="card-shadow mb-6">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">
                        <i class="fa fa-question-circle text-blue-500 mr-2"></i>什么是Bark？
                    </h3>
                    <div class="space-y-3 text-gray-700">
                        <p>
                            Bark是一款开源的iOS推送工具，可以让您的设备接收自定义推送通知。
                            通过配置Bark，您可以在卡密被验证时立即收到通知，及时了解卡密使用情况。
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- 调试信息区域 -->
            <div class="card-shadow">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                        <i class="fa fa-bug text-red-500 mr-2"></i>调试信息
                        <button onclick="document.querySelector('.debug-box').classList.toggle('hidden')" 
                                class="ml-2 text-sm text-blue-600 hover:underline">
                            切换显示
                        </button>
                    </h3>
                    <div class="debug-box">
                        <p><?php echo implode("<br>\n", $debugInfo); ?></p>
                    </div>
                    <p class="mt-4 text-sm text-gray-500">
                        若设置无法保存，请提供上述调试信息以便排查问题
                    </p>
                </div>
            </div>
        </main>
    </div>

    <script>
        // 侧边栏切换功能
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('hidden');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化处理
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) {
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.add('hidden');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('hidden');
                }
            });
        });
    </script>
</body>
</html>
<?php
// 清理变量
unset($message, $messageType, $barkEnabled, $barkServer, $barkDeviceKey, $barkIcon, $debugInfo, $db, $pdo);
?>