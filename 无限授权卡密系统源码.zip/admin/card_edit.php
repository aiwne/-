<?php
// 验证登录状态
require_once 'auth.php';
require_once '../db_connect.php';

$message = '';
$messageType = '';
$card = null;

// 检查卡密ID是否提供
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: cards_list.php?error=invalid_id');
    exit;
}

$cardId = (int)$_GET['id'];

// 获取卡密信息
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    $stmt = $pdo->prepare("SELECT * FROM cards WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $cardId]);
    $card = $stmt->fetch();
    
    if (!$card) {
        header('Location: cards_list.php?error=card_not_found');
        exit;
    }
} catch (PDOException $e) {
    $message = "获取卡密信息失败: " . $e->getMessage();
    $messageType = 'error';
    error_log("获取卡密信息错误: " . $e->getMessage());
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $card) {
    $action = $_POST['action'] ?? 'update';
    
    if ($action === 'add_uses') {
        // 处理增加使用次数
        $addUses = (int)($_POST['add_uses'] ?? 0);
        
        if ($addUses <= 0) {
            $message = "增加次数必须大于0";
            $messageType = 'error';
        } else {
            try {
                // 增加使用次数
                $stmt = $pdo->prepare("UPDATE cards SET current_uses = current_uses + :add_uses, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
                $stmt->execute([
                    ':add_uses' => $addUses,
                    ':id' => $cardId
                ]);
                
                $message = "成功增加 {$addUses} 次使用次数";
                $messageType = 'success';
                
                // 刷新卡密数据
                $card['current_uses'] += $addUses;
            } catch (PDOException $e) {
                $message = "增加次数失败: " . $e->getMessage();
                $messageType = 'error';
                error_log("增加使用次数错误: " . $e->getMessage());
            }
        }
    } else {
        // 处理常规更新
        $cardCode = trim($_POST['card_code'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $maxUses = (int)($_POST['max_uses'] ?? 1);
        $isUsed = isset($_POST['is_used']) ? 1 : 0;
        
        // 验证表单数据
        if (empty($cardCode) || empty($content)) {
            $message = "卡密和内容不能为空";
            $messageType = 'error';
        } elseif ($maxUses < 1) {
            $message = "最大使用次数必须大于0";
            $messageType = 'error';
        } else {
            try {
                // 检查卡密是否已被其他记录使用
                $stmt = $pdo->prepare("SELECT id FROM cards WHERE card_code = :code AND id != :id LIMIT 1");
                $stmt->execute([
                    ':code' => $cardCode,
                    ':id' => $cardId
                ]);
                
                if ($stmt->fetch()) {
                    $message = "该卡密已存在，请使用其他卡密";
                    $messageType = 'error';
                } else {
                    // 更新卡密信息
                    $updateData = [
                        ':card_code' => $cardCode,
                        ':content' => $content,
                        ':max_uses' => $maxUses,
                        ':is_used' => $isUsed,
                        ':id' => $cardId
                    ];
                    
                    // 如果状态改为已使用且之前未使用，更新使用时间
                    if ($isUsed == 1 && $card['is_used'] == 0) {
                        $sql = "UPDATE cards SET card_code = :card_code, content = :content, max_uses = :max_uses, is_used = :is_used, used_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
                    } 
                    // 如果状态改为未使用，清空使用时间
                    elseif ($isUsed == 0 && $card['is_used'] == 1) {
                        $sql = "UPDATE cards SET card_code = :card_code, content = :content, max_uses = :max_uses, is_used = :is_used, used_at = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
                    } 
                    // 其他情况不修改使用时间
                    else {
                        $sql = "UPDATE cards SET card_code = :card_code, content = :content, max_uses = :max_uses, is_used = :is_used, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
                    }
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($updateData);
                    
                    $message = "卡密信息已成功更新";
                    $messageType = 'success';
                    
                    // 刷新卡密数据
                    $card['card_code'] = $cardCode;
                    $card['content'] = $content;
                    $card['max_uses'] = $maxUses;
                    $card['is_used'] = $isUsed;
                }
            } catch (PDOException $e) {
                $message = "更新失败: " . $e->getMessage();
                $messageType = 'error';
                error_log("更新卡密错误: " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑卡密 - 卡密管理系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <!-- 顶部导航栏 -->
    <header class="bg-white shadow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside class="bg-gray-800 w-64 flex-shrink-0 hidden md:block">
            <div class="h-full pt-5 pb-4 overflow-y-auto">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="sidebar-menu-link bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_add.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="batch_generate.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="profile.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-semibold text-gray-800">编辑卡密</h2>
                    <a href="cards_list.php" class="text-blue-600 hover:text-blue-800 flex items-center">
                        <i class="fa fa-arrow-left mr-2"></i>返回列表
                    </a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="mb-6 p-4 rounded-md <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                        <i class="fa <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($card): ?>
                    <div class="bg-white shadow rounded-lg p-6 max-w-3xl">
                        <form method="post" class="space-y-6">
                            <input type="hidden" name="action" value="update">
                            <div>
                                <label for="card_code" class="block text-sm font-medium text-gray-700 mb-1">卡密代码 <span class="text-red-500">*</span></label>
                                <input type="text" id="card_code" name="card_code" required
                                       value="<?php echo htmlspecialchars($card['card_code']); ?>"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <p class="mt-1 text-xs text-gray-500">卡密是用户验证时输入的代码，需保持唯一</p>
                            </div>
                            
                            <div>
                                <label for="content" class="block text-sm font-medium text-gray-700 mb-1">卡密内容 <span class="text-red-500">*</span></label>
                                <textarea id="content" name="content" rows="6" required
                                          class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($card['content']); ?></textarea>
                                <p class="mt-1 text-xs text-gray-500">用户验证成功后显示的内容</p>
                            </div>
                            
                            <div>
                                <label for="max_uses" class="block text-sm font-medium text-gray-700 mb-1">最大使用次数 <span class="text-red-500">*</span></label>
                                <input type="number" id="max_uses" name="max_uses" min="1" max="999" required
                                       value="<?php echo $card['max_uses'] ?? 1; ?>"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <p class="mt-1 text-xs text-gray-500">该卡密最多可以被使用的次数</p>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" id="is_used" name="is_used"
                                       <?php echo $card['is_used'] ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="is_used" class="ml-2 block text-sm text-gray-700">
                                    标记为已使用
                                </label>
                            </div>
                            
                            <div class="pt-4 border-t border-gray-200">
                                <div class="flex flex-wrap gap-4">
                                    <button type="submit" 
                                            class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md transition duration-300">
                                        <i class="fa fa-save mr-2"></i>保存修改
                                    </button>
                                    <a href="cards_list.php" 
                                       class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-6 rounded-md transition duration-300">
                                        <i class="fa fa-times mr-2"></i>取消
                                    </a>
                                    <a href="card_delete.php?id=<?php echo $card['id']; ?>" 
                                       class="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-6 rounded-md transition duration-300 delete-form"
                                       data-card-code="<?php echo $card['card_code']; ?>">
                                        <i class="fa fa-trash mr-2"></i>删除卡密
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                    
                    <!-- 卡密信息显示 -->
                    <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 mt-6 max-w-3xl">
                        <h4 class="text-sm font-medium text-gray-700 mb-2">卡密信息</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                                <span class="text-gray-500">创建时间:</span>
                                <?php echo date('Y-m-d H:i:s', strtotime($card['created_at'])); ?>
                            </div>
                            <div>
                                <span class="text-gray-500">最后更新:</span>
                                <?php echo date('Y-m-d H:i:s', strtotime($card['updated_at'])); ?>
                            </div>
                            <div>
                                <span class="text-gray-500">使用时间:</span>
                                <?php 
                                if (!empty($card['updated_at']) && $card['updated_at'] !== '0000-00-00 00:00:00' && ($card['current_uses'] ?? 0) > 0) {
                                    echo date('Y-m-d H:i:s', strtotime($card['updated_at']));
                                } else {
                                    echo '<span class="text-gray-400">未使用</span>';
                                }
                                ?>
                            </div>
                            <div>
                                <span class="text-gray-500">使用状态:</span>
                                <?php 
                                $currentUses = $card['current_uses'] ?? 0;
                                $maxUses = $card['max_uses'] ?? 1;
                                $isFullyUsed = $currentUses >= $maxUses;
                                
                                if ($isFullyUsed) {
                                    echo '<span class="text-red-600"><i class="fa fa-times-circle mr-1"></i>已用完</span>';
                                } elseif ($currentUses > 0) {
                                    echo '<span class="text-yellow-600"><i class="fa fa-clock-o mr-1"></i>使用中</span>';
                                } else {
                                    echo '<span class="text-green-600"><i class="fa fa-check-circle mr-1"></i>未使用</span>';
                                }
                                ?>
                            </div>
                            <div>
                                <span class="text-gray-500">使用次数:</span>
                                <span class="font-medium"><?php echo $currentUses; ?>/<?php echo $maxUses; ?></span>
                            </div>
                            <div>
                                <span class="text-gray-500">剩余次数:</span>
                                <span class="font-medium text-blue-600"><?php echo max(0, $maxUses - $currentUses); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 增加使用次数功能 -->
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6 max-w-3xl">
                        <h4 class="text-sm font-medium text-blue-700 mb-3 flex items-center">
                            <i class="fa fa-plus-circle mr-2"></i>增加使用次数
                        </h4>
                        <form method="post" class="flex items-end gap-3">
                            <input type="hidden" name="action" value="add_uses">
                            <div class="flex-1">
                                <label for="add_uses" class="block text-xs text-gray-600 mb-1">增加次数</label>
                                <input type="number" id="add_uses" name="add_uses" min="1" max="100" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            <button type="submit" 
                                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">
                                <i class="fa fa-plus mr-1"></i>增加
                            </button>
                        </form>
                        <p class="text-xs text-gray-500 mt-2">注意：增加次数后，当前使用次数会相应增加，但不会影响最大使用次数</p>
                    </div>
                <?php else: ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                        <i class="fa fa-exclamation-triangle mr-2"></i>无法加载卡密信息，请返回重试
                    </div>
                    <div class="mt-4">
                        <a href="cards_list.php" class="inline-flex items-center px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md">
                            <i class="fa fa-arrow-left mr-2"></i>返回卡密列表
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>
<?php
// 清理敏感数据
unset($message, $messageType, $db, $pdo, $stmt, $card, $cardId);
?>
    