<?php
/**
 * 卡密导出处理接口
 * 提供AJAX接口用于处理导出请求
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 设置响应头
header('Content-Type: application/json; charset=utf-8');

// 只允许POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => '只支持POST请求'
    ]);
    exit;
}

try {
    // 获取导出参数
    $exportFormat = $_POST['export_format'] ?? 'csv';
    $categoryId = $_POST['category_id'] ?? '';
    $status = $_POST['status'] ?? '';
    $dateFrom = $_POST['date_from'] ?? '';
    $dateTo = $_POST['date_to'] ?? '';
    $includeHeaders = isset($_POST['include_headers']);
    $includeUsedInfo = isset($_POST['include_used_info']);
    $onlyUnused = isset($_POST['only_unused']);
    
    // 获取数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        throw new Exception("数据库连接失败");
    }
    
    // 构建查询条件
    $conditions = [];
    $params = [];
    
    // 分类筛选
    if (!empty($categoryId)) {
        $conditions[] = "c.category_id = :category_id";
        $params[':category_id'] = $categoryId;
    }
    
    // 状态筛选
    if (!empty($status)) {
        switch ($status) {
            case 'unused':
                $conditions[] = "c.current_uses = 0";
                break;
            case 'using':
                $conditions[] = "c.current_uses > 0 AND c.current_uses < c.max_uses";
                break;
            case 'used':
                $conditions[] = "c.current_uses >= c.max_uses";
                break;
            case 'expired':
                $conditions[] = "c.valid_until IS NOT NULL AND c.valid_until < NOW()";
                break;
        }
    }
    
    // 时间范围筛选
    if (!empty($dateFrom)) {
        $conditions[] = "c.created_at >= :date_from";
        $params[':date_from'] = $dateFrom . ' 00:00:00';
    }
    
    if (!empty($dateTo)) {
        $conditions[] = "c.created_at <= :date_to";
        $params[':date_to'] = $dateTo . ' 23:59:59';
    }
    
    // 仅导出未使用的卡密
    if ($onlyUnused) {
        $conditions[] = "c.current_uses = 0";
    }
    
    $whereClause = $conditions ? "WHERE " . implode(' AND ', $conditions) : '';
    
    // 查询数据
    $sql = "
        SELECT 
            c.id,
            c.card_code,
            c.content,
            c.max_uses,
            c.current_uses,
            c.valid_until,
            c.first_use_ip,
            c.last_use_ip,
            c.created_at,
            c.used_at,
            cat.name as category_name,
            CASE 
                WHEN c.valid_until IS NOT NULL AND c.valid_until < NOW() THEN 'expired'
                WHEN c.current_uses >= c.max_uses THEN 'used'
                WHEN c.current_uses > 0 THEN 'using'
                ELSE 'unused'
            END as status
        FROM cards c
        LEFT JOIN categories cat ON c.category_id = cat.id
        {$whereClause}
        ORDER BY c.created_at DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($cards)) {
        echo json_encode([
            'success' => false,
            'message' => '没有找到符合条件的卡密数据'
        ]);
        exit;
    }
    
    // 生成文件名
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "cards_export_{$timestamp}.{$exportFormat}";
    
    // 根据格式导出
    switch ($exportFormat) {
        case 'csv':
            exportToCsv($cards, $filename, $includeHeaders, $includeUsedInfo);
            break;
        case 'excel':
            exportToExcel($cards, $filename, $includeHeaders, $includeUsedInfo);
            break;
        case 'json':
            exportToJson($cards, $filename, $includeUsedInfo);
            break;
        case 'txt':
            exportToTxt($cards, $filename, $includeUsedInfo);
            break;
        default:
            throw new Exception("不支持的导出格式");
    }
    
} catch (Exception $e) {
    error_log("卡密导出错误：" . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => '导出失败：' . $e->getMessage()
    ]);
}

/**
 * 导出为CSV格式
 */
function exportToCsv($cards, $filename, $includeHeaders = true, $includeUsedInfo = true) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    // 输出BOM以支持中文
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    // 输出表头
    if ($includeHeaders) {
        $headers = ['ID', '卡密代码', '内容', '最大使用次数', '当前使用次数', '状态', '分类', '有效期'];
        
        if ($includeUsedInfo) {
            $headers = array_merge($headers, ['首次使用IP', '最后使用IP', '创建时间', '使用时间']);
        }
        
        fputcsv($output, $headers);
    }
    
    // 输出数据
    foreach ($cards as $card) {
        $row = [
            $card['id'],
            $card['card_code'],
            $card['content'],
            $card['max_uses'],
            $card['current_uses'],
            $card['status'],
            $card['category_name'] ?: '未分类',
            $card['valid_until'] ?: ''
        ];
        
        if ($includeUsedInfo) {
            $row = array_merge($row, [
                $card['first_use_ip'] ?: '',
                $card['last_use_ip'] ?: '',
                $card['created_at'],
                $card['used_at'] ?: ''
            ]);
        }
        
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

/**
 * 导出为Excel格式
 */
function exportToExcel($cards, $filename, $includeHeaders = true, $includeUsedInfo = true) {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    echo "<table border='1'>";
    
    // 输出表头
    if ($includeHeaders) {
        echo "<tr>";
        echo "<th>ID</th><th>卡密代码</th><th>内容</th><th>最大使用次数</th><th>当前使用次数</th>";
        echo "<th>状态</th><th>分类</th><th>有效期</th>";
        
        if ($includeUsedInfo) {
            echo "<th>首次使用IP</th><th>最后使用IP</th><th>创建时间</th><th>使用时间</th>";
        }
        
        echo "</tr>";
    }
    
    // 输出数据
    foreach ($cards as $card) {
        echo "<tr>";
        echo "<td>{$card['id']}</td>";
        echo "<td>{$card['card_code']}</td>";
        echo "<td>{$card['content']}</td>";
        echo "<td>{$card['max_uses']}</td>";
        echo "<td>{$card['current_uses']}</td>";
        echo "<td>{$card['status']}</td>";
        echo "<td>" . ($card['category_name'] ?: '未分类') . "</td>";
        echo "<td>" . ($card['valid_until'] ?: '') . "</td>";
        
        if ($includeUsedInfo) {
            echo "<td>" . ($card['first_use_ip'] ?: '') . "</td>";
            echo "<td>" . ($card['last_use_ip'] ?: '') . "</td>";
            echo "<td>{$card['created_at']}</td>";
            echo "<td>" . ($card['used_at'] ?: '') . "</td>";
        }
        
        echo "</tr>";
    }
    
    echo "</table>";
    exit;
}

/**
 * 导出为JSON格式
 */
function exportToJson($cards, $filename, $includeUsedInfo = true) {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    $exportData = [
        'export_time' => date('Y-m-d H:i:s'),
        'total_count' => count($cards),
        'cards' => $cards
    ];
    
    echo json_encode($exportData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * 导出为TXT格式
 */
function exportToTxt($cards, $filename, $includeUsedInfo = true) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    echo "卡密导出报告\n";
    echo "导出时间：" . date('Y-m-d H:i:s') . "\n";
    echo "总数量：" . count($cards) . "\n";
    echo str_repeat("=", 50) . "\n\n";
    
    foreach ($cards as $card) {
        echo "ID: {$card['id']}\n";
        echo "卡密代码: {$card['card_code']}\n";
        echo "内容: {$card['content']}\n";
        echo "使用次数: {$card['current_uses']}/{$card['max_uses']}\n";
        echo "状态: {$card['status']}\n";
        echo "分类: " . ($card['category_name'] ?: '未分类') . "\n";
        
        if ($card['valid_until']) {
            echo "有效期: {$card['valid_until']}\n";
        }
        
        if ($includeUsedInfo) {
            if ($card['first_use_ip']) {
                echo "首次使用IP: {$card['first_use_ip']}\n";
            }
            if ($card['used_at']) {
                echo "使用时间: {$card['used_at']}\n";
            }
        }
        
        echo "创建时间: {$card['created_at']}\n";
        echo str_repeat("-", 30) . "\n";
    }
    
    exit;
}
?>
