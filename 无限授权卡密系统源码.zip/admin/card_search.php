<?php
/**
 * 卡密查询页面
 * 功能：支持按卡密代码、内容、分类、使用状态等多条件搜索
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化应用
class CardSearch {
    private $pdo;
    private $message = '';
    private $messageType = '';
    private $page = 1;
    private $limit = 20;
    private $searchQuery = '';
    private $searchType = 'code'; // code, content, category, all
    private $categoryId = '';
    private $usedFilter = '';
    private $ipFilter = '';
    private $totalCards = 0;
    private $cards = [];
    private $categories = [];

    public function __construct() {
        $this->initDb();
        $this->handleSession();
        $this->parseRequestParams();
        $this->loadCategories();
        $this->loadCards();
    }

    // 初始化数据库连接
    private function initDb() {
        try {
            $db = Database::getInstance();
            $this->pdo = $db->getPdo();
        } catch (PDOException $e) {
            $this->setMessage("数据库连接失败: " . $e->getMessage(), 'error');
            error_log("数据库连接错误: " . $e->getMessage());
        }
    }

    // 处理会话相关（CSRF令牌）
    private function handleSession() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    // 解析请求参数
    private function parseRequestParams() {
        // 分页参数
        if (isset($_GET['page']) && is_numeric($_GET['page'])) {
            $this->page = max(1, (int)$_GET['page']);
        }

        // 搜索参数
        if (isset($_GET['q']) && !empty(trim($_GET['q']))) {
            $this->searchQuery = trim($_GET['q']);
        }

        if (isset($_GET['type']) && in_array($_GET['type'], ['code', 'content', 'category', 'all'])) {
            $this->searchType = $_GET['type'];
        }

        // 筛选参数
        if (isset($_GET['category']) && is_numeric($_GET['category'])) {
            $this->categoryId = (int)$_GET['category'];
        }

        if (isset($_GET['used']) && in_array($_GET['used'], ['0', '1', 'using'])) {
            $this->usedFilter = $_GET['used'];
        }

        if (isset($_GET['ip_filter']) && in_array($_GET['ip_filter'], ['bound', 'unbound'])) {
            $this->ipFilter = $_GET['ip_filter'];
        }

        // 消息参数
        if (isset($_GET['message']) && isset($_GET['type'])) {
            $this->message = urldecode($_GET['message']);
            $this->messageType = $_GET['type'];
        }
    }

    // 加载分类列表
    private function loadCategories() {
        try {
            $stmt = $this->pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
            $this->categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->setMessage("获取分类列表失败: " . $e->getMessage(), 'error');
            error_log("获取分类列表错误: " . $e->getMessage());
        }
    }

    // 加载卡密列表
    private function loadCards() {
        if (!$this->pdo) return;

        try {
            // 构建查询条件
            $conditions = [];
            $params = [];

            // 搜索条件
            if (!empty($this->searchQuery)) {
                switch ($this->searchType) {
                    case 'code':
                        $conditions[] = "c.card_code LIKE :search";
                        $params[':search'] = '%' . $this->searchQuery . '%';
                        break;
                    case 'content':
                        $conditions[] = "c.content LIKE :search";
                        $params[':search'] = '%' . $this->searchQuery . '%';
                        break;
                    case 'category':
                        $conditions[] = "cat.name LIKE :search";
                        $params[':search'] = '%' . $this->searchQuery . '%';
                        break;
                    case 'all':
                    default:
                        $conditions[] = "(c.card_code LIKE :search OR c.content LIKE :search OR cat.name LIKE :search)";
                        $params[':search'] = '%' . $this->searchQuery . '%';
                        break;
                }
            }

            // 其他筛选条件
            if (!empty($this->categoryId)) {
                $conditions[] = "c.category_id = :category_id";
                $params[':category_id'] = $this->categoryId;
            }

            if ($this->usedFilter !== '') {
                if ($this->usedFilter === 'using') {
                    $conditions[] = "c.current_uses > 0 AND c.current_uses < c.max_uses";
                } else {
                    $conditions[] = "c.used = :used";
                    $params[':used'] = $this->usedFilter;
                }
            }

            if ($this->ipFilter === 'bound') {
                $conditions[] = "c.first_use_ip IS NOT NULL AND c.first_use_ip != ''";
            } elseif ($this->ipFilter === 'unbound') {
                $conditions[] = "(c.first_use_ip IS NULL OR c.first_use_ip = '')";
            }

            $whereClause = $conditions ? "WHERE " . implode(' AND ', $conditions) : '';

            // 查询总数
            $countStmt = $this->pdo->prepare("
                SELECT COUNT(*) 
                FROM cards c
                LEFT JOIN categories cat ON c.category_id = cat.id
                {$whereClause}
            ");
            $countStmt->execute($params);
            $this->totalCards = (int)$countStmt->fetchColumn();

            // 计算分页偏移量
            $offset = ($this->page - 1) * $this->limit;

            // 查询当前页数据
            $stmt = $this->pdo->prepare("
                SELECT c.*, cat.name AS category_name,
                       CASE 
                           WHEN c.valid_until IS NOT NULL AND c.valid_until < NOW() THEN 'expired'
                           WHEN c.current_uses >= c.max_uses THEN 'used'
                           WHEN c.current_uses > 0 THEN 'using'
                           ELSE 'unused'
                       END as status
                FROM cards c
                LEFT JOIN categories cat ON c.category_id = cat.id
                {$whereClause}
                ORDER BY c.created_at DESC
                LIMIT :limit OFFSET :offset
            ");
            
            $dataParams = $params;
            $dataParams[':limit'] = $this->limit;
            $dataParams[':offset'] = $offset;

            $stmt->execute($dataParams);
            $this->cards = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            error_log("获取卡密列表错误: " . $e->getMessage());
            $this->setMessage("获取卡密列表失败: " . $e->getMessage(), 'error');
        }
    }

    // 设置消息
    private function setMessage(string $message, string $type) {
        $this->message = $message;
        $this->messageType = $type;
    }

    // 生成分页HTML
    private function renderPagination() {
        if ($this->totalCards <= 0) return '';

        $totalPages = ceil($this->totalCards / $this->limit);
        $visiblePages = 5;
        $halfVisible = floor($visiblePages / 2);
        $startPage = max(1, $this->page - $halfVisible);
        $endPage = min($totalPages, $startPage + $visiblePages - 1);

        if ($endPage - $startPage < $visiblePages - 1) {
            $startPage = max(1, $endPage - $visiblePages + 1);
        }

        $pagination = '<nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">';
        
        // 上一页
        $prevPage = $this->page - 1;
        $prevUrl = $prevPage >= 1 ? $this->buildPageUrl($prevPage) : '#';
        $pagination .= '<a href="' . $prevUrl . '" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ' . ($prevPage < 1 ? 'opacity-50 cursor-not-allowed' : '') . '">';
        $pagination .= '<span class="sr-only">上一页</span><i class="fa fa-chevron-left text-xs"></i></a>';

        // 页码
        if ($startPage > 1) {
            $pagination .= '<a href="' . $this->buildPageUrl(1) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">1</a>';
            if ($startPage > 2) $pagination .= '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
        }

        for ($i = $startPage; $i <= $endPage; $i++) {
            $isActive = $i === $this->page;
            $pagination .= '<a href="' . $this->buildPageUrl($i) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium ' . ($isActive ? 'z-10 bg-blue-50 border-blue-500 text-blue-600' : 'text-gray-700 hover:bg-gray-50') . '">' . $i . '</a>';
        }

        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) $pagination .= '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
            $pagination .= '<a href="' . $this->buildPageUrl($totalPages) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">' . $totalPages . '</a>';
        }

        // 下一页
        $nextPage = $this->page + 1;
        $nextUrl = $nextPage <= $totalPages ? $this->buildPageUrl($nextPage) : '#';
        $pagination .= '<a href="' . $nextUrl . '" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ' . ($nextPage > $totalPages ? 'opacity-50 cursor-not-allowed' : '') . '">';
        $pagination .= '<span class="sr-only">下一页</span><i class="fa fa-chevron-right text-xs"></i></a>';
        
        $pagination .= '</nav>';
        return $pagination;
    }

    // 构建分页URL
    private function buildPageUrl(int $page) {
        $url = "card_search.php?page={$page}";
        if (!empty($this->searchQuery)) $url .= "&q=" . urlencode($this->searchQuery);
        if ($this->searchType !== 'code') $url .= "&type=" . $this->searchType;
        if (!empty($this->categoryId)) $url .= "&category=" . $this->categoryId;
        if ($this->usedFilter !== '') $url .= "&used=" . $this->usedFilter;
        if ($this->ipFilter !== '') $url .= "&ip_filter=" . $this->ipFilter;
        return $url;
    }

    // 渲染页面
    public function render() {
        ?>
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>卡密查询 - 卡密系统</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
            <style type="text/tailwindcss">
                @layer utilities {
                    .sidebar-visible {
                        transform: translateX(0);
                        visibility: visible;
                    }
                    .sidebar-hidden {
                        transform: translateX(-100%);
                        visibility: hidden;
                    }
                    .sidebar-overlay {
                        background-color: rgba(0, 0, 0, 0.5);
                        opacity: 0;
                        visibility: hidden;
                        transition: opacity 0.3s ease;
                    }
                    .sidebar-overlay.active {
                        opacity: 1;
                        visibility: visible;
                    }
                    .mobile-menu-btn {
                        @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
                    }
                    .card-hover {
                        @apply transition-all duration-200 hover:shadow-md hover:-translate-y-1;
                    }
                    .btn-effect {
                        @apply transition-all duration-200 transform hover:scale-105 active:scale-95;
                    }
                    .fade-in {
                        animation: fadeIn 0.3s ease-in-out;
                    }
                    @keyframes fadeIn {
                        from { opacity: 0; }
                        to { opacity: 1; }
                    }
                    .copy-notify {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        padding: 12px 20px;
                        background: #10b981;
                        color: white;
                        border-radius: 4px;
                        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                        z-index: 9999;
                        opacity: 0;
                        transform: translateY(-20px);
                        transition: all 0.3s ease;
                    }
                    .copy-notify.show {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        </head>
        <body class="bg-gray-100">
            <!-- 移动端菜单按钮 -->
            <button id="mobileMenuBtn" class="mobile-menu-btn">
                <i class="fa fa-bars"></i>
            </button>
            <!-- 顶部导航 -->
            <header class="bg-white shadow h-16 lg:pl-64">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16">
                        <div class="flex items-center">
                            <h1 class="text-xl font-bold text-gray-800">卡密查询系统</h1>
                        </div>
                        <div class="flex items-center">
                            <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                            <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                                <i class="fa fa-sign-out mr-1"></i>退出登录
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <!-- 侧边栏遮罩层 -->
            <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>
            <!-- 主容器 -->
            <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
                <!-- 侧边栏 -->
                <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
                    <div class="h-full pb-4">
                        <nav class="px-2 space-y-1">
                            <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-tachometer mr-3"></i>仪表盘
                            </a>
                            <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-list-alt mr-3"></i>卡密管理
                            </a>
                            <a href="card_search.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-search mr-3"></i>卡密查询
                            </a>
                            <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-plus-circle mr-3"></i>添加卡密
                            </a>
                            <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                            <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-tags mr-3"></i>分类管理
                            </a>
                            <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-cubes mr-3"></i>批量生成
                            </a>
                            <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-bell mr-3"></i>Bark通知设置
                            </a>
                            <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                            </a>
                             <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                            <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-user mr-3"></i>个人设置
                            </a>
                        </nav>
                    </div>
                </aside>
                <!-- 主内容区 -->
               <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-semibold text-gray-800">卡密查询</h2>
                        <p class="mt-1 text-gray-600">支持按卡密代码、内容、分类等多条件搜索</p>
                    </div>
                    
                    <!-- 消息提示 -->
                    <?php if (!empty($this->message)): ?>
                        <div class="mb-6 p-4 rounded-md <?php 
                            echo $this->messageType === 'success' ? 'bg-green-100 text-green-800' : 
                                 ($this->messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                        ?>">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <?php if ($this->messageType === 'success'): ?>
                                        <i class="fa fa-check-circle text-green-500"></i>
                                    <?php elseif ($this->messageType === 'warning'): ?>
                                        <i class="fa fa-exclamation-triangle text-yellow-500"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times-circle text-red-500"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-3">
                                    <p><?php echo $this->message; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- 复制成功通知 -->
                    <div id="copyNotify" class="copy-notify">
                        <i class="fa fa-check mr-2"></i>
                        <span id="notifyText">复制成功</span>
                    </div>

                    <!-- 搜索表单 -->
                    <div class="bg-white shadow-sm rounded-lg mb-6 overflow-hidden">
                        <div class="p-4 md:p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4">搜索条件</h3>
                            <form method="get" class="space-y-4" id="searchForm">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label for="q" class="block text-sm font-medium text-gray-700 mb-1">搜索关键词</label>
                                        <input type="text" name="q" id="q" 
                                               value="<?php echo htmlspecialchars($this->searchQuery); ?>"
                                               class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                               placeholder="请输入搜索关键词">
                                    </div>
                                    
                                    <div>
                                        <label for="type" class="block text-sm font-medium text-gray-700 mb-1">搜索类型</label>
                                        <select name="type" id="type" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="code" <?php echo $this->searchType === 'code' ? 'selected' : ''; ?>>卡密代码</option>
                                            <option value="content" <?php echo $this->searchType === 'content' ? 'selected' : ''; ?>>卡密内容</option>
                                            <option value="category" <?php echo $this->searchType === 'category' ? 'selected' : ''; ?>>分类名称</option>
                                            <option value="all" <?php echo $this->searchType === 'all' ? 'selected' : ''; ?>>全部字段</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label for="category" class="block text-sm font-medium text-gray-700 mb-1">卡密分类</label>
                                        <select name="category" id="category" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部分类</option>
                                            <?php foreach ($this->categories as $category): ?>
                                                <option value="<?php echo $category['id']; ?>" 
                                                    <?php echo $this->categoryId == $category['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($category['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label for="used" class="block text-sm font-medium text-gray-700 mb-1">使用状态</label>
                                        <select name="used" id="used" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部状态</option>
                                            <option value="0" <?php echo $this->usedFilter === '0' ? 'selected' : ''; ?>>未使用</option>
                                            <option value="using" <?php echo $this->usedFilter === 'using' ? 'selected' : ''; ?>>使用中</option>
                                            <option value="1" <?php echo $this->usedFilter === '1' ? 'selected' : ''; ?>>已使用</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label for="ip_filter" class="block text-sm font-medium text-gray-700 mb-1">IP绑定状态</label>
                                        <select name="ip_filter" id="ip_filter" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部</option>
                                            <option value="bound" <?php echo $this->ipFilter === 'bound' ? 'selected' : ''; ?>>已绑定IP</option>
                                            <option value="unbound" <?php echo $this->ipFilter === 'unbound' ? 'selected' : ''; ?>>未绑定IP</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="flex justify-end">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                        <i class="fa fa-search mr-2"></i>搜索
                                    </button>
                                    <?php if (!empty($this->searchQuery) || !empty($this->categoryId) || $this->usedFilter !== '' || $this->ipFilter !== ''): ?>
                                        <a href="card_search.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                            <i class="fa fa-refresh mr-2"></i>重置
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- 搜索结果 -->
                    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
                        <!-- 结果统计 -->
                        <div class="px-4 py-3 border-b border-gray-200 sm:px-6">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center">
                                    <h3 class="text-lg font-medium text-gray-900">搜索结果</h3>
                                    <?php if (!empty($this->searchQuery)): ?>
                                        <span class="ml-2 text-sm text-gray-500">
                                            关键词: "<span class="font-medium text-blue-600"><?php echo htmlspecialchars($this->searchQuery); ?></span>"
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-sm text-gray-500">
                                    共找到 <span class="font-medium text-blue-600"><?php echo $this->totalCards; ?></span> 条结果
                                </div>
                            </div>
                        </div>
                        
                        <!-- 表格区域 -->
                        <?php if (empty($this->cards)): ?>
                            <!-- 空状态 -->
                            <div class="p-8 text-center">
                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                                    <i class="fa fa-search text-gray-400 text-2xl"></i>
                                </div>
                                <h3 class="text-lg font-medium text-gray-900">未找到相关卡密</h3>
                                <p class="mt-1 text-gray-500">没有找到符合条件的卡密，请尝试调整搜索条件</p>
                                <div class="mt-6">
                                    <a href="card_add.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                        <i class="fa fa-plus mr-2"></i>添加卡密
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- 桌面端表格视图 -->
                            <div class="overflow-x-auto hidden md:block">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">卡密代码</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">内容</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">使用状态</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">分类</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">创建时间</th>
                                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php foreach ($this->cards as $card): ?>
                                            <tr class="hover:bg-gray-50 transition-colors">
                                                <!-- 卡密代码 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-mono text-gray-900 max-w-xs truncate" title="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                        <?php echo htmlspecialchars($card['card_code']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 内容 -->
                                                <td class="px-6 py-4">
                                                    <div class="text-sm text-gray-900 max-w-xs truncate" title="<?php echo htmlspecialchars($card['content']); ?>">
                                                        <?php echo htmlspecialchars($card['content']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 使用状态 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <?php
                                                    $statusClass = '';
                                                    $statusText = '';
                                                    $statusIcon = '';
                                                    
                                                    switch ($card['status']) {
                                                        case 'expired':
                                                            $statusClass = 'bg-gray-100 text-gray-800';
                                                            $statusText = '已过期';
                                                            $statusIcon = 'fa-clock';
                                                            break;
                                                        case 'used':
                                                            $statusClass = 'bg-red-100 text-red-800';
                                                            $statusText = '已用完';
                                                            $statusIcon = 'fa-check-circle';
                                                            break;
                                                        case 'using':
                                                            $statusClass = 'bg-yellow-100 text-yellow-800';
                                                            $statusText = '使用中';
                                                            $statusIcon = 'fa-play-circle';
                                                            break;
                                                        case 'unused':
                                                        default:
                                                            $statusClass = 'bg-green-100 text-green-800';
                                                            $statusText = '未使用';
                                                            $statusIcon = 'fa-circle';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                                        <i class="fa <?php echo $statusIcon; ?> mr-1"></i>
                                                        <?php echo $statusText; ?>
                                                    </span>
                                                    <?php if ($card['max_uses'] > 1): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            <?php echo $card['current_uses']; ?>/<?php echo $card['max_uses']; ?> 次
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ($card['valid_until']): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            至 <?php echo date('m-d H:i', strtotime($card['valid_until'])); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if (!empty($card['first_use_ip'])): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            <i class="fa fa-map-marker mr-1"></i>绑定IP: <?php echo htmlspecialchars($card['first_use_ip']); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <!-- 分类 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm text-gray-900">
                                                        <?php echo empty($card['category_name']) ? '<span class="text-gray-400">未分类</span>' : htmlspecialchars($card['category_name']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 创建时间 -->
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo date('Y-m-d H:i', strtotime($card['created_at'])); ?>
                                                </td>
                                                
                                                <!-- 操作 -->
                                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                    <button class="copy-single text-green-600 hover:text-green-900 mr-3 btn-effect" 
                                                            data-code="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                        <i class="fa fa-copy mr-1"></i>复制
                                                    </button>
                                                    <a href="card_edit.php?id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->searchQuery) ? '&q=' . urlencode($this->searchQuery) : '';
                                                        echo $this->searchType !== 'code' ? '&type=' . $this->searchType : '';
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-indigo-600 hover:text-indigo-900 mr-3 btn-effect">
                                                        <i class="fa fa-pencil mr-1"></i>编辑
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- 移动端卡片视图 -->
                            <div class="p-4 md:hidden">
                                <?php foreach ($this->cards as $card): ?>
                                    <div class="bg-white border border-gray-200 rounded-lg mb-4 overflow-hidden card-hover">
                                        <div class="px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                                            <div class="flex items-center">
                                                <span class="text-sm font-medium text-gray-900">卡密 #<?php echo $card['id']; ?></span>
                                            </div>
                                            <?php
                                            $statusClass = '';
                                            $statusText = '';
                                            $statusIcon = '';
                                            
                                            switch ($card['status']) {
                                                case 'expired':
                                                    $statusClass = 'bg-gray-100 text-gray-800';
                                                    $statusText = '已过期';
                                                    $statusIcon = 'fa-clock';
                                                    break;
                                                case 'used':
                                                    $statusClass = 'bg-red-100 text-red-800';
                                                    $statusText = '已用完';
                                                    $statusIcon = 'fa-check-circle';
                                                    break;
                                                case 'using':
                                                    $statusClass = 'bg-yellow-100 text-yellow-800';
                                                    $statusText = '使用中';
                                                    $statusIcon = 'fa-play-circle';
                                                    break;
                                                case 'unused':
                                                default:
                                                    $statusClass = 'bg-green-100 text-green-800';
                                                    $statusText = '未使用';
                                                    $statusIcon = 'fa-circle';
                                                    break;
                                            }
                                            ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                                <i class="fa <?php echo $statusIcon; ?> mr-1"></i>
                                                <?php echo $statusText; ?>
                                            </span>
                                        </div>
                                        <div class="px-4 py-3">
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">卡密代码</div>
                                                <div class="text-sm font-mono text-gray-900 truncate" title="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                    <?php echo htmlspecialchars($card['card_code']); ?>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">内容</div>
                                                <div class="text-sm text-gray-900 truncate" title="<?php echo htmlspecialchars($card['content']); ?>">
                                                    <?php echo htmlspecialchars($card['content']); ?>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">分类</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo empty($card['category_name']) ? '<span class="text-gray-400">未分类</span>' : htmlspecialchars($card['category_name']); ?>
                                                </div>
                                            </div>
                                            <?php if ($card['max_uses'] > 1): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">使用次数</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo $card['current_uses']; ?>/<?php echo $card['max_uses']; ?> 次
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if ($card['valid_until']): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">有效期至</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo date('Y-m-d H:i:s', strtotime($card['valid_until'])); ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if (!empty($card['first_use_ip'])): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">绑定IP</div>
                                                <div class="text-sm text-gray-900">
                                                    <i class="fa fa-map-marker mr-1"></i><?php echo htmlspecialchars($card['first_use_ip']); ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <div class="text-xs text-gray-500">
                                                创建时间: <?php echo date('Y-m-d H:i', strtotime($card['created_at'])); ?>
                                            </div>
                                        </div>
                                        <div class="px-4 py-3 border-t border-gray-200 flex justify-end gap-3">
                                            <button class="copy-single text-green-600 hover:text-green-900 p-2 btn-effect" 
                                                    data-code="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                <i class="fa fa-copy"></i>
                                            </button>
                                            <a href="card_edit.php?id=<?php echo $card['id']; ?><?php 
                                                echo !empty($this->searchQuery) ? '&q=' . urlencode($this->searchQuery) : '';
                                                echo $this->searchType !== 'code' ? '&type=' . $this->searchType : '';
                                                echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                            ?>" class="text-indigo-600 hover:text-indigo-900 p-2 btn-effect">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <!-- 分页 -->
                        <?php if ($this->totalCards > 0): ?>
                            <div class="px-4 py-3 bg-white border-t border-gray-200 sm:px-6 flex items-center justify-between">
                                <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                    <div>
                                        <p class="text-sm text-gray-700">
                                            显示第 <span class="font-medium"><?php echo ($this->page - 1) * $this->limit + 1; ?></span> 到 <span class="font-medium"><?php echo min($this->page * $this->limit, $this->totalCards); ?></span> 条，共 <span class="font-medium"><?php echo $this->totalCards; ?></span> 条结果
                                        </p>
                                    </div>
                                    <div>
                                        <?php echo $this->renderPagination(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </main>
            </div>

            <!-- 侧边栏切换脚本 -->
            <script>
                // 侧边栏相关脚本
                document.getElementById('mobileMenuBtn').addEventListener('click', function() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    sidebar.classList.toggle('sidebar-hidden');
                    sidebar.classList.toggle('sidebar-visible');
                    overlay.classList.toggle('active');
                });

                document.getElementById('sidebarOverlay').addEventListener('click', function() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    sidebar.classList.add('sidebar-hidden');
                    sidebar.classList.remove('sidebar-visible');
                    overlay.classList.remove('active');
                });

                // 复制功能
                function showCopyNotify(text) {
                    const notify = document.getElementById('copyNotify');
                    const notifyText = document.getElementById('notifyText');
                    notifyText.textContent = text;
                    notify.classList.add('show');
                    setTimeout(() => {
                        notify.classList.remove('show');
                    }, 2000);
                }

                // 单个复制
                document.querySelectorAll('.copy-single').forEach(button => {
                    button.addEventListener('click', function() {
                        const code = this.getAttribute('data-code');
                        if (navigator.clipboard) {
                            navigator.clipboard.writeText(code).then(() => {
                                showCopyNotify('卡密代码已复制到剪贴板');
                            }).catch(() => {
                                showCopyNotify('复制失败，请手动复制');
                            });
                        } else {
                            showCopyNotify('复制失败，请手动复制');
                        }
                    });
                });

                // 搜索表单自动提交
                document.getElementById('searchForm').addEventListener('submit', function(e) {
                    const searchInput = document.getElementById('q');
                    if (searchInput.value.trim() === '') {
                        e.preventDefault();
                        showCopyNotify('请输入搜索关键词');
                        searchInput.focus();
                        return false;
                    }
                });
            </script>
        </body>
        </html>
        <?php
    }
}

// 运行应用
$cardSearch = new CardSearch();
$cardSearch->render();
?>
