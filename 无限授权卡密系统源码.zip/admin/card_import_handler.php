<?php
/**
 * 卡密导入处理接口
 * 提供AJAX接口用于处理文件上传和导入
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 设置响应头
header('Content-Type: application/json; charset=utf-8');

// 只允许POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => '只支持POST请求'
    ]);
    exit;
}

// 检查文件上传
if (!isset($_FILES['card_file']) || $_FILES['card_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode([
        'success' => false,
        'message' => '文件上传失败'
    ]);
    exit;
}

$file = $_FILES['card_file'];

try {
    // 验证文件
    $validation = validateUploadFile($file);
    if (!$validation['valid']) {
        echo json_encode([
            'success' => false,
            'message' => $validation['message']
        ]);
        exit;
    }
    
    // 解析文件
    $cards = parseCardFile($file['tmp_name'], $file['type']);
    if (empty($cards)) {
        echo json_encode([
            'success' => false,
            'message' => '文件中没有找到有效的卡密数据'
        ]);
        exit;
    }
    
    // 导入到数据库
    $result = importCardsToDatabase($cards);
    
    echo json_encode([
        'success' => true,
        'message' => '导入完成',
        'data' => $result
    ]);
    
} catch (Exception $e) {
    error_log("卡密导入错误：" . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => '导入失败：' . $e->getMessage()
    ]);
}

/**
 * 验证上传文件
 */
function validateUploadFile($file) {
    // 检查文件大小（限制10MB）
    if ($file['size'] > 10 * 1024 * 1024) {
        return [
            'valid' => false,
            'message' => '文件大小超过10MB限制'
        ];
    }
    
    // 检查文件类型
    $allowedTypes = [
        'text/csv',
        'text/plain', 
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    $fileType = mime_content_type($file['tmp_name']);
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowedExtensions = ['csv', 'txt', 'xlsx', 'xls'];
    
    if (!in_array($fileType, $allowedTypes) && !in_array($fileExtension, $allowedExtensions)) {
        return [
            'valid' => false,
            'message' => '不支持的文件类型，请上传CSV、TXT或Excel文件'
        ];
    }
    
    return ['valid' => true];
}

/**
 * 解析卡密文件
 */
function parseCardFile($filePath, $fileType) {
    $cards = [];
    
    if (strpos($fileType, 'csv') !== false || strpos($fileType, 'text') !== false) {
        $cards = parseCsvFile($filePath);
    } elseif (strpos($fileType, 'excel') !== false || strpos($fileType, 'spreadsheet') !== false) {
        $cards = parseExcelFile($filePath);
    }
    
    return $cards;
}

/**
 * 解析CSV文件
 */
function parseCsvFile($filePath) {
    $cards = [];
    $handle = fopen($filePath, 'r');
    
    if (!$handle) {
        return $cards;
    }
    
    // 检测BOM
    $bom = fread($handle, 3);
    if ($bom !== "\xEF\xBB\xBF") {
        rewind($handle);
    }
    
    $lineNumber = 0;
    while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
        $lineNumber++;
        
        // 跳过空行和注释行
        if (empty(array_filter($data)) || (isset($data[0]) && strpos(trim($data[0]), '#') === 0)) {
            continue;
        }
        
        // 至少需要卡密代码
        if (empty($data[0])) {
            continue;
        }
        
        $card = [
            'card_code' => trim($data[0]),
            'content' => isset($data[1]) ? trim($data[1]) : '',
            'max_uses' => isset($data[2]) ? (int)$data[2] : 1,
            'valid_until' => null,
            'category_id' => null
        ];
        
        // 验证使用次数
        if ($card['max_uses'] < 1 || $card['max_uses'] > 999) {
            $card['max_uses'] = 1;
        }
        
        // 处理有效期
        if (isset($data[3]) && !empty($data[3])) {
            $validUntil = strtotime($data[3]);
            if ($validUntil !== false) {
                $card['valid_until'] = date('Y-m-d H:i:s', $validUntil);
            }
        }
        
        // 处理分类ID
        if (isset($data[4]) && !empty($data[4])) {
            $card['category_id'] = (int)$data[4];
        }
        
        $cards[] = $card;
    }
    
    fclose($handle);
    return $cards;
}

/**
 * 解析Excel文件
 */
function parseExcelFile($filePath) {
    // 简化处理，实际项目中建议使用PhpSpreadsheet库
    // 这里将Excel文件转换为CSV格式处理
    $csvPath = $filePath . '.csv';
    
    // 尝试使用系统命令转换
    $command = "libreoffice --headless --convert-to csv --outdir " . dirname($filePath) . " " . escapeshellarg($filePath) . " 2>/dev/null";
    exec($command, $output, $returnCode);
    
    if ($returnCode === 0 && file_exists($csvPath)) {
        $cards = parseCsvFile($csvPath);
        unlink($csvPath); // 删除临时文件
        return $cards;
    }
    
    // 如果转换失败，返回空数组
    return [];
}

/**
 * 导入卡密到数据库
 */
function importCardsToDatabase($cards) {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        throw new Exception("数据库连接失败");
    }
    
    $result = [
        'total' => count($cards),
        'success' => 0,
        'failed' => 0,
        'duplicates' => 0,
        'errors' => []
    ];
    
    // 开始事务
    $pdo->beginTransaction();
    
    try {
        // 准备插入语句
        $stmt = $pdo->prepare("
            INSERT INTO cards (card_code, content, max_uses, valid_until, category_id, created_at) 
            VALUES (:card_code, :content, :max_uses, :valid_until, :category_id, NOW())
        ");
        
        // 准备检查重复的语句
        $checkStmt = $pdo->prepare("SELECT id FROM cards WHERE card_code = :card_code");
        
        foreach ($cards as $card) {
            try {
                // 检查卡密是否已存在
                $checkStmt->execute([':card_code' => $card['card_code']]);
                
                if ($checkStmt->fetch()) {
                    $result['duplicates']++;
                    continue;
                }
                
                // 插入新卡密
                $stmt->execute([
                    ':card_code' => $card['card_code'],
                    ':content' => $card['content'],
                    ':max_uses' => $card['max_uses'],
                    ':valid_until' => $card['valid_until'],
                    ':category_id' => $card['category_id']
                ]);
                
                $result['success']++;
                
            } catch (PDOException $e) {
                $result['failed']++;
                $result['errors'][] = "卡密 {$card['card_code']} 插入失败：" . $e->getMessage();
            }
        }
        
        $pdo->commit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
    return $result;
}
?>
