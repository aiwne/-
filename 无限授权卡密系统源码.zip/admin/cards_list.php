<?php
/**
 * 卡密管理列表页面
 * 功能：卡密分类筛选、使用状态筛选、全选、批量复制、批量删除、单独复制、单独删除
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化应用
class CardManager {
    private $pdo;
    private $message = '';
    private $messageType = '';
    private $page = 1;
    private $limit = 20;
    private $categoryId = '';
    private $usedFilter = '';
    private $ipFilter = '';
    private $totalCards = 0;
    private $cards = [];
    private $categories = [];

    public function __construct() {
        $this->initDb();
        $this->handleSession();
        $this->parseRequestParams();
        $this->handleActions();
        $this->loadCategories();
        $this->loadCards();
    }

    // 初始化数据库连接
    private function initDb() {
        try {
            $db = Database::getInstance();
            $this->pdo = $db->getPdo();
        } catch (PDOException $e) {
            $this->setMessage("数据库连接失败: " . $e->getMessage(), 'error');
            error_log("数据库连接错误: " . $e->getMessage());
        }
    }

    // 处理会话相关（CSRF令牌）
    private function handleSession() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    // 解析请求参数
    private function parseRequestParams() {
        // 分页参数
        if (isset($_GET['page']) && is_numeric($_GET['page'])) {
            $this->page = max(1, (int)$_GET['page']);
        }

        // 筛选参数
        if (isset($_GET['category']) && is_numeric($_GET['category'])) {
            $this->categoryId = (int)$_GET['category'];
        }

        if (isset($_GET['used']) && in_array($_GET['used'], ['0', '1', 'using'])) {
            $this->usedFilter = $_GET['used'];
        }


        // IP筛选参数
        if (isset($_GET['ip_filter']) && in_array($_GET['ip_filter'], ['bound', 'unbound'])) {
            $this->ipFilter = $_GET['ip_filter'];
        }

        // 消息参数
        if (isset($_GET['message']) && isset($_GET['type'])) {
            $this->message = urldecode($_GET['message']);
            $this->messageType = $_GET['type'];
        }
    }

    // 处理各种操作请求
    private function handleActions() {
        // 防止重复提交
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->validateCsrfToken();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_action'])) {
            $this->handleBatchAction();
        } elseif (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && is_numeric($_GET['id'])) {
            $this->handleSingleDelete((int)$_GET['id']);
        } elseif (isset($_GET['action']) && $_GET['action'] === 'unbind_ip' && isset($_GET['id']) && is_numeric($_GET['id'])) {
            $this->handleIpUnbind((int)$_GET['id']);
        } elseif (isset($_GET['action']) && $_GET['action'] === 'ban' && isset($_GET['id']) && is_numeric($_GET['id'])) {
            $this->handleCardBan((int)$_GET['id']);
        } elseif (isset($_GET['action']) && $_GET['action'] === 'unban' && isset($_GET['id']) && is_numeric($_GET['id'])) {
            $this->handleCardUnban((int)$_GET['id']);
        }
    }

    // CSRF令牌验证
    private function validateCsrfToken() {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $this->redirectWithMessage("操作失败：无效的请求令牌", 'error');
        }
    }

    // 处理批量操作
    private function handleBatchAction() {
        // 验证选中的ID
        if (empty($_POST['selected_ids'])) {
            $this->redirectWithMessage("请先选择要操作的卡密", 'error');
        }

        // 过滤并验证ID
        $validIds = array_unique(array_filter(array_map(function($id) {
            return is_numeric($id) && $id > 0 ? (int)$id : null;
        }, explode(',', $_POST['selected_ids']))));

        if (empty($validIds)) {
            $this->redirectWithMessage("未找到有效的卡密ID", 'error');
        }

        // 执行批量删除
        if ($_POST['batch_action'] === 'delete') {
            try {
                $placeholders = rtrim(str_repeat('?,', count($validIds)), ',');
                $stmt = $this->pdo->prepare("DELETE FROM cards WHERE id IN ($placeholders)");
                $stmt->execute($validIds);
                $this->redirectWithMessage("成功删除 " . $stmt->rowCount() . " 个卡密", 'success');
            } catch (PDOException $e) {
                $this->redirectWithMessage("删除失败: " . $e->getMessage(), 'error');
                error_log("批量删除卡密错误: " . $e->getMessage());
            }
        }
        
        // 执行批量编辑
        elseif ($_POST['batch_action'] === 'edit') {
            $this->handleBatchEdit($validIds);
        }
    }

    // 处理单个删除
    private function handleSingleDelete(int $cardId) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM cards WHERE id = :id");
            $stmt->execute([':id' => $cardId]);
            $this->redirectWithMessage("卡密已成功删除", 'success');
        } catch (PDOException $e) {
            $this->redirectWithMessage("删除失败: " . $e->getMessage(), 'error');
            error_log("删除卡密错误: " . $e->getMessage());
        }
    }

    // 处理IP换绑
    private function handleIpUnbind(int $cardId) {
        try {
            // 清除IP绑定信息，但保留其他使用记录
            $stmt = $this->pdo->prepare("UPDATE cards SET first_use_ip = NULL, last_use_ip = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmt->execute([':id' => $cardId]);
            
            if ($stmt->rowCount() > 0) {
                $this->redirectWithMessage("IP换绑成功，该卡密下次使用时将绑定新的IP地址", 'success');
            } else {
                $this->redirectWithMessage("未找到指定的卡密", 'error');
            }
        } catch (PDOException $e) {
            $this->redirectWithMessage("IP换绑失败: " . $e->getMessage(), 'error');
            error_log("IP换绑错误: " . $e->getMessage());
        }
    }

    // 处理卡密封禁
    private function handleCardBan(int $cardId) {
        try {
            // 封禁卡密（设置is_banned = 1）
            $stmt = $this->pdo->prepare("UPDATE cards SET is_banned = 1, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmt->execute([':id' => $cardId]);
            
            if ($stmt->rowCount() > 0) {
                $this->redirectWithMessage("卡密已成功封禁，该卡密将无法使用", 'success');
            } else {
                $this->redirectWithMessage("未找到指定的卡密", 'error');
            }
        } catch (PDOException $e) {
            $this->redirectWithMessage("封禁失败: " . $e->getMessage(), 'error');
            error_log("卡密封禁错误: " . $e->getMessage());
        }
    }

    // 处理卡密解禁
    private function handleCardUnban(int $cardId) {
        try {
            // 解禁卡密（设置is_banned = 0）
            $stmt = $this->pdo->prepare("UPDATE cards SET is_banned = 0, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmt->execute([':id' => $cardId]);
            
            if ($stmt->rowCount() > 0) {
                $this->redirectWithMessage("卡密已成功解禁，该卡密可以正常使用", 'success');
            } else {
                $this->redirectWithMessage("未找到指定的卡密", 'error');
            }
        } catch (PDOException $e) {
            $this->redirectWithMessage("解禁失败: " . $e->getMessage(), 'error');
            error_log("卡密解禁错误: " . $e->getMessage());
        }
    }
    
    // 处理批量编辑
    private function handleBatchEdit(array $validIds) {
        $newContent = trim($_POST['batch_content'] ?? '');
        $newCategoryId = !empty($_POST['batch_category']) ? (int)$_POST['batch_category'] : null;
        $newMaxUses = !empty($_POST['batch_max_uses']) ? max(1, (int)$_POST['batch_max_uses']) : null;
        $newValidUntil = !empty($_POST['batch_valid_until']) ? $_POST['batch_valid_until'] : null;
        
        // 验证输入
        if (empty($newContent) && $newCategoryId === null && $newMaxUses === null && $newValidUntil === null) {
            $this->redirectWithMessage("请至少填写一个要修改的字段", 'error');
        }
        
        // 验证有效时间格式
        if ($newValidUntil && !strtotime($newValidUntil)) {
            $this->redirectWithMessage("有效时间格式不正确", 'error');
        }
        
        try {
            $pdo = $this->pdo;
            $pdo->beginTransaction();
            
            $updateFields = [];
            $params = [];
            
            // 构建更新字段和参数
            $paramIndex = 1;
            $params = [];
            
            if (!empty($newContent)) {
                $updateFields[] = "content = ?";
                $params[] = $newContent;
                $paramIndex++;
            }
            
            if ($newCategoryId !== null) {
                $updateFields[] = "category_id = ?";
                $params[] = $newCategoryId;
                $paramIndex++;
            }
            
            if ($newMaxUses !== null) {
                $updateFields[] = "max_uses = ?";
                $params[] = $newMaxUses;
                $paramIndex++;
            }
            
            if ($newValidUntil !== null) {
                $updateFields[] = "valid_until = ?";
                $params[] = $newValidUntil ? date('Y-m-d H:i:s', strtotime($newValidUntil)) : null;
                $paramIndex++;
            }
            
            // 添加更新时间
            $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
            
            // 构建SQL - 使用位置参数
            $placeholders = rtrim(str_repeat('?,', count($validIds)), ',');
            $sql = "UPDATE cards SET " . implode(', ', $updateFields) . " WHERE id IN ($placeholders)";
            
            $stmt = $pdo->prepare($sql);
            
            // 合并参数：先添加更新字段的参数，再添加ID参数
            $allParams = array_merge($params, $validIds);
            $stmt->execute($allParams);
            
            $pdo->commit();
            
            $updatedCount = $stmt->rowCount();
            $this->redirectWithMessage("成功批量编辑 {$updatedCount} 个卡密", 'success');
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $this->redirectWithMessage("批量编辑失败: " . $e->getMessage(), 'error');
            error_log("批量编辑卡密错误: " . $e->getMessage());
        }
    }

    // 加载分类列表
    private function loadCategories() {
        try {
            $stmt = $this->pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
            $this->categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $this->setMessage("获取分类列表失败: " . $e->getMessage(), 'error');
            error_log("获取分类分类列表错误: " . $e->getMessage());
        }
    }

    // 加载卡密列表
    private function loadCards() {
        if (!$this->pdo) return;

        try {
            // 构建查询条件
            $conditions = [];
            $params = [];

            if (!empty($this->categoryId)) {
                $conditions[] = "category_id = :category_id";
                $params[':category_id'] = $this->categoryId;
            }

            if ($this->usedFilter !== '') {
                if ($this->usedFilter === 'using') {
                    // 使用中：已使用但未完全使用（current_uses > 0 且 current_uses < max_uses）
                    $conditions[] = "current_uses > 0 AND current_uses < max_uses";
                } else {
                    // 未使用(0)或已使用(1)
                    $conditions[] = "used = :used";
                    $params[':used'] = $this->usedFilter;
                }
            }


            if ($this->ipFilter === 'bound') {
                $conditions[] = "first_use_ip IS NOT NULL AND first_use_ip != ''";
            } elseif ($this->ipFilter === 'unbound') {
                $conditions[] = "(first_use_ip IS NULL OR first_use_ip = '')";
            }

            $whereClause = $conditions ? "WHERE " . implode(' AND ', $conditions) : '';

            // 查询总数
            $countStmt = $this->pdo->prepare("SELECT COUNT(*) FROM cards {$whereClause}");
            
            // 为查询总数绑定参数（不包含limit和offset）
            $countParams = [];
            foreach ($params as $key => $value) {
                if ($key !== ':limit' && $key !== ':offset') {
                    $countParams[$key] = $value;
                }
            }
            $countStmt->execute($countParams);
            $this->totalCards = (int)$countStmt->fetchColumn();

            // 计算分页偏移量
            $offset = ($this->page - 1) * $this->limit;

            // 使用简单的排序
            $orderBy = "ORDER BY c.created_at DESC";
            
            // 查询当前页数据
            $stmt = $this->pdo->prepare("
                SELECT c.*, cat.name AS category_name,
                       CASE 
                           WHEN c.is_banned = 1 THEN 'banned'
                           WHEN c.valid_until IS NOT NULL AND c.valid_until < NOW() THEN 'expired'
                           WHEN c.current_uses >= c.max_uses THEN 'used'
                           WHEN c.current_uses > 0 THEN 'using'
                           ELSE 'unused'
                       END as status
                FROM cards c
                LEFT JOIN categories cat ON c.category_id = cat.id
                {$whereClause}
                {$orderBy}
                LIMIT :limit OFFSET :offset
            ");
            
            // 为查询数据添加分页参数
            $dataParams = $params; // 复制基础参数
            $dataParams[':limit'] = $this->limit;
            $dataParams[':offset'] = $offset;

            $stmt->execute($dataParams);
            $this->cards = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            // 添加调试信息
            $debugInfo = [
                'usedFilter' => $this->usedFilter,
                'params' => $params,
                'whereClause' => $whereClause,
                'error' => $e->getMessage()
            ];
            error_log("获取卡密列表错误: " . json_encode($debugInfo, JSON_UNESCAPED_UNICODE));
            $this->setMessage("获取卡密列表失败: " . $e->getMessage(), 'error');
        }
    }

    // 设置消息
    private function setMessage(string $message, string $type) {
        $this->message = $message;
        $this->messageType = $type;
    }

    // 带消息重定向
    private function redirectWithMessage(string $message, string $type) {
        $redirectUrl = $this->buildRedirectUrl();
        header("Location: {$redirectUrl}&message=" . urlencode($message) . "&type=" . $type);
        exit;
    }

    // 构建重定向URL
    private function buildRedirectUrl() {
        $url = "cards_list.php?page={$this->page}";
        if (!empty($this->categoryId)) $url .= "&category=" . $this->categoryId;
        if ($this->usedFilter !== '') $url .= "&used=" . $this->usedFilter;
        if ($this->ipFilter !== '') $url .= "&ip_filter=" . $this->ipFilter;
        return $url;
    }

    // 生成分页HTML
    private function renderPagination() {
        if ($this->totalCards <= 0) return '';

        $totalPages = ceil($this->totalCards / $this->limit);
        $visiblePages = 5;
        $halfVisible = floor($visiblePages / 2);
        $startPage = max(1, $this->page - $halfVisible);
        $endPage = min($totalPages, $startPage + $visiblePages - 1);

        // 调整页码范围
        if ($endPage - $startPage < $visiblePages - 1) {
            $startPage = max(1, $endPage - $visiblePages + 1);
        }

        $pagination = '<nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">';
        
        // 上一页
        $prevPage = $this->page - 1;
        $prevUrl = $prevPage >= 1 ? $this->buildPageUrl($prevPage) : '#';
        $pagination .= '<a href="' . $prevUrl . '" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ' . ($prevPage < 1 ? 'opacity-50 cursor-not-allowed' : '') . '">';
        $pagination .= '<span class="sr-only">上一页</span><i class="fa fa-chevron-left text-xs"></i></a>';

        // 页码
        if ($startPage > 1) {
            $pagination .= '<a href="' . $this->buildPageUrl(1) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">1</a>';
            if ($startPage > 2) $pagination .= '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
        }

        for ($i = $startPage; $i <= $endPage; $i++) {
            $isActive = $i === $this->page;
            $pagination .= '<a href="' . $this->buildPageUrl($i) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium ' . ($isActive ? 'z-10 bg-blue-50 border-blue-500 text-blue-600' : 'text-gray-700 hover:bg-gray-50') . '">' . $i . '</a>';
        }

        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) $pagination .= '<span class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">...</span>';
            $pagination .= '<a href="' . $this->buildPageUrl($totalPages) . '" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">' . $totalPages . '</a>';
        }

        // 下一页
        $nextPage = $this->page + 1;
        $nextUrl = $nextPage <= $totalPages ? $this->buildPageUrl($nextPage) : '#';
        $pagination .= '<a href="' . $nextUrl . '" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ' . ($nextPage > $totalPages ? 'opacity-50 cursor-not-allowed' : '') . '">';
        $pagination .= '<span class="sr-only">下一页</span><i class="fa fa-chevron-right text-xs"></i></a>';
        
        $pagination .= '</nav>';
        return $pagination;
    }

    // 构建分页URL
    private function buildPageUrl(int $page) {
        $url = "cards_list.php?page={$page}";
        if (!empty($this->categoryId)) $url .= "&category=" . $this->categoryId;
        if ($this->usedFilter !== '') $url .= "&used=" . $this->usedFilter;
        if ($this->ipFilter !== '') $url .= "&ip_filter=" . $this->ipFilter;
        return $url;
    }

    // 渲染页面
    public function render() {
        ?>
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>卡密管理 - 卡密系统</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
            <style type="text/tailwindcss">
                @layer utilities {
                    .sidebar-visible {
                        transform: translateX(0);
                        visibility: visible;
                    }
                    .sidebar-hidden {
                        transform: translateX(-100%);
                        visibility: hidden;
                    }
                    .sidebar-overlay {
                        background-color: rgba(0, 0, 0, 0.5);
                        opacity: 0;
                        visibility: hidden;
                        transition: opacity 0.3s ease;
                    }
                    .sidebar-overlay.active {
                        opacity: 1;
                        visibility: visible;
                    }
                    .mobile-menu-btn {
                        @apply lg:hidden fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700;
                    }
                    .card-hover {
                        @apply transition-all duration-200 hover:shadow-md hover:-translate-y-1;
                    }
                    .btn-effect {
                        @apply transition-all duration-200 transform hover:scale-105 active:scale-95;
                    }
                    .fade-in {
                        animation: fadeIn 0.3s ease-in-out;
                    }
                    @keyframes fadeIn {
                        from { opacity: 0; }
                        to { opacity: 1; }
                    }
                    .copy-notify {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        padding: 12px 20px;
                        background: #10b981;
                        color: white;
                        border-radius: 4px;
                        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                        z-index: 9999;
                        opacity: 0;
                        transform: translateY(-20px);
                        transition: all 0.3s ease;
                    }
                    .copy-notify.show {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        </head>
        <body class="bg-gray-100">
            <!-- 移动端菜单按钮 -->
            <button id="mobileMenuBtn" class="mobile-menu-btn">
                <i class="fa fa-bars"></i>
            </button>
            <!-- 顶部导航 -->
            <header class="bg-white shadow h-16 lg:pl-64">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16">
                        <div class="flex items-center">
                            <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                        </div>
                        <div class="flex items-center">
                            <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                            <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                                <i class="fa fa-sign-out mr-1"></i>退出登录
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <!-- 侧边栏遮罩层 -->
            <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>
            <!-- 主容器 -->
            <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
                <!-- 侧边栏 -->
                <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
                    <div class="h-full pb-4">
                        <nav class="px-2 space-y-1">
                            <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-tachometer mr-3"></i>仪表盘
                            </a>
                            <a href="cards_list.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-list-alt mr-3"></i>卡密管理
                            </a>
                            <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-search mr-3"></i>卡密查询
                            </a>
                            <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-plus-circle mr-3"></i>添加卡密
                            </a>
                            <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                            <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-tags mr-3"></i>分类管理
                            </a>
                            <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-cubes mr-3"></i>批量生成
                            </a>
                            <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-bell mr-3"></i>Bark通知设置
                            </a>
                            <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                            </a>
                             <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                            <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-user mr-3"></i>个人设置
                            </a>
                        </nav>
                    </div>
                </aside>
                <!-- 主内容区 -->
                <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-semibold text-gray-800">卡密管理</h2>
                        <p class="mt-1 text-gray-600">管理所有卡密，支持搜索、筛选、复制和删除操作</p>
                    </div>
                    
                    <!-- 消息提示 -->
                    <?php if (!empty($this->message)): ?>
                        <div class="mb-6 p-4 rounded-md <?php 
                            echo $this->messageType === 'success' ? 'bg-green-100 text-green-800' : 
                                 ($this->messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                        ?>">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <?php if ($this->messageType === 'success'): ?>
                                        <i class="fa fa-check-circle text-green-500"></i>
                                    <?php elseif ($this->messageType === 'warning'): ?>
                                        <i class="fa fa-exclamation-triangle text-yellow-500"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times-circle text-red-500"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-3">
                                    <p><?php echo $this->message; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- 复制成功通知 -->
                    <div id="copyNotify" class="copy-notify">
                        <i class="fa fa-check mr-2"></i>
                        <span id="notifyText">复制成功</span>
                    </div>

                    <!-- 筛选表单 -->
                    <div class="bg-white shadow-sm rounded-lg mb-6 overflow-hidden">
                        <div class="p-4 md:p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4">筛选</h3>
                            <form method="get" class="space-y-4" id="filterForm">
                                
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label for="category" class="block text-sm font-medium text-gray-700 mb-1">卡密分类</label>
                                        <select name="category" id="category" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部分类</option>
                                            <?php foreach ($this->categories as $category): ?>
                                                <option value="<?php echo $category['id']; ?>" 
                                                    <?php echo $this->categoryId == $category['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($category['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label for="used" class="block text-sm font-medium text-gray-700 mb-1">使用状态</label>
                                        <select name="used" id="used" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部状态</option>
                                            <option value="0" <?php echo $this->usedFilter === '0' ? 'selected' : ''; ?>>未使用</option>
                                            <option value="using" <?php echo $this->usedFilter === 'using' ? 'selected' : ''; ?>>使用中</option>
                                            <option value="1" <?php echo $this->usedFilter === '1' ? 'selected' : ''; ?>>已使用</option>
                                        </select>
                                    </div>
                                    
                                    <div>
                                        <label for="ip_filter" class="block text-sm font-medium text-gray-700 mb-1">IP绑定状态</label>
                                        <select name="ip_filter" id="ip_filter" 
                                                class="block w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <option value="">全部</option>
                                            <option value="bound" <?php echo isset($_GET['ip_filter']) && $_GET['ip_filter'] === 'bound' ? 'selected' : ''; ?>>已绑定IP</option>
                                            <option value="unbound" <?php echo isset($_GET['ip_filter']) && $_GET['ip_filter'] === 'unbound' ? 'selected' : ''; ?>>未绑定IP</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="flex justify-end">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                        <i class="fa fa-filter mr-2"></i>筛选
                                    </button>
                                    <?php if (!empty($this->categoryId) || $this->usedFilter !== ''): ?>
                                        <a href="cards_list.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                            <i class="fa fa-refresh mr-2"></i>重置
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- 卡密列表和批量操作 -->
                    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
                        <!-- 批量操作栏 -->
                        <div class="px-4 py-3 border-b border-gray-200 sm:px-6 flex flex-wrap items-center justify-between gap-4">
                            <div class="flex items-center">
                                <div class="flex items-center">
                                    <input type="checkbox" id="selectAll" class="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                    <label for="selectAll" class="ml-2 block text-sm text-gray-700">全选</label>
                                </div>
                                <span id="selectedCount" class="ml-4 text-sm text-gray-500">已选择 <span class="font-medium">0</span> 项</span>
                            </div>
                            
                            <!-- 批量操作按钮组 - 移动端优化布局 -->
                            <div class="space-y-3">
                                <!-- 第一行：批量操作按钮 -->
                                <div class="flex flex-wrap gap-2">
                                    <button type="button" id="copySelected" disabled 
                                            class="flex-1 min-w-0 inline-flex items-center justify-center px-2 py-2 border border-gray-300 shadow-sm text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect opacity-50 cursor-not-allowed">
                                        <i class="fa fa-copy mr-1"></i>
                                        <span class="truncate">复制选中</span>
                                    </button>
                                    
                                    <button type="button" id="editSelected" disabled 
                                            class="flex-1 min-w-0 inline-flex items-center justify-center px-2 py-2 border border-gray-300 shadow-sm text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 btn-effect opacity-50 cursor-not-allowed">
                                        <i class="fa fa-edit mr-1"></i>
                                        <span class="truncate">批量编辑</span>
                                    </button>
                                    
                                    <button type="button" id="deleteSelected" disabled 
                                            class="flex-1 min-w-0 inline-flex items-center justify-center px-2 py-2 border border-transparent shadow-sm text-xs font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 btn-effect opacity-50 cursor-not-allowed">
                                        <i class="fa fa-trash mr-1"></i>
                                        <span class="truncate">删除选中</span>
                                    </button>
                                </div>
                                
                                <!-- 第二行：添加和生成按钮 -->
                                <div class="flex flex-wrap gap-2">
                                    <a href="card_add.php" class="flex-1 min-w-0 inline-flex items-center justify-center px-2 py-2 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                        <i class="fa fa-plus mr-1"></i>
                                        <span class="truncate">添加卡密</span>
                                    </a>
                                    <a href="batch_generate.php" class="flex-1 min-w-0 inline-flex items-center justify-center px-2 py-2 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 btn-effect">
                                        <i class="fa fa-cubes mr-1"></i>
                                        <span class="truncate">批量生成</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 批量删除表单 -->
                        <form method="post" id="batchDeleteForm" action="cards_list.php">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="batch_action" value="delete">
                            <input type="hidden" name="page" value="<?php echo $this->page; ?>">
                            <?php if (!empty($this->categoryId)): ?>
                                <input type="hidden" name="category" value="<?php echo $this->categoryId; ?>">
                            <?php endif; ?>
                            <?php if ($this->usedFilter !== ''): ?>
                                <input type="hidden" name="used" value="<?php echo $this->usedFilter; ?>">
                            <?php endif; ?>
                            <?php if ($this->ipFilter !== ''): ?>
                                <input type="hidden" name="ip_filter" value="<?php echo $this->ipFilter; ?>">
                            <?php endif; ?>
                            <input type="hidden" name="selected_ids" id="batchDeleteIds" value="">
                        </form>
                        
                        <!-- 批量编辑表单 -->
                        <form method="post" id="batchEditForm" action="cards_list.php">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <input type="hidden" name="batch_action" value="edit">
                            <input type="hidden" name="page" value="<?php echo $this->page; ?>">
                            <?php if (!empty($this->categoryId)): ?>
                                <input type="hidden" name="category" value="<?php echo $this->categoryId; ?>">
                            <?php endif; ?>
                            <?php if ($this->usedFilter !== ''): ?>
                                <input type="hidden" name="used" value="<?php echo $this->usedFilter; ?>">
                            <?php endif; ?>
                            <?php if ($this->ipFilter !== ''): ?>
                                <input type="hidden" name="ip_filter" value="<?php echo $this->ipFilter; ?>">
                            <?php endif; ?>
                            <input type="hidden" name="selected_ids" id="batchEditIds" value="">
                        </form>
                        
                        <!-- 表格区域 -->
                        <?php if (empty($this->cards)): ?>
                            <!-- 空状态 -->
                            <div class="p-8 text-center">
                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                                    <i class="fa fa-key text-gray-400 text-2xl"></i>
                                </div>
                                <h3 class="text-lg font-medium text-gray-900">暂无卡密数据</h3>
                                <p class="mt-1 text-gray-500">没有找到符合条件的卡密，请尝试调整筛选条件或添加新卡密</p>
                                <div class="mt-6">
                                    <a href="card_add.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 btn-effect">
                                        <i class="fa fa-plus mr-2"></i>添加卡密
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- 桌面端表格视图 -->
                            <div class="overflow-x-auto hidden md:block">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-12">
                                                <span class="sr-only">选择</span>
                                            </th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">卡密代码</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">内容</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">使用状态</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">分类</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">创建时间</th>
                                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php foreach ($this->cards as $card): ?>
                                            <tr class="hover:bg-gray-50 transition-colors">
                                                <!-- 复选框 - 添加data-type标识 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <input type="checkbox" name="selected_ids[]" 
                                                           class="card-checkbox h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" 
                                                           data-type="card-item"
                                                           data-id="<?php echo $card['id']; ?>"
                                                           data-code="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                </td>
                                                
                                                <!-- 卡密代码 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-mono text-gray-900 max-w-xs truncate" title="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                        <?php echo htmlspecialchars($card['card_code']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 内容 -->
                                                <td class="px-6 py-4">
                                                    <div class="text-sm text-gray-900 max-w-xs truncate" title="<?php echo htmlspecialchars($card['content']); ?>">
                                                        <?php echo htmlspecialchars($card['content']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 使用状态 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <?php
                                                    $statusClass = '';
                                                    $statusText = '';
                                                    $statusIcon = '';
                                                    
                                                    switch ($card['status']) {
                                                        case 'banned':
                                                            $statusClass = 'bg-red-100 text-red-800';
                                                            $statusText = '封禁中';
                                                            $statusIcon = 'fa-ban';
                                                            break;
                                                        case 'expired':
                                                            $statusClass = 'bg-gray-100 text-gray-800';
                                                            $statusText = '已过期';
                                                            $statusIcon = 'fa-clock';
                                                            break;
                                                        case 'used':
                                                            $statusClass = 'bg-red-100 text-red-800';
                                                            $statusText = '已用完';
                                                            $statusIcon = 'fa-check-circle';
                                                            break;
                                                        case 'using':
                                                            $statusClass = 'bg-yellow-100 text-yellow-800';
                                                            $statusText = '使用中';
                                                            $statusIcon = 'fa-play-circle';
                                                            break;
                                                        case 'unused':
                                                        default:
                                                            $statusClass = 'bg-green-100 text-green-800';
                                                            $statusText = '未使用';
                                                            $statusIcon = 'fa-circle';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                                        <i class="fa <?php echo $statusIcon; ?> mr-1"></i>
                                                        <?php echo $statusText; ?>
                                                    </span>
                                                    <?php if ($card['max_uses'] > 1): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            <?php echo $card['current_uses']; ?>/<?php echo $card['max_uses']; ?> 次
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ($card['valid_until']): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            至 <?php echo date('m-d H:i', strtotime($card['valid_until'])); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if (!empty($card['first_use_ip'])): ?>
                                                        <div class="text-xs text-gray-500 mt-1">
                                                            <i class="fa fa-map-marker mr-1"></i>绑定IP: <?php echo htmlspecialchars($card['first_use_ip']); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <!-- 分类 -->
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm text-gray-900">
                                                        <?php echo empty($card['category_name']) ? '<span class="text-gray-400">未分类</span>' : htmlspecialchars($card['category_name']); ?>
                                                    </div>
                                                </td>
                                                
                                                <!-- 创建时间 -->
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo date('Y-m-d H:i', strtotime($card['created_at'])); ?>
                                                </td>
                                                
                                                <!-- 操作 -->
                                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                    <button class="copy-single text-green-600 hover:text-green-900 mr-3 btn-effect" 
                                                            data-code="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                        <i class="fa fa-copy mr-1"></i>复制
                                                    </button>
                                                    <a href="card_edit.php?id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-indigo-600 hover:text-indigo-900 mr-3 btn-effect">
                                                        <i class="fa fa-pencil mr-1"></i>编辑
                                                    </a>
                                                    <?php if (!empty($card['first_use_ip'])): ?>
                                                    <a href="?action=unbind_ip&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-orange-600 hover:text-orange-900 mr-3 btn-effect unbind-ip"
                                                       data-id="<?php echo $card['id']; ?>" 
                                                       data-ip="<?php echo htmlspecialchars($card['first_use_ip']); ?>">
                                                        <i class="fa fa-unlink mr-1"></i>IP换绑
                                                    </a>
                                                    <?php endif; ?>
                                                    <?php if (isset($card['is_banned']) && $card['is_banned']): ?>
                                                    <a href="?action=unban&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-green-600 hover:text-green-900 mr-3 btn-effect unban-card"
                                                       data-id="<?php echo $card['id']; ?>">
                                                        <i class="fa fa-check-circle mr-1"></i>解禁
                                                    </a>
                                                    <?php else: ?>
                                                    <a href="?action=ban&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-red-600 hover:text-red-900 mr-3 btn-effect ban-card"
                                                       data-id="<?php echo $card['id']; ?>">
                                                        <i class="fa fa-ban mr-1"></i>封禁
                                                    </a>
                                                    <?php endif; ?>
                                                    <a href="?action=delete&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="text-red-600 hover:text-red-900 btn-effect delete-single"
                                                       data-id="<?php echo $card['id']; ?>">
                                                        <i class="fa fa-trash mr-1"></i>删除
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- 移动端卡片视图 -->
                            <div class="p-4 md:hidden">
                                <?php foreach ($this->cards as $card): ?>
                                    <div class="bg-white border border-gray-200 rounded-lg mb-4 overflow-hidden card-hover">
                                        <div class="px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                                            <div class="flex items-center">
                                                <!-- 复选框 - 添加data-type标识 -->
                                                <input type="checkbox" name="selected_ids[]" 
                                                       class="card-checkbox h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" 
                                                       data-type="card-item"
                                                       data-id="<?php echo $card['id']; ?>"
                                                       data-code="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                <span class="ml-2 text-sm font-medium text-gray-900">卡密 #<?php echo $card['id']; ?></span>
                                            </div>
                                            <?php
                                            $statusClass = '';
                                            $statusText = '';
                                            $statusIcon = '';
                                            
                                            switch ($card['status']) {
                                                case 'banned':
                                                    $statusClass = 'bg-red-100 text-red-800';
                                                    $statusText = '封禁中';
                                                    $statusIcon = 'fa-ban';
                                                    break;
                                                case 'expired':
                                                    $statusClass = 'bg-gray-100 text-gray-800';
                                                    $statusText = '已过期';
                                                    $statusIcon = 'fa-clock';
                                                    break;
                                                case 'used':
                                                    $statusClass = 'bg-red-100 text-red-800';
                                                    $statusText = '已用完';
                                                    $statusIcon = 'fa-check-circle';
                                                    break;
                                                case 'using':
                                                    $statusClass = 'bg-yellow-100 text-yellow-800';
                                                    $statusText = '使用中';
                                                    $statusIcon = 'fa-play-circle';
                                                    break;
                                                case 'unused':
                                                default:
                                                    $statusClass = 'bg-green-100 text-green-800';
                                                    $statusText = '未使用';
                                                    $statusIcon = 'fa-circle';
                                                    break;
                                            }
                                            ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $statusClass; ?>">
                                                <i class="fa <?php echo $statusIcon; ?> mr-1"></i>
                                                <?php echo $statusText; ?>
                                            </span>
                                        </div>
                                        <div class="px-4 py-3">
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">卡密代码</div>
                                                <div class="text-sm font-mono text-gray-900 truncate" title="<?php echo htmlspecialchars($card['card_code']); ?>">
                                                    <?php echo htmlspecialchars($card['card_code']); ?>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">内容</div>
                                                <div class="text-sm text-gray-900 truncate" title="<?php echo htmlspecialchars($card['content']); ?>">
                                                    <?php echo htmlspecialchars($card['content']); ?>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">分类</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo empty($card['category_name']) ? '<span class="text-gray-400">未分类</span>' : htmlspecialchars($card['category_name']); ?>
                                                </div>
                                            </div>
                                            <?php if ($card['max_uses'] > 1): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">使用次数</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo $card['current_uses']; ?>/<?php echo $card['max_uses']; ?> 次
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if ($card['valid_until']): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">有效期至</div>
                                                <div class="text-sm text-gray-900">
                                                    <?php echo date('Y-m-d H:i:s', strtotime($card['valid_until'])); ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if (!empty($card['first_use_ip'])): ?>
                                            <div class="mb-2">
                                                <div class="text-xs text-gray-500 mb-1">绑定IP</div>
                                                <div class="text-sm text-gray-900">
                                                    <i class="fa fa-map-marker mr-1"></i><?php echo htmlspecialchars($card['first_use_ip']); ?>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <div class="text-xs text-gray-500">
                                                创建时间: <?php echo date('Y-m-d H:i', strtotime($card['created_at'])); ?>
                                            </div>
                                        </div>
                                        <div class="px-4 py-3 border-t border-gray-200">
                                            <!-- 操作按钮组 - 移动端优化布局 -->
                                            <div class="space-y-2">
                                                <!-- 主要操作按钮行 -->
                                                <div class="flex justify-center gap-3">
                                                    <button class="copy-single flex-1 bg-green-50 hover:bg-green-100 text-green-700 py-2 px-3 rounded-md text-sm font-medium transition-colors btn-effect" 
                                                            data-code="<?php echo htmlspecialchars($card['card_code']); ?>"
                                                            title="复制卡密">
                                                        <i class="fa fa-copy mr-1"></i>复制
                                                    </button>
                                                    <a href="card_edit.php?id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="flex-1 bg-blue-50 hover:bg-blue-100 text-blue-700 py-2 px-3 rounded-md text-sm font-medium transition-colors btn-effect text-center"
                                                       title="编辑卡密">
                                                        <i class="fa fa-pencil mr-1"></i>编辑
                                                    </a>
                                                </div>
                                                
                                                <!-- 次要操作按钮行 -->
                                                <div class="flex justify-center gap-2">
                                                    <?php if (!empty($card['first_use_ip'])): ?>
                                                    <a href="?action=unbind_ip&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="flex-1 bg-orange-50 hover:bg-orange-100 text-orange-700 py-2 px-2 rounded-md text-xs font-medium transition-colors btn-effect unbind-ip text-center"
                                                       data-id="<?php echo $card['id']; ?>" 
                                                       data-ip="<?php echo htmlspecialchars($card['first_use_ip']); ?>"
                                                       title="IP换绑">
                                                        <i class="fa fa-unlink mr-1"></i>IP换绑
                                                    </a>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (isset($card['is_banned']) && $card['is_banned']): ?>
                                                    <a href="?action=unban&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="flex-1 bg-green-50 hover:bg-green-100 text-green-700 py-2 px-2 rounded-md text-xs font-medium transition-colors btn-effect unban-card text-center"
                                                       data-id="<?php echo $card['id']; ?>"
                                                       title="解禁卡密">
                                                        <i class="fa fa-check-circle mr-1"></i>解禁
                                                    </a>
                                                    <?php else: ?>
                                                    <a href="?action=ban&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="flex-1 bg-red-50 hover:bg-red-100 text-red-700 py-2 px-2 rounded-md text-xs font-medium transition-colors btn-effect ban-card text-center"
                                                       data-id="<?php echo $card['id']; ?>"
                                                       title="封禁卡密">
                                                        <i class="fa fa-ban mr-1"></i>封禁
                                                    </a>
                                                    <?php endif; ?>
                                                    
                                                    <a href="?action=delete&id=<?php echo $card['id']; ?>&page=<?php echo $this->page; ?><?php 
                                                        echo !empty($this->categoryId) ? '&category=' . $this->categoryId : '';
                                                        echo $this->usedFilter !== '' ? '&used=' . $this->usedFilter : '';
                                                        echo $this->ipFilter !== '' ? '&ip_filter=' . $this->ipFilter : '';
                                                    ?>" class="flex-1 bg-red-50 hover:bg-red-100 text-red-700 py-2 px-2 rounded-md text-xs font-medium transition-colors btn-effect delete-single text-center"
                                                       data-id="<?php echo $card['id']; ?>"
                                                       title="删除卡密">
                                                        <i class="fa fa-trash mr-1"></i>删除
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <!-- 分页 -->
                        <?php if ($this->totalCards > 0): ?>
                            <div class="px-4 py-3 bg-white border-t border-gray-200 sm:px-6 flex items-center justify-between">
                                <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                    <div>
                                        <p class="text-sm text-gray-700">
                                            显示第 <span class="font-medium"><?php echo ($this->page - 1) * $this->limit + 1; ?></span> 到 <span class="font-medium"><?php echo min($this->page * $this->limit, $this->totalCards); ?></span> 条，共 <span class="font-medium"><?php echo $this->totalCards; ?></span> 条结果
                                        </p>
                                    </div>
                                    <div>
                                        <?php echo $this->renderPagination(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </main>
            </div>

            <!-- 批量编辑模态框 -->
            <div id="batchEditModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 hidden">
                <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-2/3 lg:w-1/2 shadow-lg rounded-md bg-white">
                    <div class="mt-3">
                        <!-- 模态框头部 -->
                        <div class="flex items-center justify-between pb-4 border-b border-gray-200">
                            <h3 class="text-lg font-medium text-gray-900">
                                <i class="fa fa-edit mr-2 text-green-600"></i>批量编辑卡密
                            </h3>
                            <button type="button" id="closeBatchEditModal" class="text-gray-400 hover:text-gray-600">
                                <i class="fa fa-times text-xl"></i>
                            </button>
                        </div>
                        
                        <!-- 模态框内容 -->
                        <div class="mt-4">
                            <div class="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                                <p class="text-sm text-blue-800">
                                    <i class="fa fa-info-circle mr-2"></i>
                                    将批量编辑 <span id="selectedCountText" class="font-semibold">0</span> 个卡密，只填写需要修改的字段即可。
                                </p>
                            </div>
                            
                            <form id="batchEditContentForm" class="space-y-4">
                                <!-- 卡密内容 -->
                                <div>
                                    <label for="batch_content" class="block text-sm font-medium text-gray-700 mb-1">
                                        卡密内容
                                    </label>
                                    <textarea name="batch_content" id="batch_content" rows="3" 
                                              placeholder="输入新的卡密内容（留空表示不修改）"
                                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"></textarea>
                                    <p class="mt-1 text-xs text-gray-500">所有选中卡密的内容将被统一修改为此内容</p>
                                </div>
                                
                                <!-- 分类 -->
                                <div>
                                    <label for="batch_category" class="block text-sm font-medium text-gray-700 mb-1">
                                        卡密分类
                                    </label>
                                    <select name="batch_category" id="batch_category" 
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                        <option value="">不修改分类</option>
                                        <?php foreach ($this->categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>">
                                                <?php echo htmlspecialchars($category['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- 使用次数和有效期 -->
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label for="batch_max_uses" class="block text-sm font-medium text-gray-700 mb-1">
                                            最大使用次数
                                        </label>
                                        <input type="number" name="batch_max_uses" id="batch_max_uses" 
                                               min="1" max="999" placeholder="留空表示不修改"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                    </div>
                                    
                                    <div>
                                        <label for="batch_valid_until" class="block text-sm font-medium text-gray-700 mb-1">
                                            有效期至
                                        </label>
                                        <input type="datetime-local" name="batch_valid_until" id="batch_valid_until" 
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                        <p class="mt-1 text-xs text-gray-500">留空表示不修改有效期</p>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        <!-- 模态框底部 -->
                        <div class="flex justify-end space-x-3 mt-6 pt-4 border-t border-gray-200">
                            <button type="button" id="cancelBatchEdit" 
                                    class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                                <i class="fa fa-times mr-2"></i>取消
                            </button>
                            <button type="button" id="confirmBatchEdit" 
                                    class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                <i class="fa fa-check mr-2"></i>确认编辑
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 侧边栏切换脚本 -->
            <script>
                // 侧边栏相关脚本
                document.getElementById('mobileMenuBtn').addEventListener('click', function() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    sidebar.classList.toggle('sidebar-hidden');
                    sidebar.classList.toggle('sidebar-visible');
                    overlay.classList.toggle('active');
                });

                document.getElementById('sidebarOverlay').addEventListener('click', function() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    sidebar.classList.add('sidebar-hidden');
                    sidebar.classList.remove('sidebar-visible');
                    overlay.classList.remove('active');
                });

                // IP换绑确认对话框
                document.addEventListener('click', function(e) {
                    if (e.target.closest('.unbind-ip')) {
                        e.preventDefault();
                        const link = e.target.closest('.unbind-ip');
                        const cardId = link.getAttribute('data-id');
                        const ip = link.getAttribute('data-ip');
                        
                        if (confirm(`确定要解除卡密ID ${cardId} 的IP绑定吗？\n\n当前绑定IP: ${ip}\n\n解除后，该卡密下次使用时将绑定新的IP地址。`)) {
                            window.location.href = link.href;
                        }
                    }
                    
                    // 卡密封禁确认对话框
                    if (e.target.closest('.ban-card')) {
                        e.preventDefault();
                        const link = e.target.closest('.ban-card');
                        const cardId = link.getAttribute('data-id');
                        
                        if (confirm(`确定要封禁卡密ID ${cardId} 吗？\n\n封禁后，该卡密将无法使用。`)) {
                            window.location.href = link.href;
                        }
                    }
                    
                    // 卡密解禁确认对话框
                    if (e.target.closest('.unban-card')) {
                        e.preventDefault();
                        const link = e.target.closest('.unban-card');
                        const cardId = link.getAttribute('data-id');
                        
                        if (confirm(`确定要解禁卡密ID ${cardId} 吗？\n\n解禁后，该卡密可以正常使用。`)) {
                            window.location.href = link.href;
                        }
                    }
                });
                
                // 批量编辑功能
                const batchEditModal = document.getElementById('batchEditModal');
                const editSelectedBtn = document.getElementById('editSelected');
                const closeBatchEditModal = document.getElementById('closeBatchEditModal');
                const cancelBatchEdit = document.getElementById('cancelBatchEdit');
                const confirmBatchEdit = document.getElementById('confirmBatchEdit');
                const batchEditForm = document.getElementById('batchEditForm');
                const selectedCountText = document.getElementById('selectedCountText');
                
                // 打开批量编辑模态框
                editSelectedBtn.addEventListener('click', function() {
                    const selectedIds = getSelectedIds();
                    if (selectedIds.length === 0) {
                        alert('请先选择要编辑的卡密');
                        return;
                    }
                    
                    selectedCountText.textContent = selectedIds.length;
                    batchEditModal.classList.remove('hidden');
                });
                
                // 关闭批量编辑模态框
                function closeBatchEditModalFunc() {
                    batchEditModal.classList.add('hidden');
                    // 清空表单
                    document.getElementById('batchEditContentForm').reset();
                }
                
                closeBatchEditModal.addEventListener('click', closeBatchEditModalFunc);
                cancelBatchEdit.addEventListener('click', closeBatchEditModalFunc);
                
                // 点击模态框背景关闭
                batchEditModal.addEventListener('click', function(e) {
                    if (e.target === batchEditModal) {
                        closeBatchEditModalFunc();
                    }
                });
                
                // 确认批量编辑
                confirmBatchEdit.addEventListener('click', function() {
                    const selectedIds = getSelectedIds();
                    if (selectedIds.length === 0) {
                        alert('请先选择要编辑的卡密');
                        return;
                    }
                    
                    // 获取表单数据
                    const formData = new FormData(document.getElementById('batchEditContentForm'));
                    const content = formData.get('batch_content')?.trim();
                    const category = formData.get('batch_category');
                    const maxUses = formData.get('batch_max_uses');
                    const validUntil = formData.get('batch_valid_until');
                    
                    // 验证至少有一个字段被填写
                    if (!content && !category && !maxUses && !validUntil) {
                        alert('请至少填写一个要修改的字段');
                        return;
                    }
                    
                    // 确认操作
                    if (!confirm(`确定要批量编辑 ${selectedIds.length} 个卡密吗？`)) {
                        return;
                    }
                    
                    // 设置表单数据并提交
                    document.getElementById('batchEditIds').value = selectedIds.join(',');
                    
                    // 将表单数据添加到批量编辑表单
                    const batchForm = document.getElementById('batchEditForm');
                    const formInputs = document.getElementById('batchEditContentForm').elements;
                    
                    // 清除之前的表单数据
                    const existingInputs = batchForm.querySelectorAll('input[name^="batch_"]');
                    existingInputs.forEach(input => {
                        if (input.name !== 'batch_action' && input.name !== 'selected_ids') {
                            input.remove();
                        }
                    });
                    
                    // 添加新的表单数据
                    for (let input of formInputs) {
                        if (input.name && input.value) {
                            const hiddenInput = document.createElement('input');
                            hiddenInput.type = 'hidden';
                            hiddenInput.name = input.name;
                            hiddenInput.value = input.value;
                            batchForm.appendChild(hiddenInput);
                        }
                    }
                    
                    // 提交表单
                    batchForm.submit();
                });
                
                // 获取选中的卡密ID
                function getSelectedIds() {
                    const checkboxes = document.querySelectorAll('.card-checkbox:checked');
                    return Array.from(checkboxes).map(cb => cb.getAttribute('data-id'));
                }
                
                // 更新批量编辑按钮状态
                function updateBatchEditButton() {
                    const selectedCount = getSelectedIds().length;
                    const editBtn = document.getElementById('editSelected');
                    
                    if (selectedCount > 0) {
                        editBtn.disabled = false;
                        editBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                        editBtn.classList.add('hover:bg-gray-50');
                    } else {
                        editBtn.disabled = true;
                        editBtn.classList.add('opacity-50', 'cursor-not-allowed');
                        editBtn.classList.remove('hover:bg-gray-50');
                    }
                }
                
                // 监听复选框变化
                document.addEventListener('change', function(e) {
                    if (e.target.classList.contains('card-checkbox')) {
                        updateBatchEditButton();
                    }
                });
                
                // 初始化批量编辑按钮状态
                updateBatchEditButton();
            </script>
            
            <!-- 引入批量操作脚本 -->
            <script src="card_batch_actions.js?v=<?php echo time(); ?>"></script>
                    </div>
                </main>
            </div>
        </body>
        </html>
        <?php
    }
}

// 运行应用
$cardManager = new CardManager();
$cardManager->render();
?>
    