<?php
/**
 * 卡密上传页面
 * 支持CSV、TXT、Excel文件上传和批量导入
 */
require_once 'auth.php';
require_once '../db_connect.php';
require_once 'upload_validator.php';

// 初始化变量
$message = '';
$messageType = '';
$uploadStats = [
    'total' => 0,
    'success' => 0,
    'failed' => 0,
    'duplicates' => 0,
    'errors' => []
];

// 处理文件上传
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['card_file'])) {
    try {
        // 获取上传选项
        $defaultCategory = !empty($_POST['default_category']) ? (int)$_POST['default_category'] : null;
        $defaultMaxUses = !empty($_POST['default_max_uses']) ? (int)$_POST['default_max_uses'] : 1;
        $defaultContent = !empty($_POST['default_content']) ? trim($_POST['default_content']) : '';
        $defaultValidUntil = !empty($_POST['default_valid_until']) ? trim($_POST['default_valid_until']) : null;
        
        // 验证文件
        $validation = UploadValidator::validateFile($_FILES['card_file']);
        if (!$validation['valid']) {
            $message = "文件验证失败：" . implode('; ', $validation['errors']);
            $messageType = 'error';
        } else {
            // 验证CSV内容
            $contentValidation = UploadValidator::validateCsvContent($_FILES['card_file']['tmp_name']);
            if (!$contentValidation['valid']) {
                $message = "文件内容验证失败：" . implode('; ', $contentValidation['errors']);
                if (!empty($contentValidation['warnings'])) {
                    $message .= "<br>警告：" . implode('; ', $contentValidation['warnings']);
                }
                $messageType = 'error';
            } else {
                $uploadStats = handleCardUpload($_FILES['card_file'], [
                    'default_category' => $defaultCategory,
                    'default_max_uses' => $defaultMaxUses,
                    'default_content' => $defaultContent,
                    'default_valid_until' => $defaultValidUntil
                ]);
                
                if ($uploadStats['success'] > 0) {
                    $message = "上传成功！共处理 {$uploadStats['total']} 条记录，成功导入 {$uploadStats['success']} 条";
                    if ($uploadStats['duplicates'] > 0) {
                        $message .= "，跳过重复 {$uploadStats['duplicates']} 条";
                    }
                    if ($uploadStats['failed'] > 0) {
                        $message .= "，失败 {$uploadStats['failed']} 条";
                    }
                    $messageType = 'success';
                } else {
                    $message = "上传失败：" . implode('; ', $uploadStats['errors']);
                    $messageType = 'error';
                }
            }
        }
    } catch (Exception $e) {
        $message = "上传处理失败：" . $e->getMessage();
        $messageType = 'error';
        error_log("卡密上传错误：" . $e->getMessage());
    }
}

/**
 * 处理卡密文件上传
 */
function handleCardUpload($file, $defaults = []) {
    global $pdo;
    
    $stats = [
        'total' => 0,
        'success' => 0,
        'failed' => 0,
        'duplicates' => 0,
        'errors' => []
    ];
    
    // 解析文件内容
    $fileType = UploadValidator::getMimeType($file['tmp_name']);
    error_log("文件类型: " . $fileType);
    error_log("默认值: " . json_encode($defaults));
    
    $cards = parseCardFile($file['tmp_name'], $fileType, $defaults);
    error_log("解析到的卡密数量: " . count($cards));
    
    if (empty($cards)) {
        $stats['errors'][] = "文件中没有找到有效的卡密数据";
        $stats['errors'][] = "文件类型: " . $fileType;
        $stats['errors'][] = "文件内容预览: " . substr(file_get_contents($file['tmp_name']), 0, 200);
        return $stats;
    }
    
    $stats['total'] = count($cards);
    
    // 获取数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        $stats['errors'][] = "数据库连接失败";
        return $stats;
    }
    
    // 开始事务
    $pdo->beginTransaction();
    
    try {
        // 准备插入语句
        $stmt = $pdo->prepare("
            INSERT INTO cards (card_code, content, max_uses, valid_until, category_id, created_at) 
            VALUES (:card_code, :content, :max_uses, :valid_until, :category_id, NOW())
        ");
        
        foreach ($cards as $card) {
            try {
                // 检查卡密是否已存在
                $checkStmt = $pdo->prepare("SELECT id FROM cards WHERE card_code = :card_code");
                $checkStmt->execute([':card_code' => $card['card_code']]);
                
                if ($checkStmt->fetch()) {
                    $stats['duplicates']++;
                    continue;
                }
                
                // 插入新卡密
                $stmt->execute([
                    ':card_code' => $card['card_code'],
                    ':content' => $card['content'] ?? '',
                    ':max_uses' => $card['max_uses'] ?? 1,
                    ':valid_until' => $card['valid_until'] ?? null,
                    ':category_id' => $card['category_id'] ?? null
                ]);
                
                $stats['success']++;
                
            } catch (PDOException $e) {
                $stats['failed']++;
                $stats['errors'][] = "卡密 {$card['card_code']} 插入失败：" . $e->getMessage();
            }
        }
        
        $pdo->commit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $stats['errors'][] = "数据库操作失败：" . $e->getMessage();
    }
    
    return $stats;
}

/**
 * 解析卡密文件
 */
function parseCardFile($filePath, $fileType, $defaults = []) {
    $cards = [];
    
    // 检查文件扩展名作为备用判断
    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    
    // 如果是CSV或文本文件，或者文件扩展名是txt/csv，都使用CSV解析器
    if (strpos($fileType, 'csv') !== false || 
        strpos($fileType, 'text') !== false || 
        strpos($fileType, 'plain') !== false ||
        $extension === 'txt' || 
        $extension === 'csv') {
        $cards = parseCsvFile($filePath, $defaults);
    } elseif (strpos($fileType, 'excel') !== false || 
               strpos($fileType, 'spreadsheet') !== false ||
               $extension === 'xlsx' || 
               $extension === 'xls') {
        $cards = parseExcelFile($filePath, $defaults);
    } else {
        // 默认尝试作为文本文件处理
        error_log("未知文件类型，尝试作为文本文件处理: " . $fileType);
        $cards = parseCsvFile($filePath, $defaults);
    }
    
    return $cards;
}

/**
 * 解析CSV文件
 */
function parseCsvFile($filePath, $defaults = []) {
    $cards = [];
    
    // 直接读取文件内容，避免复杂的文件指针操作
    $content = file_get_contents($filePath);
    if ($content === false) {
        return $cards;
    }
    
    // 移除BOM
    if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
        $content = substr($content, 3);
    }
    
    // 按行分割，同时处理Windows和Unix换行符
    $lines = preg_split('/\r\n|\r|\n/', $content);
    error_log("文件总行数: " . count($lines));
    
    // 如果只有一行且包含空格，可能是被合并的卡密数据
    if (count($lines) === 1 && strpos($lines[0], ' ') !== false && strpos($lines[0], ',') === false) {
        error_log("检测到单行空格分隔格式，尝试分割");
        $lines = explode(' ', $lines[0]);
        $lines = array_filter($lines, function($line) {
            return !empty(trim($line));
        });
        error_log("分割后行数: " . count($lines));
    }
    
    // 检测格式：检查第一行是否包含逗号
    $isCsvFormat = false;
    if (!empty($lines[0]) && strpos($lines[0], ',') !== false) {
        $isCsvFormat = true;
    }
    error_log("CSV格式: " . ($isCsvFormat ? '是' : '否'));
    error_log("第一行: '" . trim($lines[0] ?? '') . "'");
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        // 跳过空行
        if (empty($line)) {
            continue;
        }
        
        // 跳过注释行
        if (strpos($line, '#') === 0) {
            continue;
        }
        
        if ($isCsvFormat) {
            // CSV格式：解析CSV行
            $data = str_getcsv($line, ',');
            
            // 至少需要卡密代码
            if (empty($data[0])) {
                continue;
            }
            
            $card = [
                'card_code' => trim($data[0]),
                'content' => !empty($data[1]) ? trim($data[1]) : ($defaults['default_content'] ?? ''),
                'max_uses' => !empty($data[2]) ? intval($data[2]) : ($defaults['default_max_uses'] ?? 1),
                'valid_until' => !empty($data[3]) ? trim($data[3]) : ($defaults['default_valid_until'] ?? null),
                'category_id' => !empty($data[4]) ? intval($data[4]) : ($defaults['default_category'] ?? null)
            ];
        } else {
            // 纯文本格式：整行作为卡密代码
            $card = [
                'card_code' => $line,
                'content' => $defaults['default_content'] ?? '',
                'max_uses' => $defaults['default_max_uses'] ?? 1,
                'valid_until' => $defaults['default_valid_until'] ?? null,
                'category_id' => $defaults['default_category'] ?? null
            ];
        }
        
        // 使用验证类清理和标准化数据
        $card = UploadValidator::sanitizeCardData($card);
        
        error_log("添加卡密: " . $card['card_code']);
        $cards[] = $card;
    }
    
    return $cards;
}

/**
 * 解析Excel文件（简化版，实际项目中建议使用PhpSpreadsheet库）
 */
function parseExcelFile($filePath, $defaults = []) {
    // 这里使用简化处理，实际项目中建议使用PhpSpreadsheet库
    // 将Excel文件转换为CSV格式处理
    $csvPath = $filePath . '.csv';
    
    // 使用系统命令转换（需要安装libreoffice或类似工具）
    $command = "libreoffice --headless --convert-to csv --outdir " . dirname($filePath) . " " . escapeshellarg($filePath);
    exec($command, $output, $returnCode);
    
    if ($returnCode === 0 && file_exists($csvPath)) {
        $cards = parseCsvFile($csvPath, $defaults);
        unlink($csvPath); // 删除临时文件
        return $cards;
    }
    
    // 如果转换失败，尝试直接读取（仅支持简单的Excel格式）
    return parseSimpleExcel($filePath, $defaults);
}

/**
 * 简单Excel解析（仅支持基本格式）
 */
function parseSimpleExcel($filePath, $defaults = []) {
    // 这里可以实现简单的Excel解析逻辑
    // 或者提示用户转换为CSV格式
    return [];
}

// 获取分类列表
$categories = [];
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("获取分类列表失败：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡密上传 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/common.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .sidebar-menu-link {
                @apply transition duration-150;
            }
            .mobile-menu-btn {
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 50;
                background-color: white;
                padding: 0.5rem;
                border-radius: 0.375rem;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                color: #374151;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid #e5e7eb;
                transition: all 0.2s ease;
            }
            .mobile-menu-btn:hover {
                background-color: #f9fafb;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            }
            @media (min-width: 1024px) {
                .mobile-menu-btn {
                    display: none !important;
                }
            }
            /* 确保PC端侧边栏始终可见 */
            @media (min-width: 1024px) {
                #sidebar {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
            }
            /* 移动端侧边栏默认隐藏，但允许JavaScript控制 */
            @media (max-width: 1023px) {
                #sidebar {
                    transform: translateX(-100%);
                    visibility: hidden;
                }
                /* JavaScript控制的侧边栏状态优先级更高 */
                #sidebar.sidebar-visible {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
                #sidebar.sidebar-hidden {
                    transform: translateX(-100%) !important;
                    visibility: hidden !important;
                }
            }
            .upload-area {
                border: 2px dashed #cbd5e1;
                transition: all 0.3s ease;
            }
            .upload-area.dragover {
                border-color: #3b82f6;
                background-color: #eff6ff;
            }
            .file-info {
                display: none;
            }
            .file-info.show {
                display: block;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700 lg:hidden">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密上传</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">卡密上传</h2>
                <p class="mt-1 text-gray-600">支持CSV、TXT、Excel文件格式的卡密批量导入</p>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 上传统计 -->
            <?php if ($uploadStats['total'] > 0): ?>
                <div class="mb-6 bg-white shadow rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-800 mb-4">上传统计</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="text-center">
                            <div class="text-2xl font-bold text-blue-600"><?php echo $uploadStats['total']; ?></div>
                            <div class="text-sm text-gray-500">总记录数</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-green-600"><?php echo $uploadStats['success']; ?></div>
                            <div class="text-sm text-gray-500">成功导入</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-yellow-600"><?php echo $uploadStats['duplicates']; ?></div>
                            <div class="text-sm text-gray-500">跳过重复</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-red-600"><?php echo $uploadStats['failed']; ?></div>
                            <div class="text-sm text-gray-500">导入失败</div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- 上传表单 -->
            <div class="bg-white shadow rounded-lg p-6">
                <form method="post" enctype="multipart/form-data" id="uploadForm">
                    <!-- 文件上传区域 -->
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">选择文件</label>
                        <div class="upload-area rounded-lg p-8 text-center" id="uploadArea">
                            <input type="file" name="card_file" id="cardFile" accept=".csv,.txt,.xlsx,.xls" class="hidden" required>
                            <div id="uploadContent">
                                <i class="fa fa-cloud-upload text-4xl text-gray-400 mb-4"></i>
                                <p class="text-lg text-gray-600 mb-2">点击选择文件或拖拽文件到此处</p>
                                <p class="text-sm text-gray-500">支持 CSV、TXT、Excel 格式，最大 10MB</p>
                            </div>
                            <div id="fileInfo" class="file-info">
                                <i class="fa fa-file text-2xl text-blue-500 mb-2"></i>
                                <p id="fileName" class="text-sm font-medium text-gray-800"></p>
                                <p id="fileSize" class="text-xs text-gray-500"></p>
                                <button type="button" id="removeFile" class="mt-2 text-red-500 hover:text-red-700">
                                    <i class="fa fa-times mr-1"></i>移除文件
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- 上传选项 -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">上传选项</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="defaultCategory" class="block text-sm font-medium text-gray-700 mb-1">默认分类</label>
                                <select name="default_category" id="defaultCategory" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="">不设置分类</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="text-xs text-gray-500 mt-1">如果文件中没有指定分类，将使用此默认分类</p>
                            </div>
                            <div>
                                <label for="defaultMaxUses" class="block text-sm font-medium text-gray-700 mb-1">默认使用次数</label>
                                <input type="number" name="default_max_uses" id="defaultMaxUses" value="1" min="1" max="999" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <p class="text-xs text-gray-500 mt-1">如果文件中没有指定使用次数，将使用此默认值</p>
                            </div>
                            <div>
                                <label for="defaultContent" class="block text-sm font-medium text-gray-700 mb-1">默认内容</label>
                                <textarea name="default_content" id="defaultContent" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="如果文件中没有指定内容，将使用此默认内容"></textarea>
                                <p class="text-xs text-gray-500 mt-1">支持多行文本，可以是激活码、下载链接等</p>
                            </div>
                            <div>
                                <label for="defaultValidUntil" class="block text-sm font-medium text-gray-700 mb-1">默认有效期</label>
                                <input type="datetime-local" name="default_valid_until" id="defaultValidUntil" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <p class="text-xs text-gray-500 mt-1">如果文件中没有指定有效期，将使用此默认值</p>
                            </div>
                        </div>
                    </div>

                    <!-- 文件格式说明 -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">文件格式说明</h3>
                        <div class="bg-gray-50 rounded-lg p-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- 纯文本格式 -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-2">📄 纯文本格式（每行一个卡密）：</p>
                                    <div class="bg-white rounded border p-3 font-mono text-sm">
                                        <div class="text-gray-500"># 注释行以#开头，会被自动忽略</div>
                                        <div>VLPV5Q25FUUPLK44</div>
                                        <div>RZ8X-CBDN-JPY8-YBXR</div>
                                        <div>B7B4-VXFU-U9AY-CYEU</div>
                                        <div>GKAH-QKML-BV8L-EBGM</div>
                                        <div class="text-gray-500"># 空行会被自动跳过</div>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">
                                        <strong>适用场景：</strong>只有卡密代码，其他信息使用默认值
                                    </p>
                                </div>
                                
                                <!-- CSV格式 -->
                                <div>
                                    <p class="text-sm font-medium text-gray-700 mb-2">📊 CSV格式（逗号分隔）：</p>
                                    <div class="bg-white rounded border p-3 font-mono text-sm">
                                        <div class="text-gray-500"># 格式：卡密代码,内容,使用次数,有效期,分类ID</div>
                                        <div>ABC123456789,会员激活码,1,2024-12-31,1</div>
                                        <div>DEF987654321,积分兑换码,3,2024-06-30,2</div>
                                        <div>GHI111222333,测试卡密,1,,</div>
                                        <div>JKL444555666,,,2024-12-31,</div>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">
                                        <strong>适用场景：</strong>需要为每个卡密设置不同属性
                                    </p>
                                </div>
                            </div>
                            
                            <div class="mt-4 text-xs text-gray-600">
                                <p><strong>字段说明：</strong></p>
                                <ul class="list-disc list-inside mt-1 space-y-1">
                                    <li><strong>卡密代码：</strong>必填，唯一标识符</li>
                                    <li><strong>内容：</strong>可选，卡密对应的内容（激活码、下载链接等）</li>
                                    <li><strong>使用次数：</strong>可选，1-999次，默认为1</li>
                                    <li><strong>有效期：</strong>可选，格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS</li>
                                    <li><strong>分类ID：</strong>可选，对应分类管理中的分类ID</li>
                                </ul>
                            </div>
                            
                            <div class="mt-4 p-3 bg-green-50 rounded border border-green-200">
                                <p class="text-sm text-green-800">
                                    <i class="fa fa-check-circle mr-1"></i>
                                    <strong>智能识别：</strong>系统会自动识别文件格式。如果文件包含逗号，按CSV格式处理；否则按纯文本格式处理。
                                </p>
                            </div>
                            
                            <div class="mt-3 p-3 bg-blue-50 rounded border border-blue-200">
                                <p class="text-sm text-blue-800">
                                    <i class="fa fa-lightbulb-o mr-1"></i>
                                    <strong>提示：</strong>如果某个字段为空，系统将使用上方设置的默认值。这样可以让您的文件更简洁，只需要包含卡密代码即可。
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- 提交按钮 -->
                    <div class="flex justify-end">
                        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200">
                            <i class="fa fa-upload mr-2"></i>开始上传
                        </button>
                    </div>
                </form>
            </div>

            <!-- 下载模板 -->
            <div class="mt-6 bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-800 mb-4">下载模板</h3>
                <p class="text-sm text-gray-600 mb-4">下载标准格式的CSV模板文件，按照模板格式准备您的卡密数据。</p>
                <a href="download_template.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <i class="fa fa-download mr-2"></i>下载CSV模板
                </a>
            </div>
        </main>
    </div>

    <script src="../assets/js/common.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const uploadArea = document.getElementById('uploadArea');
            const fileInput = document.getElementById('cardFile');
            const uploadContent = document.getElementById('uploadContent');
            const fileInfo = document.getElementById('fileInfo');
            const fileName = document.getElementById('fileName');
            const fileSize = document.getElementById('fileSize');
            const removeFile = document.getElementById('removeFile');

            // 点击上传区域
            uploadArea.addEventListener('click', function() {
                fileInput.click();
            });

            // 文件选择
            fileInput.addEventListener('change', function(e) {
                handleFileSelect(e.target.files[0]);
            });

            // 拖拽上传
            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    handleFileSelect(files[0]);
                }
            });

            // 移除文件
            removeFile.addEventListener('click', function(e) {
                e.stopPropagation();
                fileInput.value = '';
                uploadContent.style.display = 'block';
                fileInfo.classList.remove('show');
            });

            function handleFileSelect(file) {
                if (!file) return;

                // 检查文件类型
                const allowedTypes = ['text/csv', 'text/plain', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
                if (!allowedTypes.includes(file.type) && !file.name.match(/\.(csv|txt|xlsx|xls)$/i)) {
                    alert('请选择CSV、TXT或Excel文件');
                    return;
                }

                // 检查文件大小
                if (file.size > 10 * 1024 * 1024) {
                    alert('文件大小不能超过10MB');
                    return;
                }

                // 显示文件信息
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                uploadContent.style.display = 'none';
                fileInfo.classList.add('show');
            }

            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }

            // 表单提交验证
            document.getElementById('uploadForm').addEventListener('submit', function(e) {
                if (!fileInput.files.length) {
                    e.preventDefault();
                    alert('请选择要上传的文件');
                    return false;
                }
            });
        });
    </script>
</body>
</html>
