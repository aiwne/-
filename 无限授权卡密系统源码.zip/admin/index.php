<?php
/**
 * 管理员后台入口文件
 * 负责登录状态判断和页面跳转
 */
session_start();

// 确保会话安全设置
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on');
ini_set('session.cookie_samesite', 'Lax');

/**
 * 检查管理员是否已登录
 * @return bool 是否登录
 */
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// 根据登录状态跳转到相应页面
if (isAdminLoggedIn()) {
    // 已登录，跳转到后台仪表盘
    header('Location: dashboard.php');
} else {
    // 未登录，跳转到登录页面
    header('Location: login.php');
}

// 确保跳转后终止脚本执行
exit;
?>
    