<?php
/**
 * 批量生成卡密页面（修复版）
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化变量
$message = '';
$messageType = '';
$categories = [];
$maxUses = 1;
$validUntil = '';

// 获取所有分类
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "获取分类失败: " . $e->getMessage();
    $messageType = 'error';
    error_log("批量生成卡密 - 获取分类错误: " . $e->getMessage());
}

// 处理批量生成请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate'])) {
    // 验证输入
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $categoryId = isset($_POST['category']) ? (int)$_POST['category'] : 0;
    $content = isset($_POST['content']) ? trim($_POST['content']) : '';
    $length = isset($_POST['length']) ? (int)$_POST['length'] : 16;
    $maxUses = isset($_POST['max_uses']) && is_numeric($_POST['max_uses']) ? max(1, (int)$_POST['max_uses']) : 1;
    $validUntil = !empty($_POST['valid_until']) ? $_POST['valid_until'] : null;
    
    // 验证参数有效性
    if ($quantity <= 0 || $quantity > 1000) {
        $message = "请输入有效的生成数量（1-1000）";
        $messageType = 'error';
    } elseif ($categoryId <= 0) {
        $message = "请选择卡密分类";
        $messageType = 'error';
    } elseif (empty($content)) {
        $message = "请输入卡密内容";
        $messageType = 'error';
    } elseif ($length < 8 || $length > 32) {
        $message = "卡密长度应在8-32之间";
        $messageType = 'error';
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getPdo();
            $pdo->beginTransaction(); // 开始事务
            
            $generatedCodes = [];
            $duplicateCheck = [];
            $successCount = 0;
            
            // 生成卡密
            for ($i = 0; $i < $quantity; $i++) {
                // 生成唯一的卡密
                do {
                    $cardCode = generateCardCode($length);
                } while (in_array($cardCode, $duplicateCheck));
                
                $duplicateCheck[] = $cardCode;
                
                // 验证有效时间
                if ($validUntil && !strtotime($validUntil)) {
                    throw new Exception("有效时间格式不正确");
                }
                
                // 插入数据库
                $stmt = $pdo->prepare("
                    INSERT INTO cards (card_code, content, category_id, max_uses, current_uses, valid_until, used, created_at)
                    VALUES (:card_code, :content, :category_id, :max_uses, 0, :valid_until, 0, NOW())
                ");
                
                $result = $stmt->execute([
                    ':card_code' => $cardCode,
                    ':content' => $content,
                    ':category_id' => $categoryId,
                    ':max_uses' => $maxUses,
                    ':valid_until' => $validUntil ? date('Y-m-d H:i:s', strtotime($validUntil)) : null
                ]);
                
                if ($result) {
                    $successCount++;
                    $generatedCodes[] = $cardCode;
                } else {
                    error_log("批量生成卡密 - 插入失败: " . implode(', ', $stmt->errorInfo()));
                }
            }
            
            // 提交事务
            $pdo->commit();
            
            if ($successCount > 0) {
                $message = "成功生成 {$successCount} 个卡密";
                $messageType = 'success';
                
                // 记录成功生成的卡密（可选）
                error_log("批量生成卡密 - 成功生成 {$successCount} 个，ID范围: " . 
                          (empty($generatedCodes) ? '无' : $generatedCodes[0] . ' 至 ' . end($generatedCodes)));
            } else {
                $message = "生成卡密失败，未插入任何数据";
                $messageType = 'error';
            }
            
        } catch (PDOException $e) {
            $pdo->rollBack(); // 回滚事务
            $message = "数据库错误: " . $e->getMessage();
            $messageType = 'error';
            error_log("批量生成卡密 - 数据库错误: " . $e->getMessage());
        } catch (Exception $e) {
            $pdo->rollBack(); // 回滚事务
            $message = "生成失败: " . $e->getMessage();
            $messageType = 'error';
            error_log("批量生成卡密 - 错误: " . $e->getMessage());
        }
    }
}

/**
 * 生成随机卡密
 * @param int $length 卡密长度
 * @return string 生成的卡密
 */
function generateCardCode($length = 16) {
    // 字符集：数字+大写字母，排除易混淆字符（0, O, 1, I）
    $chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    $charLength = strlen($chars);
    $code = '';
    
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[mt_rand(0, $charLength - 1)];
    }
    
    // 每4个字符一组，增强可读性
    return implode('-', str_split($code, 4));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>批量生成卡密 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible { transform: translateX(0); visibility: visible; }
            .sidebar-hidden { transform: translateX(-100%); visibility: hidden; }
            .form-input-focus { @apply focus:ring-2 focus:ring-blue-500 focus:border-blue-500; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700 lg:hidden">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? '管理员'); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-upload mr-3"></i>卡密上传
                            </a>
                            <a href="card_export.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                                <i class="fa fa-download mr-3"></i>卡密导出
                            </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                      <a href="bark_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto p-2 lg:pl-64 transition-all duration-300">
            <div class="px-1 sm:px-2 lg:px-3 py-2">
            <div class="mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">批量生成卡密</h2>
                <p class="mt-1 text-gray-600">一次性生成多个卡密，可指定数量、分类和内容</p>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 批量生成表单 -->
            <div class="bg-white shadow overflow-hidden sm:rounded-lg max-w-3xl">
                <div class="px-4 py-5 sm:p-6">
                    <form method="post" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- 生成数量 -->
                            <div>
                                <label for="quantity" class="block text-sm font-medium text-gray-700 mb-1">生成数量 <span class="text-red-500">*</span></label>
                                <input type="number" name="quantity" id="quantity" 
                                       value="10" min="1" max="1000" step="1"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus">
                                <p class="mt-1 text-xs text-gray-500">最多可生成1000个卡密</p>
                            </div>
                            
                            <!-- 卡密长度 -->
                            <div>
                                <label for="length" class="block text-sm font-medium text-gray-700 mb-1">卡密长度 <span class="text-red-500">*</span></label>
                                <input type="number" name="length" id="length" 
                                       value="16" min="8" max="32" step="1"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus">
                                <p class="mt-1 text-xs text-gray-500">卡密长度建议在8-32之间</p>
                            </div>
                            
                            <!-- 卡密分类 -->
                            <div class="md:col-span-2">
                                <label for="category" class="block text-sm font-medium text-gray-700 mb-1">卡密分类 <span class="text-red-500">*</span></label>
                                <select name="category" id="category" 
                                        class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus">
                                    <option value="">请选择分类</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (empty($categories)): ?>
                                    <p class="mt-1 text-xs text-yellow-600">
                                        <i class="fa fa-info-circle mr-1"></i>没有可用分类，请先添加分类
                                    </p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- 使用次数和有效时间 -->
                            <div>
                                <label for="max_uses" class="block text-sm font-medium text-gray-700 mb-1">
                                    最大使用次数 <span class="text-red-500">*</span>
                                </label>
                                <input type="number" name="max_uses" id="max_uses" 
                                       value="1" min="1" max="999"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus">
                                <p class="mt-1 text-xs text-gray-500">设置卡密可使用的最大次数，1表示一次性使用</p>
                            </div>
                            
                            <div>
                                <label for="valid_until" class="block text-sm font-medium text-gray-700 mb-1">
                                    有效期至（可选）
                                </label>
                                <input type="datetime-local" name="valid_until" id="valid_until" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus">
                                <p class="mt-1 text-xs text-gray-500">设置卡密的有效期，留空表示永久有效</p>
                            </div>
                            
                            <!-- 卡密内容 -->
                            <div class="md:col-span-2">
                                <label for="content" class="block text-sm font-medium text-gray-700 mb-1">卡密内容 <span class="text-red-500">*</span></label>
                                <textarea name="content" id="content" rows="4" 
                                          placeholder="例如：VIP会员1个月、100元充值卡等"
                                          class="w-full px-4 py-2 border border-gray-300 rounded-md form-input-focus"></textarea>
                                <p class="mt-1 text-xs text-gray-500">所有生成的卡密将使用相同的内容描述</p>
                            </div>
                        </div>
                        
                        <!-- 操作按钮 -->
                        <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                            <a href="cards_list.php" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                                <i class="fa fa-arrow-left mr-2"></i>返回列表
                            </a>
                            <button type="submit" name="generate" 
                                    class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                    <?php echo empty($categories) ? 'disabled title="请先添加分类"' : ''; ?>>
                                <i class="fa fa-cogs mr-2"></i>批量生成
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 生成说明 -->
            <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mt-6 max-w-3xl">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fa fa-info-circle text-blue-500 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-blue-800">生成说明</h3>
                        <div class="mt-2 text-sm text-blue-700 space-y-1">
                            <p>• 生成的卡密由数字和大写字母组成，不包含易混淆字符（0, O, 1, I）</p>
                            <p>• 卡密将按每4个字符一组自动分隔，增强可读性</p>
                            <p>• 系统会确保生成的卡密不重复</p>
                            <p>• 生成成功后，可在卡密管理列表中查看和管理这些卡密</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏切换功能
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            function toggleSidebar() {
                sidebar.classList.toggle('sidebar-visible');
                sidebar.classList.toggle('sidebar-hidden');
                sidebarOverlay.classList.toggle('hidden');
                document.body.classList.toggle('overflow-hidden');
            }
            
            mobileMenuBtn.addEventListener('click', toggleSidebar);
            sidebarOverlay.addEventListener('click', toggleSidebar);

            // 窗口大小变化处理
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 1024) {
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                    sidebarOverlay.classList.add('hidden');
                } else if (!sidebar.classList.contains('sidebar-visible')) {
                    sidebar.classList.add('hidden');
                }
            });

            // 表单验证
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const quantity = parseInt(document.getElementById('quantity').value);
                    const category = document.getElementById('category').value;
                    const content = document.getElementById('content').value.trim();
                    const length = parseInt(document.getElementById('length').value);
                    
                    let error = '';
                    
                    if (isNaN(quantity) || quantity <= 0 || quantity > 1000) {
                        error = '请输入有效的生成数量（1-1000）';
                    } else if (category === '') {
                        error = '请选择卡密分类';
                    } else if (content === '') {
                        error = '请输入卡密内容';
                    } else if (isNaN(length) || length < 8 || length > 32) {
                        error = '卡密长度应在8-32之间';
                    }
                    
                    if (error) {
                        e.preventDefault();
                        alert(error);
                        return false;
                    }
                    
                    // 确认生成
                    if (!confirm(`确定要生成 ${quantity} 个卡密吗？`)) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
        });
    </script>
</body>
</html>
<?php
unset($message, $messageType, $categories, $db, $pdo, $stmt);
?>
    