<?php
/**
 * 下载CSV模板文件
 */
require_once 'auth.php';

// 设置响应头
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="卡密导入模板.csv"');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');

// 输出BOM，确保Excel正确显示中文
echo "\xEF\xBB\xBF";

// 创建CSV内容
$csvContent = [
    ['# 卡密导入模板 - 请按照以下格式填写数据'],
    ['# 格式：卡密代码,内容,使用次数,有效期,分类ID'],
    ['# 只有卡密代码是必填的，其他字段可选'],
    ['# 注释行以#开头，会被自动忽略'],
    [''],
    ['# 示例数据：'],
    ['ABC123456789', '会员激活码', '1', '2024-12-31', '1'],
    ['DEF987654321', '积分兑换码', '3', '2024-06-30', '2'],
    ['GHI111222333', '测试卡密', '1', '', ''],
    ['JKL444555666', '', '', '2024-12-31', ''],
    [''],
    ['# 字段说明：'],
    ['# 卡密代码：必填，唯一标识符，建议使用字母数字组合'],
    ['# 内容：可选，卡密对应的内容（激活码、下载链接、说明等）'],
    ['# 使用次数：可选，1-999次，默认为1'],
    ['# 有效期：可选，格式：YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS'],
    ['# 分类ID：可选，对应分类管理中的分类ID，留空则不设置分类'],
    [''],
    ['# 请在下方添加您的卡密数据：'],
    ['# 卡密代码', '内容', '使用次数', '有效期', '分类ID']
];

// 输出CSV内容
foreach ($csvContent as $row) {
    // 将数组转换为CSV格式
    $csvRow = [];
    foreach ($row as $field) {
        // 如果字段包含逗号、引号或换行符，需要用引号包围并转义
        if (strpos($field, ',') !== false || strpos($field, '"') !== false || strpos($field, "\n") !== false) {
            $field = '"' . str_replace('"', '""', $field) . '"';
        }
        $csvRow[] = $field;
    }
    echo implode(',', $csvRow) . "\n";
}

exit;
?>