<?php
// 验证管理员登录状态
require_once 'auth.php';
require_once '../db_connect.php';

try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        throw new Exception("无法建立数据库连接，请检查配置");
    }
    
    // 执行需要的查询
    $stmt = $pdo->query("SELECT COUNT(*) FROM cards");
    $totalCards = $stmt->fetchColumn();
    
} catch (Exception $e) {
    $error = "数据库错误: " . $e->getMessage();
    error_log($error);
}
// 获取统计数据
$stats = [
    'total_cards' => 0,
    'used_cards' => 0,
    'unused_cards' => 0,
    'recent_activities' => []
];

try {
    // 获取数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 总卡密数量
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards");
    $stats['total_cards'] = $stmt->fetchColumn();
    
    // 已使用卡密数量
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards WHERE is_used = 1");
    $stats['used_cards'] = $stmt->fetchColumn();
    
    // 未使用卡密数量
    $stats['unused_cards'] = $stats['total_cards'] - $stats['used_cards'];
    
    // 最近使用记录
    $stmt = $pdo->query("SELECT card_code, used_at FROM cards WHERE is_used = 1 ORDER BY used_at DESC LIMIT 5");
    $stats['recent_activities'] = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "获取统计数据失败: " . $e->getMessage();
    error_log("仪表盘数据错误: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理仪表盘</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/common.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js"></script>
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .sidebar-menu-link {
                @apply transition duration-150;
            }
            .mobile-menu-btn {
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 50;
                background-color: white;
                padding: 0.5rem;
                border-radius: 0.375rem;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                color: #374151;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid #e5e7eb;
                transition: all 0.2s ease;
            }
            .mobile-menu-btn:hover {
                background-color: #f9fafb;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            }
            @media (min-width: 1024px) {
                .mobile-menu-btn {
                    display: none !important;
                }
            }
            /* 确保PC端侧边栏始终可见 */
            @media (min-width: 1024px) {
                #sidebar {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
            }
            /* 移动端侧边栏默认隐藏，但允许JavaScript控制 */
            @media (max-width: 1023px) {
                #sidebar {
                    transform: translateX(-100%);
                    visibility: hidden;
                }
                /* JavaScript控制的侧边栏状态优先级更高 */
                #sidebar.sidebar-visible {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
                #sidebar.sidebar-hidden {
                    transform: translateX(-100%) !important;
                    visibility: hidden !important;
                }
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 - 只在移动端显示 -->
    <button id="mobileMenuBtn" class="mobile-menu-btn">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航栏 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>

    <div class="flex h-screen overflow-hidden">
        <!-- 侧边栏 -->
                <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="sidebar-menu-link bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                     <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                       <a href="bark_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                   <a href="email_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                    <a href="website_settings.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-cog mr-3"></i>网站设置
                    </a>
                    <a href="profile.php" class="sidebar-menu-link text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
       <main class="flex-1 overflow-y-auto">
            <div class="px-3 sm:px-4 lg:px-6 py-4">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6">系统概览</h2>
                
                <?php if (isset($error)): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                        <i class="fa fa-exclamation-triangle mr-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- 统计卡片 -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="bg-white shadow rounded-lg p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-blue-100 p-3 rounded-full">
                                <i class="fa fa-credit-card text-blue-600 text-xl"></i>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500">总卡密数量</dt>
                                    <dd>
                                        <div class="text-lg font-semibold text-gray-900"><?php echo number_format($stats['total_cards']); ?></div>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white shadow rounded-lg p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-green-100 p-3 rounded-full">
                                <i class="fa fa-check-circle text-green-600 text-xl"></i>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500">已使用卡密</dt>
                                    <dd>
                                        <div class="text-lg font-semibold text-gray-900"><?php echo number_format($stats['used_cards']); ?></div>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <?php 
                                            $usedPercent = $stats['total_cards'] > 0 ? ($stats['used_cards'] / $stats['total_cards']) * 100 : 0;
                                            echo number_format($usedPercent, 1) . '% 的卡密已使用'; 
                                            ?>
                                        </div>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white shadow rounded-lg p-6">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 bg-yellow-100 p-3 rounded-full">
                                <i class="fa fa-clock-o text-yellow-600 text-xl"></i>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500">未使用卡密</dt>
                                    <dd>
                                        <div class="text-lg font-semibold text-gray-900"><?php echo number_format($stats['unused_cards']); ?></div>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <?php 
                                            $unusedPercent = $stats['total_cards'] > 0 ? ($stats['unused_cards'] / $stats['total_cards']) * 100 : 0;
                                            echo number_format($unusedPercent, 1) . '% 的卡密未使用'; 
                                            ?>
                                        </div>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 图表和最近活动 -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- 使用情况图表 -->
                    <div class="bg-white shadow rounded-lg p-6 lg:col-span-2">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">卡密使用情况</h3>
                        <div class="h-64">
                            <canvas id="usageChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- 最近活动 -->
                    <div class="bg-white shadow rounded-lg p-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">最近使用记录</h3>
                        <div class="space-y-4">
                            <?php if (count($stats['recent_activities']) > 0): ?>
                                <?php foreach ($stats['recent_activities'] as $activity): ?>
                                    <div class="flex items-start">
                                        <div class="flex-shrink-0 h-10 w-10 flex items-center justify-center rounded-full bg-gray-100">
                                            <i class="fa fa-key text-gray-500"></i>
                                        </div>
                                        <div class="ml-3">
                                            <p class="text-sm text-gray-600">
                                                <span class="font-medium">卡密:</span> <?php echo substr($activity['card_code'], 0, 8) . '...'; ?>
                                            </p>
                                            <p class="text-xs text-gray-500 mt-1">
                                                使用时间: <?php echo $activity['used_at'] ? date('Y-m-d H:i', strtotime($activity['used_at'])) : '未知'; ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-sm text-gray-500 italic">暂无使用记录</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- 快捷操作 -->
                <div class="mt-8 bg-white shadow rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-800 mb-4">快捷操作</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                        <a href="card_add.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-blue-600 mb-2">
                                <i class="fa fa-plus-circle text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">添加单个卡密</span>
                        </a>
                         <a href="card_upload.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-blue-600 mb-2">
                                <i class="fa fa fa-upload mr-3 text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">自定义上传卡密</span>
                        </a>
                        <a href="batch_generate.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-green-600 mb-2">
                                <i class="fa fa-cubes text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">批量生成卡密</span>
                        </a>
                        <a href="cards_list.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-purple-600 mb-2">
                                <i class="fa fa-list-alt text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">管理所有卡密</span>
                        </a>
                        <a href="card_search.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-blue-600 mb-2">
                                <i class="fa fa-search mr-3 text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">卡密查询</span>
                        </a>
                        <a href="categories.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-blue-600 mb-2">
                                <i class="fa fa-tags mr-3 text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">分类管理</span>
                        </a>
                        <a href="fa fa-download mr-3" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-blue-600 mb-2">
                                <i class="fa fa-download mr-3 text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">卡密导出</span>
                        </a>
                        <a href="profile.php" class="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition duration-200">
                            <div class="text-yellow-600 mb-2">
                                <i class="fa fa-cog text-2xl"></i>
                            </div>
                            <span class="text-sm font-medium text-gray-700">公告设置</span>
                        </a>
                    </div>
                </div>
                
                <!-- API接口测试区域 -->
                <div class="mt-8 bg-white shadow rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-800 mb-4">API接口测试</h3>
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- 卡密验证API测试 -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h4 class="font-medium text-gray-700 mb-3">
                                <i class="fa fa-key mr-2 text-blue-600"></i>卡密验证API
                            </h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">卡密代码</label>
                                    <input type="text" id="testCardCode" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                           placeholder="输入要测试的卡密代码">
                                </div>
                                <button onclick="testCardVerify()" 
                                        class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-200">
                                    <i class="fa fa-play mr-2"></i>测试验证
                                </button>
                                <div id="verifyResult" class="hidden mt-3 p-3 rounded-md text-sm"></div>
                            </div>
                        </div>
                        
                        <!-- 卡密查询API测试 -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h4 class="font-medium text-gray-700 mb-3">
                                <i class="fa fa-search mr-2 text-green-600"></i>卡密查询API
                            </h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">卡密代码</label>
                                    <input type="text" id="queryCardCode" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                                           placeholder="输入要查询的卡密代码">
                                </div>
                                <button onclick="testCardQuery()" 
                                        class="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition duration-200">
                                    <i class="fa fa-search mr-2"></i>查询卡密
                                </button>
                                <div id="queryResult" class="hidden mt-3 p-3 rounded-md text-sm"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- API统计信息 -->
                    <div class="mt-6 border-t border-gray-200 pt-6">
                        <h4 class="font-medium text-gray-700 mb-3">
                            <i class="fa fa-chart-bar mr-2 text-purple-600"></i>API统计信息
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">今日API调用</div>
                                <div class="text-2xl font-bold text-gray-800" id="todayApiCalls">-</div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">本周API调用</div>
                                <div class="text-2xl font-bold text-gray-800" id="weekApiCalls">-</div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">API响应时间</div>
                                <div class="text-2xl font-bold text-gray-800" id="apiResponseTime">-</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/common.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        // 初始化卡密使用情况图表
        document.addEventListener('DOMContentLoaded', function() {
            // 调试：检查移动端菜单按钮
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            
            console.log('Dashboard调试信息:', {
                mobileMenuBtn: !!mobileMenuBtn,
                sidebar: !!sidebar,
                sidebarOverlay: !!sidebarOverlay,
                windowWidth: window.innerWidth,
                isMobile: window.innerWidth < 1024
            });
            
            if (mobileMenuBtn) {
                console.log('移动端菜单按钮样式:', {
                    display: window.getComputedStyle(mobileMenuBtn).display,
                    visibility: window.getComputedStyle(mobileMenuBtn).visibility,
                    zIndex: window.getComputedStyle(mobileMenuBtn).zIndex,
                    pointerEvents: window.getComputedStyle(mobileMenuBtn).pointerEvents
                });
            }
            
            // 图表初始化
            const ctx = document.getElementById('usageChart').getContext('2d');
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['已使用', '未使用'],
                    datasets: [{
                        data: [
                            <?php echo $stats['used_cards']; ?>,
                            <?php echo $stats['unused_cards']; ?>
                        ],
                        backgroundColor: [
                            '#10B981', // 绿色 - 已使用
                            '#F59E0B'  // 黄色 - 未使用
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    },
                    cutout: '70%'
                }
            });
            
            // 加载API统计信息
            loadApiStats();
        });
        
        // API测试函数
        async function testCardVerify() {
            const cardCode = document.getElementById('testCardCode').value.trim();
            const resultDiv = document.getElementById('verifyResult');
            
            if (!cardCode) {
                showApiResult(resultDiv, '请输入卡密代码', 'error');
                return;
            }
            
            const startTime = Date.now();
            showApiResult(resultDiv, '正在验证...', 'info');
            
            try {
                const response = await fetch('../api/card_verify.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        card_code: cardCode,
                        client_info: {
                            user_agent: navigator.userAgent,
                            ip: '127.0.0.1',
                            language: navigator.language
                        }
                    })
                });
                
                const data = await response.json();
                const responseTime = Date.now() - startTime;
                
                if (data.success) {
                    const resultHtml = `
                        <div class="text-green-800">
                            <div class="font-medium mb-2">✅ 验证成功</div>
                            <div class="space-y-1 text-xs">
                                <div><strong>卡密ID:</strong> ${data.data.card_id}</div>
                                <div><strong>分类:</strong> ${data.data.category_name}</div>
                                <div><strong>状态:</strong> ${data.data.status}</div>
                                <div><strong>剩余次数:</strong> ${data.data.remaining_uses}/${data.data.max_uses}</div>
                                <div><strong>响应时间:</strong> ${responseTime}ms</div>
                                ${data.data.valid_until ? `<div><strong>有效期:</strong> ${data.data.valid_until}</div>` : ''}
                            </div>
                        </div>
                    `;
                    showApiResult(resultDiv, resultHtml, 'success');
                } else {
                    const resultHtml = `
                        <div class="text-red-800">
                            <div class="font-medium mb-2">❌ 验证失败</div>
                            <div class="space-y-1 text-xs">
                                <div><strong>错误代码:</strong> ${data.code}</div>
                                <div><strong>错误信息:</strong> ${data.message}</div>
                                <div><strong>响应时间:</strong> ${responseTime}ms</div>
                            </div>
                        </div>
                    `;
                    showApiResult(resultDiv, resultHtml, 'error');
                }
            } catch (error) {
                showApiResult(resultDiv, `网络错误: ${error.message}`, 'error');
            }
        }
        
        async function testCardQuery() {
            const cardCode = document.getElementById('queryCardCode').value.trim();
            const resultDiv = document.getElementById('queryResult');
            
            if (!cardCode) {
                showApiResult(resultDiv, '请输入卡密代码', 'error');
                return;
            }
            
            const startTime = Date.now();
            showApiResult(resultDiv, '正在查询...', 'info');
            
            try {
                const response = await fetch(`../api/card_query.php?card_code=${encodeURIComponent(cardCode)}`);
                const data = await response.json();
                const responseTime = Date.now() - startTime;
                
                if (data.success) {
                    const resultHtml = `
                        <div class="text-green-800">
                            <div class="font-medium mb-2">✅ 查询成功</div>
                            <div class="space-y-1 text-xs">
                                <div><strong>卡密ID:</strong> ${data.data.card_id}</div>
                                <div><strong>分类:</strong> ${data.data.category_name}</div>
                                <div><strong>状态:</strong> ${data.data.status}</div>
                                <div><strong>使用次数:</strong> ${data.data.current_uses}/${data.data.max_uses}</div>
                                <div><strong>创建时间:</strong> ${data.data.created_at}</div>
                                <div><strong>响应时间:</strong> ${responseTime}ms</div>
                                ${data.data.used_at ? `<div><strong>使用时间:</strong> ${data.data.used_at}</div>` : ''}
                                ${data.data.first_use_ip ? `<div><strong>绑定IP:</strong> ${data.data.first_use_ip}</div>` : ''}
                            </div>
                        </div>
                    `;
                    showApiResult(resultDiv, resultHtml, 'success');
                } else {
                    const resultHtml = `
                        <div class="text-red-800">
                            <div class="font-medium mb-2">❌ 查询失败</div>
                            <div class="space-y-1 text-xs">
                                <div><strong>错误代码:</strong> ${data.code}</div>
                                <div><strong>错误信息:</strong> ${data.message}</div>
                                <div><strong>响应时间:</strong> ${responseTime}ms</div>
                            </div>
                        </div>
                    `;
                    showApiResult(resultDiv, resultHtml, 'error');
                }
            } catch (error) {
                showApiResult(resultDiv, `网络错误: ${error.message}`, 'error');
            }
        }
        
        function showApiResult(element, message, type) {
            element.innerHTML = message;
            element.className = `mt-3 p-3 rounded-md text-sm ${getResultClass(type)}`;
            element.classList.remove('hidden');
        }
        
        function getResultClass(type) {
            switch(type) {
                case 'success': return 'bg-green-100 text-green-800';
                case 'error': return 'bg-red-100 text-red-800';
                case 'info': return 'bg-blue-100 text-blue-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        }
        
        async function loadApiStats() {
            try {
                const response = await fetch('../api/card_stats.php');
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('todayApiCalls').textContent = data.data.today_used || 0;
                    document.getElementById('weekApiCalls').textContent = data.data.week_used || 0;
                    document.getElementById('apiResponseTime').textContent = '< 100ms';
                }
            } catch (error) {
                console.error('加载API统计失败:', error);
            }
        }
    </script>
</body>
</html>
<?php
// 清理敏感数据
unset($stats, $db, $pdo, $stmt, $error);
?>