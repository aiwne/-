<?php
/**
 * 卡密状态快速切换处理
 * 用于在已使用和未使用状态间快速切换
 */
// 验证登录状态
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化返回URL
$returnUrl = 'cards_list.php';

// 检查必要参数
if (!isset($_GET['id']) || !is_numeric($_GET['id']) || !isset($_GET['status']) || !in_array($_GET['status'], ['0', '1'])) {
    header("Location: $returnUrl?error=invalid_params");
    exit;
}

$cardId = (int)$_GET['id'];
$targetStatus = (int)$_GET['status'];

try {
    // 获取数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 检查卡密是否存在
    $stmt = $pdo->prepare("SELECT * FROM cards WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $cardId]);
    $card = $stmt->fetch();
    
    if (!$card) {
        header("Location: $returnUrl?error=card_not_found");
        exit;
    }
    
    // 根据目标状态准备更新数据
    $updateData = [
        'is_used' => $targetStatus,
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    // 如果切换为已使用状态，设置使用时间
    if ($targetStatus == 1) {
        $updateData['used_at'] = date('Y-m-d H:i:s');
        // 如果需要，这里可以添加自动记录设备信息的逻辑
        // $updateData['device_info'] = "管理员手动标记为已使用";
    } 
    // 如果切换为未使用状态，清空使用时间
    else {
        $updateData['used_at'] = null;
        // 可选：清空设备信息
        // $updateData['device_info'] = null;
    }
    
    // 执行更新
    $stmt = $pdo->prepare("UPDATE cards SET 
                         is_used = :is_used,
                         used_at = :used_at,
                         updated_at = :updated_at
                         WHERE id = :id");
    
    $stmt->execute([
        ':is_used' => $updateData['is_used'],
        ':used_at' => $updateData['used_at'],
        ':updated_at' => $updateData['updated_at'],
        ':id' => $cardId
    ]);
    
    // 更新成功，跳转回列表并显示消息
    $statusText = $targetStatus == 1 ? '已使用' : '未使用';
    header("Location: $returnUrl?success=status_updated&status=$statusText&code=" . urlencode($card['card_code']));
    exit;
    
} catch (PDOException $e) {
    error_log("卡密状态切换错误: " . $e->getMessage());
    header("Location: $returnUrl?error=database_error");
    exit;
} catch (Exception $e) {
    error_log("卡密状态切换异常: " . $e->getMessage());
    header("Location: $returnUrl?error=operation_failed");
    exit;
}
?>
    