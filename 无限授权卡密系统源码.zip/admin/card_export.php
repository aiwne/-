<?php
/**
 * 卡密导出页面
 * 支持多种格式导出：CSV、Excel、JSON、TXT
 */
require_once 'auth.php';
require_once '../db_connect.php';

// 初始化变量
$message = '';
$messageType = '';
$exportStats = [
    'total' => 0,
    'exported' => 0,
    'format' => '',
    'filename' => ''
];

// 处理导出请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_action'])) {
    try {
        $exportStats = handleCardExport($_POST);
        
        if ($exportStats['exported'] > 0) {
            $message = "导出成功！共导出 {$exportStats['exported']} 条记录，文件：{$exportStats['filename']}";
            $messageType = 'success';
        } else {
            $message = "没有找到符合条件的卡密数据";
            $messageType = 'warning';
        }
    } catch (Exception $e) {
        $message = "导出失败：" . $e->getMessage();
        $messageType = 'error';
        error_log("卡密导出错误：" . $e->getMessage());
    }
}

/**
 * 处理卡密导出
 */
function handleCardExport($params) {
    global $pdo;
    
    $stats = [
        'total' => 0,
        'exported' => 0,
        'format' => $params['export_format'] ?? 'csv',
        'filename' => ''
    ];
    
    // 获取数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        throw new Exception("数据库连接失败");
    }
    
    // 构建查询条件
    $conditions = [];
    $params_sql = [];
    
    // 分类筛选
    if (!empty($params['category_id'])) {
        $conditions[] = "c.category_id = :category_id";
        $params_sql[':category_id'] = $params['category_id'];
    }
    
    // 状态筛选
    if (!empty($params['status'])) {
        switch ($params['status']) {
            case 'unused':
                $conditions[] = "c.current_uses = 0";
                break;
            case 'using':
                $conditions[] = "c.current_uses > 0 AND c.current_uses < c.max_uses";
                break;
            case 'used':
                $conditions[] = "c.current_uses >= c.max_uses";
                break;
            case 'expired':
                $conditions[] = "c.valid_until IS NOT NULL AND c.valid_until < NOW()";
                break;
        }
    }
    
    // 时间范围筛选
    if (!empty($params['date_from'])) {
        $conditions[] = "c.created_at >= :date_from";
        $params_sql[':date_from'] = $params['date_from'] . ' 00:00:00';
    }
    
    if (!empty($params['date_to'])) {
        $conditions[] = "c.created_at <= :date_to";
        $params_sql[':date_to'] = $params['date_to'] . ' 23:59:59';
    }
    
    $whereClause = $conditions ? "WHERE " . implode(' AND ', $conditions) : '';
    
    // 查询数据
    $sql = "
        SELECT 
            c.id,
            c.card_code,
            c.content,
            c.max_uses,
            c.current_uses,
            c.valid_until,
            c.first_use_ip,
            c.last_use_ip,
            c.created_at,
            c.used_at,
            cat.name as category_name,
            CASE 
                WHEN c.valid_until IS NOT NULL AND c.valid_until < NOW() THEN 'expired'
                WHEN c.current_uses >= c.max_uses THEN 'used'
                WHEN c.current_uses > 0 THEN 'using'
                ELSE 'unused'
            END as status
        FROM cards c
        LEFT JOIN categories cat ON c.category_id = cat.id
        {$whereClause}
        ORDER BY c.created_at DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params_sql);
    $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $stats['total'] = count($cards);
    
    if (empty($cards)) {
        return $stats;
    }
    
    // 生成文件名
    $timestamp = date('Y-m-d_H-i-s');
    $stats['filename'] = "cards_export_{$timestamp}.{$stats['format']}";
    
    // 根据格式导出
    switch ($stats['format']) {
        case 'csv':
            exportToCsv($cards, $stats['filename']);
            break;
        case 'excel':
            exportToExcel($cards, $stats['filename']);
            break;
        case 'json':
            exportToJson($cards, $stats['filename']);
            break;
        case 'txt':
            exportToTxt($cards, $stats['filename']);
            break;
        default:
            throw new Exception("不支持的导出格式");
    }
    
    $stats['exported'] = count($cards);
    return $stats;
}

/**
 * 导出为CSV格式
 */
function exportToCsv($cards, $filename) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    // 输出BOM以支持中文
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    // 输出表头
    fputcsv($output, [
        'ID', '卡密代码', '内容', '最大使用次数', '当前使用次数', 
        '状态', '分类', '有效期', '首次使用IP', '最后使用IP', 
        '创建时间', '使用时间'
    ]);
    
    // 输出数据
    foreach ($cards as $card) {
        fputcsv($output, [
            $card['id'],
            $card['card_code'],
            $card['content'],
            $card['max_uses'],
            $card['current_uses'],
            $card['status'],
            $card['category_name'] ?: '未分类',
            $card['valid_until'] ?: '',
            $card['first_use_ip'] ?: '',
            $card['last_use_ip'] ?: '',
            $card['created_at'],
            $card['used_at'] ?: ''
        ]);
    }
    
    fclose($output);
    exit;
}

/**
 * 导出为Excel格式（简化版）
 */
function exportToExcel($cards, $filename) {
    // 这里使用简化的Excel导出，实际项目中建议使用PhpSpreadsheet库
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th><th>卡密代码</th><th>内容</th><th>最大使用次数</th><th>当前使用次数</th>";
    echo "<th>状态</th><th>分类</th><th>有效期</th><th>首次使用IP</th><th>最后使用IP</th>";
    echo "<th>创建时间</th><th>使用时间</th>";
    echo "</tr>";
    
    foreach ($cards as $card) {
        echo "<tr>";
        echo "<td>{$card['id']}</td>";
        echo "<td>{$card['card_code']}</td>";
        echo "<td>{$card['content']}</td>";
        echo "<td>{$card['max_uses']}</td>";
        echo "<td>{$card['current_uses']}</td>";
        echo "<td>{$card['status']}</td>";
        echo "<td>" . ($card['category_name'] ?: '未分类') . "</td>";
        echo "<td>" . ($card['valid_until'] ?: '') . "</td>";
        echo "<td>" . ($card['first_use_ip'] ?: '') . "</td>";
        echo "<td>" . ($card['last_use_ip'] ?: '') . "</td>";
        echo "<td>{$card['created_at']}</td>";
        echo "<td>" . ($card['used_at'] ?: '') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    exit;
}

/**
 * 导出为JSON格式
 */
function exportToJson($cards, $filename) {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    $exportData = [
        'export_time' => date('Y-m-d H:i:s'),
        'total_count' => count($cards),
        'cards' => $cards
    ];
    
    echo json_encode($exportData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * 导出为TXT格式
 */
function exportToTxt($cards, $filename) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    echo "卡密导出报告\n";
    echo "导出时间：" . date('Y-m-d H:i:s') . "\n";
    echo "总数量：" . count($cards) . "\n";
    echo str_repeat("=", 50) . "\n\n";
    
    foreach ($cards as $card) {
        echo "ID: {$card['id']}\n";
        echo "卡密代码: {$card['card_code']}\n";
        echo "内容: {$card['content']}\n";
        echo "使用次数: {$card['current_uses']}/{$card['max_uses']}\n";
        echo "状态: {$card['status']}\n";
        echo "分类: " . ($card['category_name'] ?: '未分类') . "\n";
        if ($card['valid_until']) {
            echo "有效期: {$card['valid_until']}\n";
        }
        if ($card['first_use_ip']) {
            echo "首次使用IP: {$card['first_use_ip']}\n";
        }
        if ($card['used_at']) {
            echo "使用时间: {$card['used_at']}\n";
        }
        echo "创建时间: {$card['created_at']}\n";
        echo str_repeat("-", 30) . "\n";
    }
    
    exit;
}

// 获取分类列表
$categories = [];
try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    $stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("获取分类列表失败：" . $e->getMessage());
}

// 获取统计信息
$totalCards = 0;
$usedCards = 0;
$unusedCards = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards");
    $totalCards = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards WHERE is_used = 1");
    $usedCards = $stmt->fetchColumn();
    
    $unusedCards = $totalCards - $usedCards;
} catch (Exception $e) {
    error_log("获取统计信息失败：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>卡密导出 - 卡密系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/common.css" rel="stylesheet">
    <style type="text/tailwindcss">
        @layer utilities {
            .sidebar-visible {
                transform: translateX(0);
                visibility: visible;
            }
            .sidebar-hidden {
                transform: translateX(-100%);
                visibility: hidden;
            }
            .sidebar-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease;
            }
            .sidebar-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            .sidebar-menu-link {
                @apply transition duration-150;
            }
            .mobile-menu-btn {
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 50;
                background-color: white;
                padding: 0.5rem;
                border-radius: 0.375rem;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                color: #374151;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid #e5e7eb;
                transition: all 0.2s ease;
            }
            .mobile-menu-btn:hover {
                background-color: #f9fafb;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            }
            @media (min-width: 1024px) {
                .mobile-menu-btn {
                    display: none !important;
                }
            }
            /* 确保PC端侧边栏始终可见 */
            @media (min-width: 1024px) {
                #sidebar {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
            }
            /* 移动端侧边栏默认隐藏，但允许JavaScript控制 */
            @media (max-width: 1023px) {
                #sidebar {
                    transform: translateX(-100%);
                    visibility: hidden;
                }
                /* JavaScript控制的侧边栏状态优先级更高 */
                #sidebar.sidebar-visible {
                    transform: translateX(0) !important;
                    visibility: visible !important;
                }
                #sidebar.sidebar-hidden {
                    transform: translateX(-100%) !important;
                    visibility: hidden !important;
                }
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- 移动端菜单按钮 -->
    <button id="mobileMenuBtn" class="fixed top-4 left-4 z-50 bg-white p-2 rounded-md shadow-md text-gray-700 lg:hidden">
        <i class="fa fa-bars"></i>
    </button>

    <!-- 顶部导航 -->
    <header class="bg-white shadow h-16 lg:pl-64">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">卡密导出</h1>
                </div>
                <div class="flex items-center">
                    <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                        <i class="fa fa-sign-out mr-1"></i>退出登录
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- 侧边栏遮罩层 -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden hidden"></div>

    <!-- 主容器 -->
    <div class="flex min-h-[calc(100vh-4rem)] h-screen overflow-hidden">
        <!-- 侧边栏 -->
        <aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
            <div class="h-full pb-4">
                <nav class="px-2 space-y-1">
                    <a href="dashboard.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tachometer mr-3"></i>仪表盘
                    </a>
                    <a href="cards_list.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-list-alt mr-3"></i>卡密管理
                    </a>
                    <a href="card_search.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-search mr-3"></i>卡密查询
                    </a>
                    <a href="card_add.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-plus-circle mr-3"></i>添加卡密
                    </a>
                    <a href="card_upload.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-upload mr-3"></i>卡密上传
                    </a>
                    <a href="card_export.php" class="bg-blue-600 text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-download mr-3"></i>卡密导出
                    </a>
                    <a href="categories.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-tags mr-3"></i>分类管理
                    </a>
                    <a href="batch_generate.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-cubes mr-3"></i>批量生成
                    </a>
                    <a href="bark_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-bell mr-3"></i>Bark通知设置
                    </a>
                    <a href="email_settings.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-envelope w-5 mr-3"></i>邮箱配置
                    </a>
                     <a href="website_settings.php" class="sidebar-menu-link <?php echo $currentPage === 'website_settings.php' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium">
                <i class="fa fa-cog mr-3"></i>网站设置
            </a>
                    <a href="profile.php" class="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                        <i class="fa fa-user mr-3"></i>个人设置
                    </a>
                </nav>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="flex-1 overflow-y-auto">
            <div class="px-4 sm:px-6 lg:px-8 py-6">
                <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-semibold text-gray-800">卡密导出</h2>
                <p class="mt-1 text-gray-600">支持多种格式导出卡密数据，可按条件筛选导出内容</p>
            </div>
            
            <!-- 消息提示 -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-md <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                         ($messageType === 'warning' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800');
                ?>">
                    <i class="fa <?php 
                        echo $messageType === 'success' ? 'fa-check-circle' : 
                             ($messageType === 'warning' ? 'fa-exclamation-triangle' : 'fa-exclamation-circle');
                    ?> mr-2"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 统计信息 -->
            <div class="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-white shadow rounded-lg p-6">
                    <div class="flex items-center">
                        <div class="flex-shrink-0 bg-blue-100 p-3 rounded-full">
                            <i class="fa fa-credit-card text-blue-600 text-xl"></i>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500">总卡密数量</dt>
                                <dd class="text-lg font-semibold text-gray-900"><?php echo number_format($totalCards); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white shadow rounded-lg p-6">
                    <div class="flex items-center">
                        <div class="flex-shrink-0 bg-green-100 p-3 rounded-full">
                            <i class="fa fa-check-circle text-green-600 text-xl"></i>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500">已使用卡密</dt>
                                <dd class="text-lg font-semibold text-gray-900"><?php echo number_format($usedCards); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white shadow rounded-lg p-6">
                    <div class="flex items-center">
                        <div class="flex-shrink-0 bg-yellow-100 p-3 rounded-full">
                            <i class="fa fa-clock-o text-yellow-600 text-xl"></i>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500">未使用卡密</dt>
                                <dd class="text-lg font-semibold text-gray-900"><?php echo number_format($unusedCards); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 导出表单 -->
            <div class="bg-white shadow rounded-lg p-6">
                <form method="post" id="exportForm">
                    <input type="hidden" name="export_action" value="1">
                    
                    <!-- 导出格式 -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">导出格式</h3>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <label class="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="export_format" value="csv" class="mr-3" checked>
                                <div>
                                    <div class="font-medium text-gray-900">CSV</div>
                                    <div class="text-sm text-gray-500">Excel兼容</div>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="export_format" value="excel" class="mr-3">
                                <div>
                                    <div class="font-medium text-gray-900">Excel</div>
                                    <div class="text-sm text-gray-500">.xls格式</div>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="export_format" value="json" class="mr-3">
                                <div>
                                    <div class="font-medium text-gray-900">JSON</div>
                                    <div class="text-sm text-gray-500">结构化数据</div>
                                </div>
                            </label>
                            
                            <label class="flex items-center p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="export_format" value="txt" class="mr-3">
                                <div>
                                    <div class="font-medium text-gray-900">TXT</div>
                                    <div class="text-sm text-gray-500">纯文本格式</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <!-- 筛选条件 -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">筛选条件</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div>
                                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">分类</label>
                                <select name="category_id" id="category_id" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="">全部分类</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">状态</label>
                                <select name="status" id="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="">全部状态</option>
                                    <option value="unused">未使用</option>
                                    <option value="using">使用中</option>
                                    <option value="used">已使用</option>
                                    <option value="expired">已过期</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="date_from" class="block text-sm font-medium text-gray-700 mb-1">创建时间从</label>
                                <input type="date" name="date_from" id="date_from" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label for="date_to" class="block text-sm font-medium text-gray-700 mb-1">创建时间到</label>
                                <input type="date" name="date_to" id="date_to" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                    </div>

                    <!-- 导出选项 -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-800 mb-4">导出选项</h3>
                        <div class="space-y-3">
                            <label class="flex items-center">
                                <input type="checkbox" name="include_headers" value="1" checked class="mr-3">
                                <span class="text-sm text-gray-700">包含表头（CSV/Excel格式）</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="include_used_info" value="1" checked class="mr-3">
                                <span class="text-sm text-gray-700">包含使用信息（IP、时间等）</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="only_unused" value="1" class="mr-3">
                                <span class="text-sm text-gray-700">仅导出未使用的卡密</span>
                            </label>
                        </div>
                    </div>

                    <!-- 提交按钮 -->
                    <div class="flex justify-end space-x-3">
                        <button type="button" id="previewBtn" class="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 transition duration-200">
                            <i class="fa fa-eye mr-2"></i>预览数据
                        </button>
                        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200">
                            <i class="fa fa-download mr-2"></i>开始导出
                        </button>
                    </div>
                </form>
            </div>

            <!-- 快速导出 -->
            <div class="mt-6 bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-800 mb-4">快速导出</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <a href="?quick_export=all_unused&format=csv" class="flex items-center p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200">
                        <i class="fa fa-download text-blue-600 mr-3"></i>
                        <div>
                            <div class="font-medium text-gray-900">导出未使用</div>
                            <div class="text-sm text-gray-500">CSV格式</div>
                        </div>
                    </a>
                    
                    <a href="?quick_export=all_used&format=csv" class="flex items-center p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200">
                        <i class="fa fa-download text-green-600 mr-3"></i>
                        <div>
                            <div class="font-medium text-gray-900">导出已使用</div>
                            <div class="text-sm text-gray-500">CSV格式</div>
                        </div>
                    </a>
                    
                    <a href="?quick_export=all&format=json" class="flex items-center p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200">
                        <i class="fa fa-download text-purple-600 mr-3"></i>
                        <div>
                            <div class="font-medium text-gray-900">导出全部</div>
                            <div class="text-sm text-gray-500">JSON格式</div>
                        </div>
                    </a>
                    
                    <a href="?quick_export=recent&format=csv" class="flex items-center p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-200">
                        <i class="fa fa-download text-orange-600 mr-3"></i>
                        <div>
                            <div class="font-medium text-gray-900">最近7天</div>
                            <div class="text-sm text-gray-500">CSV格式</div>
                        </div>
                    </a>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/common.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 快速导出处理
            const quickExportLinks = document.querySelectorAll('a[href*="quick_export"]');
            quickExportLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = this.getAttribute('href');
                    if (confirm('确定要开始导出吗？')) {
                        window.location.href = url;
                    }
                });
            });

            // 预览功能
            document.getElementById('previewBtn').addEventListener('click', function() {
                const form = document.getElementById('exportForm');
                const formData = new FormData(form);
                formData.append('preview', '1');
                
                // 这里可以实现预览功能
                alert('预览功能开发中...');
            });

            // 表单验证
            document.getElementById('exportForm').addEventListener('submit', function(e) {
                const dateFrom = document.getElementById('date_from').value;
                const dateTo = document.getElementById('date_to').value;
                
                if (dateFrom && dateTo && dateFrom > dateTo) {
                    e.preventDefault();
                    alert('开始日期不能晚于结束日期');
                    return false;
                }
            });
        });
    </script>
</body>
</html>
