<?php
/**
 * 卡密验证 API 接口
 * 提供RESTful API用于卡密验证
 * 
 * 请求方式: POST
 * Content-Type: application/json
 * 
 * 请求参数:
 * {
 *   "card_code": "卡密代码",
 *   "client_info": {
 *     "user_agent": "浏览器信息",
 *     "ip": "客户端IP",
 *     "language": "语言设置"
 *   }
 * }
 * 
 * 响应格式:
 * {
 *   "success": true/false,
 *   "code": 200/400/401/404/500,
 *   "message": "响应消息",
 *   "data": {
 *     "card_id": 123,
 *     "card_code": "ABC123",
 *     "content": "卡密内容",
 *     "category_name": "分类名称",
 *     "status": "success/error/expired/used/invalid_ip",
 *     "remaining_uses": 2,
 *     "max_uses": 3,
 *     "valid_until": "2024-12-31 23:59:59",
 *     "first_use_ip": "192.168.1.1",
 *     "device_info": "设备信息"
 *   },
 *   "timestamp": "2024-01-01 12:00:00"
 * }
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求（CORS预检）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 只允许POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'code' => 405,
        'message' => '只支持POST请求',
        'data' => null,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// 引入必要的文件
require_once '../db_connect.php';
require_once '../email_utils.php';

/**
 * 发送JSON响应
 */
function sendResponse($success, $code, $message, $data = null) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'code' => $code,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 获取客户端IP
 */
function getClientIP() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '未知';
    
    // 检查代理服务器
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwardedIPs = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($forwardedIPs[0]);
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }
    
    // 验证IP格式
    if (!filter_var($ip, FILTER_VALIDATE_IP) && $ip !== '未知') {
        $ip = '未知';
    }
    
    return $ip;
}

/**
 * 获取设备信息
 */
function getDeviceInfo($clientInfo = null) {
    $deviceInfo = [];
    
    if ($clientInfo && isset($clientInfo['user_agent'])) {
        $deviceInfo[] = "浏览器: " . $clientInfo['user_agent'];
    } else {
        $deviceInfo[] = "浏览器: " . ($_SERVER['HTTP_USER_AGENT'] ?? '未知');
    }
    
    if ($clientInfo && isset($clientInfo['ip'])) {
        $deviceInfo[] = "IP地址: " . $clientInfo['ip'];
    } else {
        $deviceInfo[] = "IP地址: " . getClientIP();
    }
    
    if ($clientInfo && isset($clientInfo['language'])) {
        $deviceInfo[] = "语言: " . $clientInfo['language'];
    } else {
        $deviceInfo[] = "语言: " . ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '未知');
    }
    
    return implode(' | ', $deviceInfo);
}

/**
 * 发送Bark通知
 */
function sendBarkNotification($apiBase, $title, $content, $icon = '') {
    if (empty($apiBase)) {
        return [false, "Bark API基础地址未配置"];
    }
    
    try {
        $url = rtrim($apiBase, '/') . "/$title/" . urlencode($content) . "?automaticallyCopy=1";
        
        if (!empty($icon)) {
            $url .= "&icon=" . urlencode($icon);
        }
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode != 200) {
            throw new Exception("HTTP状态码: $httpCode");
        }
        
        $result = json_decode($response, true);
        if (isset($result['code']) && $result['code'] == 200) {
            return [true, "发送成功"];
        } else {
            throw new Exception("Bark返回错误");
        }
    } catch (Exception $e) {
        error_log("Bark通知失败: " . $e->getMessage());
        return [false, $e->getMessage()];
    }
}

try {
    // 获取请求数据
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    // 验证JSON格式
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendResponse(false, 400, '无效的JSON格式');
    }
    
    // 验证必需参数
    if (empty($data['card_code'])) {
        sendResponse(false, 400, '缺少卡密代码参数');
    }
    
    $cardCode = trim($data['card_code']);
    $clientInfo = $data['client_info'] ?? [];
    
    // 获取设备信息
    $deviceInfo = getDeviceInfo($clientInfo);
    $userIP = $clientInfo['ip'] ?? getClientIP();
    
    // 初始化数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        sendResponse(false, 500, '数据库连接失败');
    }
    
    // 读取Bark设置
    $barkSettings = [
        'bark_enabled' => 0,
        'bark_server' => 'https://api.day.app',
        'bark_device_key' => '',
        'bark_icon' => ''
    ];
    
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?)");
    $stmt->execute(['bark_enabled', 'bark_server', 'bark_device_key', 'bark_icon']);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($rows as $row) {
        if (isset($barkSettings[$row['setting_key']])) {
            $barkSettings[$row['setting_key']] = $row['setting_value'];
        }
    }
    
    // 查询卡密信息
    $stmt = $pdo->prepare("
        SELECT c.*, cat.name as category_name 
        FROM cards c 
        LEFT JOIN categories cat ON c.category_id = cat.id 
        WHERE c.card_code = :code LIMIT 1
    ");
    $stmt->execute([':code' => $cardCode]);
    $card = $stmt->fetch();
    
    if (!$card) {
        sendResponse(false, 404, '无效的卡密', [
            'status' => 'invalid',
            'card_code' => $cardCode
        ]);
    }
    
    $categoryName = $card['category_name'] ?? '未知分类';
    
    // 检查卡密状态
    if ($card['valid_until'] && strtotime($card['valid_until']) < time()) {
        sendResponse(false, 400, '该卡密已过期', [
            'card_id' => $card['id'],
            'card_code' => $card['card_code'],
            'category_name' => $categoryName,
            'status' => 'expired',
            'valid_until' => $card['valid_until'],
            'expired_at' => date('Y-m-d H:i:s', strtotime($card['valid_until']))
        ]);
    }
    
    if ($card['current_uses'] >= $card['max_uses']) {
        sendResponse(false, 400, '该卡密使用次数已满', [
            'card_id' => $card['id'],
            'card_code' => $card['card_code'],
            'category_name' => $categoryName,
            'status' => 'used',
            'current_uses' => $card['current_uses'],
            'max_uses' => $card['max_uses']
        ]);
    }
    
    // IP绑定检查
    $isFirstUse = $card['current_uses'] == 0;
    
    if (!empty($card['first_use_ip'])) {
        if ($card['first_use_ip'] !== $userIP) {
            sendResponse(false, 401, '该卡密已绑定其他IP地址', [
                'card_id' => $card['id'],
                'card_code' => $card['card_code'],
                'category_name' => $categoryName,
                'status' => 'invalid_ip',
                'bound_ip' => $card['first_use_ip'],
                'current_ip' => $userIP
            ]);
        }
        $ipMatch = true;
    } elseif ($isFirstUse && empty($card['first_use_ip'])) {
        // 首次使用，绑定IP
        $stmt = $pdo->prepare("UPDATE cards SET 
                             first_use_ip = :first_use_ip,
                             last_use_ip = :last_use_ip,
                             current_uses = current_uses + 1,
                             used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                             is_used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                             used_at = CASE WHEN (current_uses + 1) >= max_uses THEN :used_at ELSE used_at END,
                             device_info = :device_info,
                             updated_at = CURRENT_TIMESTAMP 
                             WHERE id = :id");
        $stmt->execute([
            ':first_use_ip' => $userIP,
            ':last_use_ip' => $userIP,
            ':used_at' => date('Y-m-d H:i:s'),
            ':device_info' => $deviceInfo,
            ':id' => $card['id']
        ]);
        $firstUseSuccess = true;
    } else {
        sendResponse(false, 500, '卡密状态异常', [
            'card_id' => $card['id'],
            'card_code' => $card['card_code'],
            'status' => 'error'
        ]);
    }
    
    // 更新使用次数（非首次使用）
    if (isset($ipMatch) && $ipMatch) {
        $stmt = $pdo->prepare("UPDATE cards SET 
                             last_use_ip = :last_use_ip,
                             current_uses = current_uses + 1,
                             used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                             is_used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                             used_at = CASE WHEN (current_uses + 1) >= max_uses THEN :used_at ELSE used_at END,
                             device_info = :device_info,
                             updated_at = CURRENT_TIMESTAMP 
                             WHERE id = :id");
        $stmt->execute([
            ':last_use_ip' => $userIP,
            ':used_at' => date('Y-m-d H:i:s'),
            ':device_info' => $deviceInfo,
            ':id' => $card['id']
        ]);
    }
    
    // 重新查询更新后的卡密信息
    $stmt = $pdo->prepare("
        SELECT c.*, cat.name as category_name 
        FROM cards c 
        LEFT JOIN categories cat ON c.category_id = cat.id 
        WHERE c.id = :id LIMIT 1
    ");
    $stmt->execute([':id' => $card['id']]);
    $updatedCard = $stmt->fetch();
    
    // 发送邮件通知
    $emailUtils = new EmailUtils();
    $config = require '../config.php';
    $usedAt = date('Y-m-d H:i:s');
    
    list($emailSuccess, $emailMsg) = $emailUtils->sendCardUsedNotification(
        $config['email']['admin_notify_email'],
        [
            'card_id' => $updatedCard['id'],
            'card_code' => $updatedCard['card_code'],
            'category_id' => $updatedCard['category_id'],
            'used_at' => $usedAt,
            'device_info' => $deviceInfo
        ]
    );
    
    // 发送Bark通知
    $barkStatus = "未启用";
    if ($barkSettings['bark_enabled'] == 1) {
        $barkApiBase = rtrim($barkSettings['bark_server'], '/') . '/' . $barkSettings['bark_device_key'];
        list($barkSuccess, $barkMsg) = sendBarkNotification(
            $barkApiBase,
            '卡密验证成功',
            "卡密: $cardCode | 商品类型: $categoryName | 使用时间: $usedAt",
            $barkSettings['bark_icon']
        );
        $barkStatus = ($barkSuccess ? "通知成功" : "通知失败：$barkMsg");
    }
    
    // 返回成功响应
    sendResponse(true, 200, '卡密验证成功', [
        'card_id' => $updatedCard['id'],
        'card_code' => $updatedCard['card_code'],
        'content' => $updatedCard['content'],
        'category_name' => $updatedCard['category_name'],
        'status' => 'success',
        'remaining_uses' => $updatedCard['max_uses'] - $updatedCard['current_uses'],
        'current_uses' => $updatedCard['current_uses'],
        'max_uses' => $updatedCard['max_uses'],
        'valid_until' => $updatedCard['valid_until'],
        'first_use_ip' => $updatedCard['first_use_ip'],
        'last_use_ip' => $updatedCard['last_use_ip'],
        'device_info' => $deviceInfo,
        'used_at' => $usedAt,
        'is_completely_used' => $updatedCard['current_uses'] >= $updatedCard['max_uses'],
        'notifications' => [
            'email' => $emailSuccess ? '发送成功' : '发送失败：' . $emailMsg,
            'bark' => $barkStatus
        ]
    ]);
    
} catch (Exception $e) {
    error_log("API验证错误：" . $e->getMessage());
    sendResponse(false, 500, '服务器内部错误：' . $e->getMessage());
}
?>
