<?php
/**
 * 卡密统计 API 接口
 * 提供卡密使用统计信息
 * 
 * 请求方式: GET
 * 
 * 响应格式:
 * {
 *   "success": true,
 *   "code": 200,
 *   "message": "获取统计成功",
 *   "data": {
 *     "total_cards": 1000,
 *     "used_cards": 300,
 *     "unused_cards": 700,
 *     "expired_cards": 50,
 *     "categories": [
 *       {
 *         "id": 1,
 *         "name": "VIP会员",
 *         "total": 500,
 *         "used": 150,
 *         "unused": 350
 *       }
 *     ],
 *     "recent_activities": [
 *       {
 *         "card_code": "ABC123",
 *         "category_name": "VIP会员",
 *         "used_at": "2024-01-01 12:00:00",
 *         "ip": "192.168.1.1"
 *       }
 *     ],
 *     "daily_stats": [
 *       {
 *         "date": "2024-01-01",
 *         "used_count": 25
 *       }
 *     ]
 *   },
 *   "timestamp": "2024-01-01 12:00:00"
 * }
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求（CORS预检）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 只允许GET请求
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'code' => 405,
        'message' => '只支持GET请求',
        'data' => null,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// 引入必要的文件
require_once '../db_connect.php';

/**
 * 发送JSON响应
 */
function sendResponse($success, $code, $message, $data = null) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'code' => $code,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 初始化数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        sendResponse(false, 500, '数据库连接失败');
    }
    
    // 获取基础统计
    $stats = [];
    
    // 总卡密数量
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards");
    $stats['total_cards'] = (int)$stmt->fetchColumn();
    
    // 已使用卡密数量
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards WHERE is_used = 1");
    $stats['used_cards'] = (int)$stmt->fetchColumn();
    
    // 未使用卡密数量
    $stats['unused_cards'] = $stats['total_cards'] - $stats['used_cards'];
    
    // 过期卡密数量
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM cards WHERE valid_until IS NOT NULL AND valid_until < NOW()");
    $stats['expired_cards'] = (int)$stmt->fetchColumn();
    
    // 按分类统计
    $stmt = $pdo->query("
        SELECT 
            c.id,
            c.name,
            COUNT(k.id) as total,
            COUNT(CASE WHEN k.is_used = 1 THEN 1 END) as used,
            COUNT(CASE WHEN k.is_used = 0 THEN 1 END) as unused
        FROM categories c
        LEFT JOIN cards k ON c.id = k.category_id
        GROUP BY c.id, c.name
        ORDER BY c.name ASC
    ");
    $stats['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 最近使用记录
    $stmt = $pdo->query("
        SELECT 
            k.card_code,
            c.name as category_name,
            k.used_at,
            k.first_use_ip as ip
        FROM cards k
        LEFT JOIN categories c ON k.category_id = c.id
        WHERE k.is_used = 1 AND k.used_at IS NOT NULL
        ORDER BY k.used_at DESC
        LIMIT 10
    ");
    $stats['recent_activities'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 最近7天使用统计
    $stmt = $pdo->query("
        SELECT 
            DATE(used_at) as date,
            COUNT(*) as used_count
        FROM cards 
        WHERE used_at IS NOT NULL 
        AND used_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(used_at)
        ORDER BY date DESC
    ");
    $stats['daily_stats'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 使用率计算
    $stats['usage_rate'] = $stats['total_cards'] > 0 ? 
        round(($stats['used_cards'] / $stats['total_cards']) * 100, 2) : 0;
    
    // 今日使用统计
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM cards 
        WHERE DATE(used_at) = CURDATE()
    ");
    $stats['today_used'] = (int)$stmt->fetchColumn();
    
    // 本周使用统计
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM cards 
        WHERE used_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stats['week_used'] = (int)$stmt->fetchColumn();
    
    // 本月使用统计
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM cards 
        WHERE YEAR(used_at) = YEAR(NOW()) 
        AND MONTH(used_at) = MONTH(NOW())
    ");
    $stats['month_used'] = (int)$stmt->fetchColumn();
    
    sendResponse(true, 200, '获取统计成功', $stats);
    
} catch (Exception $e) {
    error_log("API统计错误：" . $e->getMessage());
    sendResponse(false, 500, '服务器内部错误：' . $e->getMessage());
}
?>
