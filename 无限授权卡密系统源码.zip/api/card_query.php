<?php
/**
 * 卡密查询 API 接口
 * 提供卡密信息查询功能
 * 
 * 请求方式: GET
 * 参数: card_code (必需)
 * 
 * 响应格式:
 * {
 *   "success": true,
 *   "code": 200,
 *   "message": "查询成功",
 *   "data": {
 *     "card_id": 123,
 *     "card_code": "ABC123",
 *     "content": "卡密内容",
 *     "category_name": "分类名称",
 *     "status": "unused/using/used/expired",
 *     "current_uses": 1,
 *     "max_uses": 3,
 *     "valid_until": "2024-12-31 23:59:59",
 *     "first_use_ip": "192.168.1.1",
 *     "last_use_ip": "192.168.1.1",
 *     "created_at": "2024-01-01 12:00:00",
 *     "used_at": "2024-01-01 12:00:00"
 *   },
 *   "timestamp": "2024-01-01 12:00:00"
 * }
 */

// 设置响应头
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理OPTIONS请求（CORS预检）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 只允许GET请求
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'code' => 405,
        'message' => '只支持GET请求',
        'data' => null,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// 引入必要的文件
require_once '../db_connect.php';

/**
 * 发送JSON响应
 */
function sendResponse($success, $code, $message, $data = null) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'code' => $code,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 获取查询参数
    $cardCode = $_GET['card_code'] ?? '';
    
    if (empty($cardCode)) {
        sendResponse(false, 400, '缺少卡密代码参数');
    }
    
    $cardCode = trim($cardCode);
    
    // 初始化数据库连接
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    if (!$pdo) {
        sendResponse(false, 500, '数据库连接失败');
    }
    
    // 查询卡密信息
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cat.name as category_name,
            CASE 
                WHEN c.valid_until IS NOT NULL AND c.valid_until < NOW() THEN 'expired'
                WHEN c.current_uses >= c.max_uses THEN 'used'
                WHEN c.current_uses > 0 THEN 'using'
                ELSE 'unused'
            END as status
        FROM cards c
        LEFT JOIN categories cat ON c.category_id = cat.id
        WHERE c.card_code = :code
        LIMIT 1
    ");
    $stmt->execute([':code' => $cardCode]);
    $card = $stmt->fetch();
    
    if (!$card) {
        sendResponse(false, 404, '卡密不存在', [
            'card_code' => $cardCode,
            'status' => 'not_found'
        ]);
    }
    
    // 构建响应数据
    $responseData = [
        'card_id' => (int)$card['id'],
        'card_code' => $card['card_code'],
        'content' => $card['content'],
        'category_name' => $card['category_name'] ?? '未分类',
        'status' => $card['status'],
        'current_uses' => (int)$card['current_uses'],
        'max_uses' => (int)$card['max_uses'],
        'valid_until' => $card['valid_until'],
        'first_use_ip' => $card['first_use_ip'],
        'last_use_ip' => $card['last_use_ip'],
        'created_at' => $card['created_at'],
        'used_at' => $card['used_at'],
        'device_info' => $card['device_info'],
        'remaining_uses' => max(0, $card['max_uses'] - $card['current_uses']),
        'is_expired' => $card['valid_until'] && strtotime($card['valid_until']) < time(),
        'is_fully_used' => $card['current_uses'] >= $card['max_uses']
    ];
    
    sendResponse(true, 200, '查询成功', $responseData);
    
} catch (Exception $e) {
    error_log("API查询错误：" . $e->getMessage());
    sendResponse(false, 500, '服务器内部错误：' . $e->getMessage());
}
?>
