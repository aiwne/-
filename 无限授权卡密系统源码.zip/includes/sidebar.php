<?php
/**
 * 通用侧边栏组件
 * 避免代码重复，统一管理侧边栏
 */

// 获取当前页面名称
$currentPage = basename($_SERVER['PHP_SELF']);

// 侧边栏菜单项配置
$menuItems = [
    [
        'url' => 'dashboard.php',
        'icon' => 'fa-tachometer',
        'text' => '仪表盘',
        'active' => $currentPage === 'dashboard.php'
    ],
    [
        'url' => 'cards_list.php',
        'icon' => 'fa-list-alt',
        'text' => '卡密管理',
        'active' => $currentPage === 'cards_list.php'
    ],
    [
        'url' => 'card_add.php',
        'icon' => 'fa-plus-circle',
        'text' => '添加卡密',
        'active' => $currentPage === 'card_add.php'
    ],
    [
        'url' => 'categories.php',
        'icon' => 'fa-tags',
        'text' => '分类管理',
        'active' => $currentPage === 'categories.php'
    ],
    [
        'url' => 'batch_generate.php',
        'icon' => 'fa-cubes',
        'text' => '批量生成',
        'active' => $currentPage === 'batch_generate.php'
    ],
    [
        'url' => 'bark_settings.php',
        'icon' => 'fa-bell',
        'text' => 'Bark通知设置',
        'active' => $currentPage === 'bark_settings.php'
    ],
    [
        'url' => 'email_settings.php',
        'icon' => 'fa-envelope',
        'text' => '邮箱配置',
        'active' => $currentPage === 'email_settings.php'
    ],
    [
        'url' => 'profile.php',
        'icon' => 'fa-user',
        'text' => '个人设置',
        'active' => $currentPage === 'profile.php'
    ]
];
?>

<!-- 侧边栏 -->
<aside id="sidebar" class="fixed lg:static top-0 left-0 z-40 h-full w-64 bg-gray-800 overflow-y-auto border-r border-gray-700 transition-all duration-300 sidebar-hidden lg:sidebar-visible pt-16 lg:pt-5">
    <div class="h-full pb-4">
        <nav class="px-2 space-y-1">
            <?php foreach ($menuItems as $item): ?>
                <a href="<?php echo $item['url']; ?>" 
                   class="<?php echo $item['active'] ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'; ?> block px-3 py-2 rounded-md text-base font-medium transition duration-150">
                    <i class="fa <?php echo $item['icon']; ?> mr-3"></i><?php echo $item['text']; ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </div>
</aside>
