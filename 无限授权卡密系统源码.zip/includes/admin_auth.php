<?php
/**
 * 管理员身份验证工具
 */

// 检查管理员是否已登录
function isAdminLoggedIn() {
    session_start();
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// 管理员登录处理
function adminLogin($username, $password) {
    try {
        $config = require_once '../config.php';
        $dbConfig = $config['database'];
        
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset={$dbConfig['charset']}";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        // 查询管理员信息（假设存在admin表存储管理员账号）
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username LIMIT 1");
        $stmt->execute([':username' => $username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$admin) {
            return [false, "用户名不存在"];
        }
        
        // 验证密码（假设密码使用password_hash加密存储）
        if (!password_verify($password, $admin['password'])) {
            return [false, "密码错误"];
        }
        
        // 设置登录状态
        session_start();
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_id'] = $admin['id'];
        
        return [true, "登录成功"];
    } catch (PDOException $e) {
        error_log("管理员登录数据库错误: " . $e->getMessage());
        return [false, "登录失败，请稍后重试"];
    }
}

// 管理员退出登录
function adminLogout() {
    session_start();
    $_SESSION = [];
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
}
?>
    