<?php
/**
 * 性能监控工具类
 * 提供查询性能监控、缓存管理等功能
 */
class Performance {
    
    private static $queryTimes = [];
    private static $cache = [];
    private static $cacheEnabled = true;
    
    /**
     * 开始查询计时
     */
    public static function startQuery($queryId) {
        self::$queryTimes[$queryId] = microtime(true);
    }
    
    /**
     * 结束查询计时
     */
    public static function endQuery($queryId) {
        if (isset(self::$queryTimes[$queryId])) {
            $time = microtime(true) - self::$queryTimes[$queryId];
            unset(self::$queryTimes[$queryId]);
            
            // 记录慢查询
            if ($time > 1.0) { // 超过1秒的查询
                self::logSlowQuery($queryId, $time);
            }
            
            return $time;
        }
        return 0;
    }
    
    /**
     * 记录慢查询
     */
    private static function logSlowQuery($queryId, $time) {
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/slow_queries_' . date('Y-m-d') . '.log';
        $logMessage = '[' . date('Y-m-d H:i:s') . '] Slow Query: ' . $queryId . ' | Time: ' . $time . "s\n";
        
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * 设置缓存
     */
    public static function setCache($key, $value, $ttl = 300) {
        if (!self::$cacheEnabled) return false;
        
        self::$cache[$key] = [
            'value' => $value,
            'expires' => time() + $ttl
        ];
        
        return true;
    }
    
    /**
     * 获取缓存
     */
    public static function getCache($key) {
        if (!self::$cacheEnabled || !isset(self::$cache[$key])) {
            return null;
        }
        
        $item = self::$cache[$key];
        
        if (time() > $item['expires']) {
            unset(self::$cache[$key]);
            return null;
        }
        
        return $item['value'];
    }
    
    /**
     * 清除缓存
     */
    public static function clearCache($key = null) {
        if ($key === null) {
            self::$cache = [];
        } else {
            unset(self::$cache[$key]);
        }
    }
    
    /**
     * 启用/禁用缓存
     */
    public static function setCacheEnabled($enabled) {
        self::$cacheEnabled = $enabled;
    }
    
    /**
     * 获取内存使用情况
     */
    public static function getMemoryUsage() {
        return [
            'current' => memory_get_usage(true),
            'peak' => memory_get_peak_usage(true),
            'current_formatted' => self::formatBytes(memory_get_usage(true)),
            'peak_formatted' => self::formatBytes(memory_get_peak_usage(true))
        ];
    }
    
    /**
     * 获取执行时间
     */
    public static function getExecutionTime() {
        return microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'];
    }
    
    /**
     * 格式化字节数
     */
    private static function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
    
    /**
     * 获取性能统计
     */
    public static function getStats() {
        return [
            'memory' => self::getMemoryUsage(),
            'execution_time' => self::getExecutionTime(),
            'cache_size' => count(self::$cache),
            'queries_tracked' => count(self::$queryTimes)
        ];
    }
    
    /**
     * 输出性能信息（调试用）
     */
    public static function debugOutput() {
        if (!defined('DEBUG') || !DEBUG) return;
        
        $stats = self::getStats();
        
        echo "<!-- Performance Debug Info:\n";
        echo "Memory Usage: " . $stats['memory']['current_formatted'] . " (Peak: " . $stats['memory']['peak_formatted'] . ")\n";
        echo "Execution Time: " . round($stats['execution_time'], 4) . "s\n";
        echo "Cache Size: " . $stats['cache_size'] . " items\n";
        echo "Queries Tracked: " . $stats['queries_tracked'] . "\n";
        echo "-->\n";
    }
}
?>
