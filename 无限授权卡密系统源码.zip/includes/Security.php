<?php
/**
 * 安全工具类
 * 提供CSRF保护、输入验证、输出转义等安全功能
 */
class Security {
    
    /**
     * 生成CSRF令牌
     */
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * 验证CSRF令牌
     */
    public static function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * 输出CSRF令牌隐藏字段
     */
    public static function csrfField() {
        $token = self::generateCSRFToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
    }
    
    /**
     * 清理和验证输入
     */
    public static function sanitizeInput($input, $type = 'string') {
        switch ($type) {
            case 'email':
                return filter_var(trim($input), FILTER_SANITIZE_EMAIL);
            case 'int':
                return filter_var($input, FILTER_SANITIZE_NUMBER_INT);
            case 'float':
                return filter_var($input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            case 'url':
                return filter_var(trim($input), FILTER_SANITIZE_URL);
            case 'string':
            default:
                return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * 验证输入格式
     */
    public static function validateInput($input, $type, $required = true) {
        if ($required && empty($input)) {
            return false;
        }
        
        if (!$required && empty($input)) {
            return true;
        }
        
        switch ($type) {
            case 'email':
                return filter_var($input, FILTER_VALIDATE_EMAIL) !== false;
            case 'int':
                return filter_var($input, FILTER_VALIDATE_INT) !== false;
            case 'float':
                return filter_var($input, FILTER_VALIDATE_FLOAT) !== false;
            case 'url':
                return filter_var($input, FILTER_VALIDATE_URL) !== false;
            case 'alphanumeric':
                return ctype_alnum($input);
            case 'alpha':
                return ctype_alpha($input);
            case 'numeric':
                return ctype_digit($input);
            default:
                return true;
        }
    }
    
    /**
     * 安全输出HTML
     */
    public static function output($string, $flags = ENT_QUOTES) {
        return htmlspecialchars($string, $flags, 'UTF-8');
    }
    
    /**
     * 安全输出URL
     */
    public static function outputUrl($url) {
        return htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * 生成安全的随机字符串
     */
    public static function generateRandomString($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    /**
     * 密码哈希
     */
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }
    
    /**
     * 验证密码
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 检查密码强度
     */
    public static function checkPasswordStrength($password) {
        $score = 0;
        
        // 长度检查
        if (strlen($password) >= 8) $score++;
        if (strlen($password) >= 12) $score++;
        
        // 字符类型检查
        if (preg_match('/[a-z]/', $password)) $score++;
        if (preg_match('/[A-Z]/', $password)) $score++;
        if (preg_match('/[0-9]/', $password)) $score++;
        if (preg_match('/[^a-zA-Z0-9]/', $password)) $score++;
        
        return $score;
    }
    
    /**
     * 防止暴力破解
     */
    public static function checkBruteForce($identifier, $maxAttempts = 5, $lockoutTime = 900) {
        $key = 'brute_force_' . md5($identifier);
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['attempts' => 0, 'last_attempt' => 0];
        }
        
        $data = $_SESSION[$key];
        
        // 检查是否在锁定时间内
        if ($data['attempts'] >= $maxAttempts && 
            (time() - $data['last_attempt']) < $lockoutTime) {
            return false;
        }
        
        // 如果超过锁定时间，重置计数
        if ((time() - $data['last_attempt']) >= $lockoutTime) {
            $_SESSION[$key] = ['attempts' => 0, 'last_attempt' => 0];
        }
        
        return true;
    }
    
    /**
     * 记录失败尝试
     */
    public static function recordFailedAttempt($identifier) {
        $key = 'brute_force_' . md5($identifier);
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['attempts' => 0, 'last_attempt' => 0];
        }
        
        $_SESSION[$key]['attempts']++;
        $_SESSION[$key]['last_attempt'] = time();
    }
    
    /**
     * 清除失败尝试记录
     */
    public static function clearFailedAttempts($identifier) {
        $key = 'brute_force_' . md5($identifier);
        unset($_SESSION[$key]);
    }
    
    /**
     * 获取客户端IP
     */
    public static function getClientIP() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    /**
     * 记录安全事件
     */
    public static function logSecurityEvent($event, $details = []) {
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/security_' . date('Y-m-d') . '.log';
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'event' => $event,
            'ip' => self::getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'details' => $details
        ];
        
        $logMessage = '[' . $logData['timestamp'] . '] ' . 
                     $logData['event'] . ' | IP: ' . $logData['ip'] . 
                     ' | Details: ' . json_encode($logData['details']) . "\n";
        
        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
}
?>
