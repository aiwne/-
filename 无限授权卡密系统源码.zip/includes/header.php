<?php
/**
 * 通用头部组件
 * 包含顶部导航栏和移动端菜单按钮
 */
?>

<!-- 移动端菜单按钮 -->
<button id="mobileMenuBtn" class="mobile-menu-btn">
    <i class="fa fa-bars"></i>
</button>

<!-- 顶部导航栏 -->
<header class="bg-white shadow h-16 lg:pl-64">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <h1 class="text-xl font-bold text-gray-800">卡密验证系统管理</h1>
            </div>
            <div class="flex items-center">
                <span class="text-gray-600 mr-4">欢迎, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? '管理员'); ?></span>
                <a href="logout.php" class="text-gray-600 hover:text-gray-900">
                    <i class="fa fa-sign-out mr-1"></i>退出登录
                </a>
            </div>
        </div>
    </div>
</header>

<!-- 侧边栏遮罩层 -->
<div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 z-30 lg:hidden"></div>
