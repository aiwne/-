<?php
/**
 * 卡密验证处理页面 - 带邮件发送和Bark通知功能
 */
require_once 'db_connect.php';
require_once 'email_utils.php';

$message = '';
$messageType = '';
$card = null;

// 获取网站设置
$websiteSettings = [
    'site_title' => '卡密验证系统',
    'site_logo_url' => '',
    'warm_reminder_title' => '温馨提示！',
    'warm_reminder_content' => '请保管好卡密内容，确保保存妥当，在此感谢你的关顾[爱心]',
    'warm_reminder_date' => date('Y-m-d'),
    'footer_text' => '© 2025 卡密验证系统 - by Lucky 版权所有 1.0',
    'verify_page_title' => '卡密验证',
    'verify_page_subtitle' => '以下是你的卡密信息'
];

try {
    $db = Database::getInstance();
    $pdo = $db->getPdo();
    
    // 从数据库读取网站设置
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        'site_title', 'site_logo_url', 'warm_reminder_title', 'warm_reminder_content',
        'warm_reminder_date', 'footer_text', 'verify_page_title', 'verify_page_subtitle'
    ]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($rows as $row) {
        if (isset($websiteSettings[$row['setting_key']])) {
            $websiteSettings[$row['setting_key']] = $row['setting_value'];
        }
    }
} catch (Exception $e) {
    error_log("读取网站设置失败：" . $e->getMessage());
}

// 添加链接转换函数：将文本中的URL转换为可点击链接（保留函数但调整使用场景）
function convertLinks($text) {
    // 先转义特殊字符防止XSS攻击
    $escapedText = htmlspecialchars($text, ENT_QUOTES);
    // 匹配URL的正则表达式（支持http/https）
    $urlPattern = '/(https?:\/\/[^\s]+)/';
    // 将URL替换为可点击的链接，添加target="_blank"确保新窗口打开
    $linkedText = preg_replace(
        $urlPattern,
        '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">$1</a>',
        $escapedText
    );
    // 保留换行符
    return nl2br($linkedText);
}

// 添加Bark通知发送函数（更新：支持自定义图标）
function sendBarkNotification($apiBase, $title, $content, $icon = '') {
    if (empty($apiBase)) {
        error_log("Bark API基础地址未配置");
        return [false, "Bark API基础地址未配置"];
    }
    
    try {
        $url = rtrim($apiBase, '/') . "/$title/" . urlencode($content) . "?automaticallyCopy=1";
        
        // 新增：添加图标参数
        if (!empty($icon)) {
            $url .= "&icon=" . urlencode($icon);
        }
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode != 200) {
            throw new Exception("HTTP状态码: $httpCode，响应: $response");
        }
        
        $result = json_decode($response, true);
        if (isset($result['code']) && $result['code'] == 200) {
            return [true, "发送成功"];
        } else {
            throw new Exception("Bark返回错误: " . json_encode($result));
        }
    } catch (Exception $e) {
        error_log("Bark通知失败: " . $e->getMessage());
        return [false, $e->getMessage()];
    }
}

// 获取设备信息函数（保持不变）
function getDeviceInfo() {
    $deviceInfo = [];
    $deviceInfo[] = "浏览器: " . (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '未知');
    $deviceInfo[] = "IP地址: " . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '未知');
    $deviceInfo[] = "语言: " . (isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '未知');
    return implode(' | ', $deviceInfo);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['card_code'])) {
    $cardCode = trim($_POST['card_code']);
    $deviceInfo = getDeviceInfo();
    $barkSettings = [
        'bark_enabled' => 0,
        'bark_server' => 'https://api.day.app',
        'bark_device_key' => '',
        'bark_icon' => '' // 新增：自定义图标设置
    ];
    
    try {
        $db = Database::getInstance();
        $pdo = $db->getPdo();
        
        if (!$pdo) {
            throw new Exception("数据库连接失败");
        }

        // 读取Bark设置（从数据库获取，新增bark_icon）
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?, ?, ?, ?)");
        $stmt->execute(['bark_enabled', 'bark_server', 'bark_device_key', 'bark_icon']);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($rows as $row) {
            if (isset($barkSettings[$row['setting_key']])) {
                $barkSettings[$row['setting_key']] = $row['setting_value'];
            }
        }

        // 构建Bark API基础地址
        $barkApiBase = rtrim($barkSettings['bark_server'], '/') . '/' . $barkSettings['bark_device_key'];
        
        // 查询卡密（关联分类表获取分类名称）
        $stmt = $pdo->prepare("
            SELECT c.*, cat.name as category_name 
            FROM cards c 
            LEFT JOIN categories cat ON c.category_id = cat.id 
            WHERE c.card_code = :code LIMIT 1
        ");
        $stmt->execute([':code' => $cardCode]);
        $card = $stmt->fetch();
        
        // 获取分类名称（默认未知分类）
        $categoryName = $card ? ($card['category_name'] ?? '未知分类') : '未知分类';
        
        if (!$card) {
            $message = "无效的卡密";
            $messageType = 'error';
            
        } else {
            // 检查卡密是否被封禁
            if (isset($card['is_banned']) && $card['is_banned']) {
                $message = "❌ 该卡密已被封禁，无法使用！\n\n" .
                          "💡 提示：请联系管理员处理此问题。";
                $messageType = 'error';
            }
            // 检查卡密是否过期
            elseif ($card['valid_until'] && strtotime($card['valid_until']) < time()) {
                $message = "该卡密已过期，有效期至：" . date('Y-m-d H:i:s', strtotime($card['valid_until']));
                $messageType = 'error';
            }
            // 检查使用次数是否已满
            elseif ($card['current_uses'] >= $card['max_uses']) {
                $message = "该卡密使用次数已满（{$card['current_uses']}/{$card['max_uses']}）";
                $messageType = 'error';
            } else {
                // 获取用户IP（支持代理服务器）
                $userIP = $_SERVER['REMOTE_ADDR'] ?? '未知';
                
                // 检查是否通过代理服务器
                if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $forwardedIPs = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                    $userIP = trim($forwardedIPs[0]);
                } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
                    $userIP = $_SERVER['HTTP_X_REAL_IP'];
                }
                
                // 验证IP地址格式
                if (!filter_var($userIP, FILTER_VALIDATE_IP) && $userIP !== '未知') {
                    error_log("无效IP地址 - 卡密ID: {$card['id']}, 用户IP: {$userIP}");
                    $userIP = '未知';
                }
                
                // 记录IP验证尝试
                error_log("卡密验证尝试 - 卡密ID: {$card['id']}, 用户IP: {$userIP}, 绑定IP: " . ($card['first_use_ip'] ?? '无'));
                
                // 检查是否是首次使用
                $isFirstUse = $card['current_uses'] == 0;
                
                // 严格的单IP绑定检查：确保一个卡密只能绑定一个IP
                if (!empty($card['first_use_ip'])) {
                    // 卡密已绑定IP，检查是否匹配
                    if ($card['first_use_ip'] !== $userIP) {
                        // 记录IP验证失败
                        error_log("IP验证失败 - 卡密ID: {$card['id']}, 卡密代码: {$card['card_code']}, 绑定IP: {$card['first_use_ip']}, 尝试IP: {$userIP}");
                        
                        $message = "❌ 该卡密已绑定其他IP地址，无法使用！\n\n" .
                                  "🔒 绑定IP：" . $card['first_use_ip'] . "\n" .
                                  "🌐 当前IP：" . $userIP . "\n\n" .
                                  "💡 提示：每个卡密只能绑定一个IP地址，无法在其他IP上使用。";
                        $messageType = 'error';
                    } else {
                        // IP匹配，允许使用
                        $ipMatch = true;
                    }
                } elseif (empty($card['first_use_ip'])) {
                    // 未绑定IP的情况（包括首次使用和IP换绑后）
                    // 记录IP绑定
                    error_log("IP绑定成功 - 卡密ID: {$card['id']}, 卡密代码: {$card['card_code']}, 绑定IP: {$userIP}");
                    
                    $stmt = $pdo->prepare("UPDATE cards SET 
                                         first_use_ip = :first_use_ip,
                                         last_use_ip = :last_use_ip,
                                         current_uses = current_uses + 1,
                                         used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                                         is_used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                                         used_at = CASE WHEN (current_uses + 1) >= max_uses THEN :used_at ELSE used_at END,
                                         device_info = :device_info,
                                         updated_at = CURRENT_TIMESTAMP 
                                         WHERE id = :id");
                    $stmt->execute([
                        ':first_use_ip' => $userIP,
                        ':last_use_ip' => $userIP,
                        ':used_at' => date('Y-m-d H:i:s'),
                        ':device_info' => $deviceInfo,
                        ':id' => $card['id']
                    ]);
                    
                    // IP绑定成功，设置标记以便后续处理
                    $firstUseSuccess = true;
                } else {
                    // 其他异常情况
                    error_log("异常情况 - 卡密ID: {$card['id']}, 卡密代码: {$card['card_code']}, 用户IP: {$userIP}");
                    
                    $message = "❌ 卡密状态异常，无法使用！\n\n" .
                              "💡 提示：请联系管理员处理此问题。";
                    $messageType = 'error';
                }
                
                // 只有在IP匹配或首次绑定时才执行更新操作
                if (isset($ipMatch) && $ipMatch) {
                    // IP匹配，更新使用次数
                    $stmt = $pdo->prepare("UPDATE cards SET 
                                         last_use_ip = :last_use_ip,
                                         current_uses = current_uses + 1,
                                         used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                                         is_used = CASE WHEN (current_uses + 1) >= max_uses THEN 1 ELSE 0 END,
                                         used_at = CASE WHEN (current_uses + 1) >= max_uses THEN :used_at ELSE used_at END,
                                         device_info = :device_info,
                                         updated_at = CURRENT_TIMESTAMP 
                                         WHERE id = :id");
                    $stmt->execute([
                        ':last_use_ip' => $userIP,
                        ':used_at' => date('Y-m-d H:i:s'),
                        ':device_info' => $deviceInfo,
                        ':id' => $card['id']
                    ]);
                }
                
                // 只有在IP验证通过或首次使用成功时才执行后续操作
                if ((isset($ipMatch) && $ipMatch) || (isset($firstUseSuccess) && $firstUseSuccess)) {
                    // 重新查询更新后的卡密信息
                    $stmt = $pdo->prepare("
                        SELECT c.*, cat.name as category_name 
                        FROM cards c 
                        LEFT JOIN categories cat ON c.category_id = cat.id 
                        WHERE c.id = :id LIMIT 1
                    ");
                    $stmt->execute([':id' => $card['id']]);
                    $card = $stmt->fetch();
                    
                    $card['is_used'] = $card['current_uses'] >= $card['max_uses'] ? 1 : 0;
                    $card['used_at'] = $card['is_used'] ? $card['used_at'] : null;
                    $card['device_info'] = $deviceInfo;
                    
                    // 发送邮件
                    $emailUtils = new EmailUtils();
                    $config = require 'config.php';
                    $usedAt = date('Y-m-d H:i:s');
                    list($emailSuccess, $emailMsg) = $emailUtils->sendCardUsedNotification(
                        $config['email']['admin_notify_email'],
                        [
                            'card_id' => $card['id'],
                            'card_code' => $card['card_code'],
                            'category_id' => $card['category_id'],
                            'used_at' => $usedAt,
                            'device_info' => $deviceInfo
                        ]
                    );
                    
                    // 发送Bark通知 - 验证成功（包含分类信息，新增图标参数）
                    $barkStatus = "未启用";
                    if ($barkSettings['bark_enabled'] == 1) {
                        list($barkSuccess, $barkMsg) = sendBarkNotification(
                            $barkApiBase,
                            '卡密验证成功',
                            "卡密: $cardCode | 商品类型: $categoryName | 使用时间: $usedAt | " . substr($deviceInfo, 0, 50),
                            $barkSettings['bark_icon'] // 传递图标参数
                        );
                        $barkStatus = ($barkSuccess ? "通知成功" : "通知失败：$barkMsg");
                    }
                    
                    // 根据使用情况显示不同的成功消息
                    if ($card['is_used']) {
                        $message = "卡密验证成功！该卡密已完全使用完毕。<br>";
                    } else {
                        $message = "卡密验证成功！剩余使用次数：" . ($card['max_uses'] - $card['current_uses']) . "/{$card['max_uses']}<br>";
                    }
                    
                    if ($card['valid_until']) {
                        $message .= "有效期至：" . date('Y-m-d H:i:s', strtotime($card['valid_until'])) . "<br>";
                    }
                    
                    // 移除邮件状态和Bark状态的显示，但保留通知功能
                    $messageType = 'success';
                }
            }
        }
    } catch (Exception $e) {
        $message = "验证失败：" . $e->getMessage();
        $messageType = 'error';
        error_log("验证错误：" . $e->getMessage());
        
        // 发送Bark通知 - 系统错误（包含分类信息，新增图标参数）
        if (!empty($barkSettings) && $barkSettings['bark_enabled'] == 1) {
            $barkApiBase = rtrim($barkSettings['bark_server'], '/') . '/' . $barkSettings['bark_device_key'];
            list($barkSuccess, $barkMsg) = sendBarkNotification(
                $barkApiBase,
                '卡密验证系统错误',
                "错误: " . $e->getMessage() . " | 卡密: $cardCode | 分类: $categoryName",
                $barkSettings['bark_icon'] // 传递图标参数
            );
            // 移除Bark状态显示，但保留通知功能
        } else {
            // 移除Bark状态显示，但保留通知功能
        }
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = "请输入卡密";
    $messageType = 'error';
}
?>
<!-- HTML部分保持不变 -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($websiteSettings['verify_page_title']); ?> - <?php echo htmlspecialchars($websiteSettings['site_title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center justify-center p-4">
    <main class="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
        <!-- 页面内容保持不变 -->
        <div class="text-center mb-6">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-500 mb-4">
                <?php if (!empty($websiteSettings['site_logo_url'])): ?>
                    <img src="<?php echo htmlspecialchars($websiteSettings['site_logo_url']); ?>" 
                         alt="LOGO" class="w-12 h-12 rounded-full object-cover">
                <?php else: ?>
                    <i class="fa fa-key text-3xl"></i>
                <?php endif; ?>
            </div>
            <h2 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($websiteSettings['verify_page_title']); ?></h2>
            <p class="text-gray-600 mt-1"><?php echo htmlspecialchars($websiteSettings['verify_page_subtitle']); ?></p>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-md <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                <i class="fa <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($messageType === 'success' && $card && !empty($card['content'])): ?>
            <!-- 卡密分类信息 -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <div class="flex items-center justify-center">
                    <i class="fa fa-tag mr-2 text-blue-600"></i>
                    <span class="text-blue-800 font-medium">卡密分类：</span>
                    <span class="ml-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                        <?php echo htmlspecialchars($card['category_name'] ?? '未分类'); ?>
                    </span>
                </div>
            </div>
            
            <div class="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6">
                <h3 class="text-lg font-medium text-gray-800 mb-3 flex items-center">
                    <i class="fa fa-gift mr-2 text-green-600"></i>卡密内容
                </h3>
                
                <?php
                // 提取内容中的URL
                $urlPattern = '/(https?:\/\/[^\s]+)/';
                $content = $card['content'];
                preg_match_all($urlPattern, $content, $matches);
                $urls = $matches[0];
                
                // 处理纯文本内容（移除URL）
                $plainText = preg_replace($urlPattern, '', $content);
                $plainText = htmlspecialchars($plainText, ENT_QUOTES);
                $plainText = nl2br($plainText);
                ?>
                
                <!-- 显示纯文本内容 -->
                <div class="text-gray-700 whitespace-pre-line mb-4 p-4 bg-white rounded-lg border border-gray-200">
                    <?php echo $plainText; ?>
                </div>
                
                <!-- 如有链接则显示跳转按钮 -->
                <?php if (!empty($urls)): ?>
                    <div class="flex flex-col gap-3 mt-4">
                        <?php foreach ($urls as $index => $url): ?>
                            <button 
                                type="button" 
                                onclick="window.open('<?php echo htmlspecialchars($url, ENT_QUOTES); ?>', '_blank', 'noopener noreferrer')"
                                class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 flex items-center justify-center"
                            >
                                <i class="fa fa-external-link mr-2"></i>点击跳转链接 <?php echo $index + 1; ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <div class="text-xs text-gray-500 pt-3 border-t border-gray-200 mt-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <p><i class="fa fa-clock mr-1"></i>使用时间: <?php 
                            // 修复时间显示问题
                            if (!empty($card['used_at']) && $card['used_at'] !== '0000-00-00 00:00:00') {
                                echo date('Y-m-d H:i:s', strtotime($card['used_at']));
                            } else {
                                echo date('Y-m-d H:i:s'); // 使用当前时间
                            }
                        ?></p>
                        <p><i class="fa fa-map-marker mr-1"></i>IP地址: <?php echo htmlspecialchars($card['first_use_ip']); ?></p>
                    </div>
                    <!-- 移除设备信息显示 -->
                </div>
            </div>
        <?php endif; ?>
        
        <form class="space-y-4">
            <div>
                <button type="button" 
                        onclick="if(confirm('请确保卡密内容已复制，确定要返回首页吗？')) window.location.href='index.php'"
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300 flex items-center justify-center">
                    <i class="fa fa-arrow-left mr-2"></i>返回首页
                </button>
                <div class="mt-6 text-center text-gray-600">
                      <div class="flex justify-between items-start">
                    <div>
                        <h3 class="font-semibold text-blue-800 flex items-center">
                            <i class="fa fa-bullhorn mr-2"></i><?php echo htmlspecialchars($websiteSettings['warm_reminder_title']); ?>
                        </h3>
                        <p class="mt-1 text-blue-700 text-sm">
                            <?php echo htmlspecialchars($websiteSettings['warm_reminder_content']); ?>
                        </p>
                        <p class="mt-2 text-xs text-blue-600">
                            发布时间：<?php echo htmlspecialchars($websiteSettings['warm_reminder_date']); ?>
                        </p>
                    </div>
            </div>
        </form>
    </main>
 
    <footer class="mt-6 text-center text-sm text-gray-500">
        <p><?php echo htmlspecialchars($websiteSettings['footer_text']); ?></p>
    </footer>
    
    <!-- 页面特定JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 自动复制卡密内容到剪贴板（如果验证成功且有内容）
            <?php if ($messageType === 'success' && $card && !empty($card['content'])): ?>
                const cardContent = `<?php echo addslashes($card['content']); ?>`;
                
                // 尝试复制到剪贴板
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(cardContent).then(() => {
                        showNotification('卡密内容已自动复制到剪贴板', 'success');
                    }).catch(() => {
                        // 复制失败，显示手动复制提示
                        showNotification('请手动复制卡密内容', 'info');
                    });
                } else {
                    // 降级处理
                    showNotification('请手动复制卡密内容', 'info');
                }
            <?php endif; ?>
            
            // 显示通知函数
            function showNotification(message, type = 'info') {
                const notification = document.createElement('div');
                notification.className = `fixed top-4 right-4 z-50 p-4 rounded-md shadow-lg transition-all duration-300 transform translate-x-full`;
                
                const typeClasses = {
                    success: 'bg-green-500 text-white',
                    error: 'bg-red-500 text-white',
                    warning: 'bg-yellow-500 text-white',
                    info: 'bg-blue-500 text-white'
                };
                
                notification.className += ` ${typeClasses[type] || typeClasses.info}`;
                notification.innerHTML = `<i class="fa fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'} mr-2"></i>${message}`;
                
                document.body.appendChild(notification);
                
                // 显示动画
                setTimeout(() => {
                    notification.classList.remove('translate-x-full');
                }, 100);
                
                // 自动隐藏
                setTimeout(() => {
                    notification.classList.add('translate-x-full');
                    setTimeout(() => {
                        notification.remove();
                    }, 300);
                }, 3000);
            }
            
            // 为所有链接按钮添加点击效果
            document.querySelectorAll('button[onclick*="window.open"]').forEach(button => {
                button.addEventListener('click', function() {
                    this.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>正在跳转...';
                    this.disabled = true;
                });
            });
        });
    </script>
</body>
</html>
<?php
unset($message, $messageType, $card, $db, $pdo, $stmt, $emailUtils);
?>