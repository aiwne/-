# 卡密验证系统 API 文档

## 📋 概述

卡密验证系统提供了一套完整的RESTful API接口，支持卡密验证、查询和统计功能。所有API都返回JSON格式的响应数据。

## 🔗 基础信息

- **基础URL**: `http://your-domain.com/api/`
- **响应格式**: JSON
- **字符编码**: UTF-8
- **跨域支持**: 已启用CORS

## 📚 API接口列表

### 1. 卡密验证接口

**接口地址**: `POST /api/card_verify.php`

**功能描述**: 验证卡密并更新使用状态

**请求参数**:
```json
{
  "card_code": "卡密代码",
  "client_info": {
    "user_agent": "浏览器信息（可选）",
    "ip": "客户端IP（可选）",
    "language": "语言设置（可选）"
  }
}
```

**响应示例**:
```json
{
  "success": true,
  "code": 200,
  "message": "卡密验证成功",
  "data": {
    "card_id": 123,
    "card_code": "ABC123",
    "content": "卡密内容",
    "category_name": "VIP会员",
    "status": "success",
    "remaining_uses": 2,
    "current_uses": 1,
    "max_uses": 3,
    "valid_until": "2024-12-31 23:59:59",
    "first_use_ip": "192.168.1.1",
    "last_use_ip": "192.168.1.1",
    "device_info": "设备信息",
    "used_at": "2024-01-01 12:00:00",
    "is_completely_used": false,
    "notifications": {
      "email": "发送成功",
      "bark": "通知成功"
    }
  },
  "timestamp": "2024-01-01 12:00:00"
}
```

**错误响应**:
```json
{
  "success": false,
  "code": 404,
  "message": "无效的卡密",
  "data": {
    "status": "invalid",
    "card_code": "INVALID123"
  },
  "timestamp": "2024-01-01 12:00:00"
}
```

### 2. 卡密查询接口

**接口地址**: `GET /api/card_query.php`

**功能描述**: 查询卡密信息（不更新使用状态）

**请求参数**:
- `card_code` (必需): 卡密代码

**请求示例**:
```
GET /api/card_query.php?card_code=ABC123
```

**响应示例**:
```json
{
  "success": true,
  "code": 200,
  "message": "查询成功",
  "data": {
    "card_id": 123,
    "card_code": "ABC123",
    "content": "卡密内容",
    "category_name": "VIP会员",
    "status": "unused",
    "current_uses": 0,
    "max_uses": 3,
    "valid_until": "2024-12-31 23:59:59",
    "first_use_ip": null,
    "last_use_ip": null,
    "created_at": "2024-01-01 12:00:00",
    "used_at": null,
    "device_info": null,
    "remaining_uses": 3,
    "is_expired": false,
    "is_fully_used": false
  },
  "timestamp": "2024-01-01 12:00:00"
}
```

### 3. 统计信息接口

**接口地址**: `GET /api/card_stats.php`

**功能描述**: 获取卡密使用统计信息

**请求示例**:
```
GET /api/card_stats.php
```

**响应示例**:
```json
{
  "success": true,
  "code": 200,
  "message": "获取统计成功",
  "data": {
    "total_cards": 1000,
    "used_cards": 300,
    "unused_cards": 700,
    "expired_cards": 50,
    "usage_rate": 30.0,
    "today_used": 25,
    "week_used": 150,
    "month_used": 300,
    "categories": [
      {
        "id": 1,
        "name": "VIP会员",
        "total": 500,
        "used": 150,
        "unused": 350
      }
    ],
    "recent_activities": [
      {
        "card_code": "ABC123",
        "category_name": "VIP会员",
        "used_at": "2024-01-01 12:00:00",
        "ip": "192.168.1.1"
      }
    ],
    "daily_stats": [
      {
        "date": "2024-01-01",
        "used_count": 25
      }
    ]
  },
  "timestamp": "2024-01-01 12:00:00"
}
```

## 📊 状态码说明

| 状态码 | 说明 |
|--------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |
| 401 | 权限错误（如IP绑定验证失败） |
| 404 | 资源不存在 |
| 405 | 请求方法不支持 |
| 500 | 服务器内部错误 |

## 🔍 卡密状态说明

| 状态 | 说明 |
|------|------|
| `unused` | 未使用 |
| `using` | 使用中（部分使用） |
| `used` | 已完全使用 |
| `expired` | 已过期 |
| `invalid` | 无效卡密 |
| `invalid_ip` | IP绑定验证失败 |

## 💡 使用示例

### JavaScript示例

```javascript
// 卡密验证
async function verifyCard(cardCode) {
    try {
        const response = await fetch('/api/card_verify.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                card_code: cardCode,
                client_info: {
                    user_agent: navigator.userAgent,
                    ip: '127.0.0.1',
                    language: navigator.language
                }
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log('验证成功:', data.data);
            return data.data;
        } else {
            console.error('验证失败:', data.message);
            return null;
        }
    } catch (error) {
        console.error('网络错误:', error);
        return null;
    }
}

// 卡密查询
async function queryCard(cardCode) {
    try {
        const response = await fetch(`/api/card_query.php?card_code=${encodeURIComponent(cardCode)}`);
        const data = await response.json();
        
        if (data.success) {
            console.log('查询成功:', data.data);
            return data.data;
        } else {
            console.error('查询失败:', data.message);
            return null;
        }
    } catch (error) {
        console.error('网络错误:', error);
        return null;
    }
}

// 获取统计信息
async function getStats() {
    try {
        const response = await fetch('/api/card_stats.php');
        const data = await response.json();
        
        if (data.success) {
            console.log('统计信息:', data.data);
            return data.data;
        } else {
            console.error('获取统计失败:', data.message);
            return null;
        }
    } catch (error) {
        console.error('网络错误:', error);
        return null;
    }
}
```

### PHP示例

```php
<?php
// 卡密验证
function verifyCard($cardCode) {
    $url = 'http://your-domain.com/api/card_verify.php';
    
    $data = [
        'card_code' => $cardCode,
        'client_info' => [
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''
        ]
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/json\r\n",
            'method' => 'POST',
            'content' => json_encode($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    
    return json_decode($result, true);
}

// 使用示例
$result = verifyCard('ABC123');
if ($result && $result['success']) {
    echo "验证成功: " . $result['data']['content'];
} else {
    echo "验证失败: " . ($result['message'] ?? '未知错误');
}
?>
```

### cURL示例

```bash
# 卡密验证
curl -X POST http://your-domain.com/api/card_verify.php \
  -H "Content-Type: application/json" \
  -d '{
    "card_code": "ABC123",
    "client_info": {
      "user_agent": "Mozilla/5.0",
      "ip": "127.0.0.1",
      "language": "zh-CN"
    }
  }'

# 卡密查询
curl "http://your-domain.com/api/card_query.php?card_code=ABC123"

# 获取统计信息
curl "http://your-domain.com/api/card_stats.php"
```

## 🔒 安全特性

1. **IP绑定**: 卡密首次使用时会绑定IP地址，防止恶意分享
2. **使用次数限制**: 支持设置卡密最大使用次数
3. **有效期控制**: 支持设置卡密有效期
4. **SQL注入防护**: 使用PDO预处理语句
5. **XSS防护**: 输出数据经过HTML转义
6. **CORS支持**: 支持跨域请求

## 📈 性能优化

1. **数据库索引**: 关键字段已建立索引
2. **连接池**: 使用单例模式管理数据库连接
3. **缓存机制**: 可考虑添加Redis缓存
4. **响应压缩**: 建议启用Gzip压缩

## 🛠️ 故障排除

### 常见问题

1. **404错误**: 检查API文件路径是否正确
2. **500错误**: 检查数据库连接和PHP错误日志
3. **CORS错误**: 确认服务器支持跨域请求
4. **JSON解析错误**: 检查请求数据格式是否正确

### 调试建议

1. 查看浏览器开发者工具的Network标签
2. 检查服务器错误日志
3. 使用API测试工具（如Postman）进行测试
4. 在仪表盘中使用内置的API测试功能

## 📞 技术支持

如有问题，请检查：
1. 系统日志文件
2. 数据库连接状态
3. PHP版本兼容性（建议PHP 7.0+）
4. 服务器配置

---

**版本**: 1.0.0  
**更新时间**: 2024-01-01  
**维护者**: 卡密验证系统开发团队
