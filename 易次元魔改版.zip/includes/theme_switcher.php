<?php
if (!defined('KK_THEME')) define('KK_THEME', true);

$__themes = ['default'=>'默认','jk'=>'🎀 JK少女','neu'=>'⬜ 新拟态'];
$__ct = 'default';

if (isset($_GET['theme']) && isset($__themes[$_GET['theme']])) {
    $__ct = $_GET['theme'];
    setcookie('acg_theme', $__ct, time() + 2592000, '/');
} elseif (isset($_COOKIE['acg_theme']) && isset($__themes[$_COOKIE['acg_theme']])) {
    $__ct = $_COOKIE['acg_theme'];
}

$__tm = ['jk'=>'/assets/user/css/index_jk.css','neu'=>'/assets/user/css/index_neu.css'];
$__css = $__tm[$__ct] ?? null;

if (php_sapi_name() === 'cli') return;

ob_start(function (string $buf) use ($__css, $__ct, $__themes) {
    if (stripos($buf, '</head>') === false) return $buf;

    if ($__css !== null) {
        $buf = preg_replace('#(/assets/user/css/index\.css)(["\'\?])#i', $__css . '$2', $buf);
        if (strpos($buf, $__css) === false)
            $buf = str_ireplace('</head>', '<link rel="stylesheet" href="'.$__css.'">' . "\n</head>", $buf);
    }

    $items = '';
    foreach ($__themes as $k => $label) {
        $active = ($k === $__ct) ? 'font-weight:700;color:var(--acg-primary,#7a8cff)' : 'color:#666';
        $check = ($k === $__ct) ? ' ✓' : '';
        $items .= '<a href="?theme='.$k.'" style="display:block;padding:6px 16px;text-decoration:none;font-size:14px;white-space:nowrap;transition:background .15s;'.$active.'" onmouseover="this.style.background=\'rgba(0,0,0,0.04)\'" onmouseout="this.style.background=\'transparent\'">'.$label.$check.'</a>';
    }

    $picker = '<div class="nav-item dropdown" style="position:relative;display:inline-block;margin-left:6px">
<a href="javascript:void(0)" class="nav-link" style="font-size:1.2rem;cursor:pointer;padding:6px 10px" onclick="var d=this.nextElementSibling;d.style.display=d.style.display===\'block\'?\'none\':\'block\'" title="切换主题">🎨</a>
<div style="display:none;position:absolute;right:0;top:100%;background:#fff;border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.12);min-width:140px;padding:6px 0;z-index:999999;backdrop-filter:blur(10px)">
<div style="padding:4px 16px 6px;font-size:11px;color:#aaa;border-bottom:1px solid #f0f0f0;margin-bottom:4px">前端主题</div>
'.$items.'
</div></div>';

    $buf = preg_replace('#(</nav>)#i', $picker . '$1', $buf, 1);

    $buf = str_ireplace('</body>', '<script>document.addEventListener("click",function(e){document.querySelectorAll(".nav-item.dropdown>div").forEach(function(d){if(!d.parentElement.contains(e.target))d.style.display="none"})});</script></body>', $buf);

    return $buf;
});
