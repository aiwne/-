!function () {
    let globalCategoryId, globalCategoryName, _ItemTable, _CateTable;

    function _OpenBusinessGroup() {
        let groupId;

        $(`.business-group`).click(function () {
            groupId = $(this).data("id");
            $('.business-group').removeClass('checked');
            $(this).addClass('checked');
        });

        $(`.payButton`).click(() => {
            if (!groupId) {
                layer.msg("请先选择要开通的套餐");
                return;
            }

            util.post("/user/api/business/purchase", {
                levelId: groupId
            }, res => {
                layer.msg("开通成功");
                window.location.href = "/user/business/index";
            });
        });


        // ============ 修改：保存成功后告知用户店铺地址 ============
        $('.save-config').click(() => {
            // ★★★ 保存前验证：避免出现"http://cs."这种没有后缀的破地址 ★★★
            const $subdomainInput = $('#subdomainInput');
            if ($subdomainInput.length > 0 && !$subdomainInput.is(':disabled')) {
                const prefix = ($subdomainInput.val() || '').trim();
                const $suffixSelect = $('#suffixSelect');
                const suffix = ($suffixSelect.val() || '').trim();
                const hasAnyOption = $suffixSelect.find('option').length > 0;

                if (prefix && !hasAnyOption) {
                    Swal.fire({
                        title: '主站未配置域名',
                        html: '<div style="text-align:left;line-height:1.7;font-size:13px;">'
                            + '管理员还没在「主站域名配置」里添加任何域名，无法绑定子域名。<br><br>'
                            + '<b>解决方法：</b><br>'
                            + '1. 登录网站后台<br>'
                            + '2. 进入「系统设置 → 其他设置」<br>'
                            + '3. 在「主站域名配置」里填上您的域名（例如 <b style="color:#50cd89;">yoursite.com</b>）<br>'
                            + '4. 保存后回到这里刷新页面'
                            + '</div>',
                        icon: 'warning',
                        confirmButtonText: '我知道了',
                        confirmButtonColor: '#ff97c4'
                    });
                    return;
                }
                if (prefix && !suffix) {
                    message.error("请先选择一个有效的域名后缀，否则店铺地址会不可访问");
                    return;
                }
                // 防止用户输入非法字符
                if (prefix && !/^[a-zA-Z0-9][a-zA-Z0-9\-]*$/.test(prefix)) {
                    message.error("子域名前缀只能包含字母、数字和短横线，且必须以字母或数字开头");
                    return;
                }
            }

            // 获取保存前的子域名状态，用于判断是否是首次绑定
            const wasSubdomainBound = !!getVar('_bound_subdomain_full');

            util.post("/user/api/business/saveConfig", util.arrayToObject($('.form-data').serializeArray()), res => {
                // 保存成功后显示店铺地址
                _ShowSaveSuccessWithUrl(wasSubdomainBound);
            });
        });
        // ============ 修改结束 ============


        $('.category-show').click(function () {
            let status = $(this).data("state");
            util.post("/user/api/master/setCategoryAllStatus", {status: status}, res => {
                message.success("已生效");
                _CateTable.refresh();
            });
        });

        $('.commodity-show').click(function () {
            let status = $(this).data("state");
            util.post("/user/api/master/setCommodityAllStatus", {
                status: status,
                category_id: globalCategoryId
            }, res => {
                message.success("已生效");
                _ItemTable.refresh();
            });
        });


        $('.commodity-premium').click(function () {
            component.popup({
                submit: '/user/api/master/setCommodityAllPremium',
                tab: [
                    {
                        name: `<i class="fa-duotone fa-regular fa-hand-holding-dollar"></i> ${globalCategoryName ? `仅分类：<span class="text-success">${globalCategoryName}</span> 下的商品生效` : "全部商品"}`,
                        form: [
                            {title: "cid", name: "category_id", type: "input", hide: true},
                            {
                                title: "加价百分比",
                                name: "premium",
                                type: "input",
                                placeholder: "商品加价",
                                tips: "比如一个商品市场价 100 元，如果你填写了 50，售价就是：\n" +
                                    "100 + (100 × 0.5) = 150 元。\n" +
                                    "如果你的进货价是 70 元，那么最终利润就是：150 - 70 = 80 元。".replace("\n", "<br>")
                            }
                        ]
                    }
                ],
                assign: {category_id: globalCategoryId},
                autoPosition: true,
                height: "auto",
                width: "480px",
                done: () => {
                    _ItemTable.refresh();
                }
            });
        });


        $('.unbind-subdomain').click(function () {
            message.ask("您正在解绑子域名，解绑后，用户将无法再通过旧子域名访问您的店铺。", () => {
                util.post("/user/api/business/unbind", {type: 0}, res => {
                    message.success("解绑成功");
                    setTimeout(() => {
                        window.location.reload()
                    }, 500);
                })
            });
        });

        $('.unbind-topdomain').click(function () {
            message.ask("您正在解绑独立域名，解绑后，用户将无法再通过独立域名访问您的店铺。", () => {
                util.post("/user/api/business/unbind", {type: 1}, res => {
                    message.success("解绑成功");
                    setTimeout(() => {
                        window.location.reload()
                    }, 500);
                })
            });
        });

    }

    // ============ 新增功能 ============

    /**
     * 保存成功后弹窗展示店铺地址
     * 不管什么情况，弹窗关闭后都刷新一次页面 —— 这样顶部地址卡片永远是最新状态
     */
    function _ShowSaveSuccessWithUrl(wasSubdomainBound) {
        const protocol = getVar('_site_protocol') || 'http';

        // 重新读取最新的子域名
        let subdomainPrefix = ($('#subdomainInput').val() || '').trim();
        let suffix = $('#suffixSelect').val() || '';
        const boundFull = getVar('_bound_subdomain_full');

        // 优先使用已绑定的，否则用表单当前的值（首次绑定后）
        let fullSubdomain = boundFull || (subdomainPrefix && suffix ? `${subdomainPrefix}.${suffix}` : '');
        let topdomain = ($('input[name="topdomain"]').val() || '').trim();

        // 决定保存后是否需要刷新页面 (新绑定/解绑/换域名 时需要刷新使顶部卡片同步)
        const needReload = !wasSubdomainBound && (fullSubdomain || topdomain);

        // 如果完全没有任何域名信息，就只弹普通成功提示
        if (!fullSubdomain && !topdomain) {
            message.success("保存成功");
            return;
        }

        let html = `<div style="text-align:left;font-size:14px;line-height:1.8;">`;
        html += `<div style="color:#666;margin-bottom:10px;">您的设置已保存，店铺现在可以通过以下地址访问：</div>`;

        if (fullSubdomain) {
            const url = `${protocol}://${fullSubdomain}`;
            html += `<div style="background:#fff5fb;border:1px dashed #ffb8d4;border-radius:8px;padding:10px 12px;margin-bottom:8px;">`;
            html += `<div style="font-size:12px;color:#a78fc8;margin-bottom:4px;">📌 系统子域名地址</div>`;
            html += `<div style="color:#ff6b9d;font-weight:bold;word-break:break-all;">${url}</div>`;
            html += `</div>`;
        }

        if (topdomain) {
            const url = `${protocol}://${topdomain}`;
            html += `<div style="background:#f4f9ff;border:1px dashed #a8d4ff;border-radius:8px;padding:10px 12px;margin-bottom:8px;">`;
            html += `<div style="font-size:12px;color:#7a9bc7;margin-bottom:4px;">🌐 独立域名地址</div>`;
            html += `<div style="color:#5b8def;font-weight:bold;word-break:break-all;">${url}</div>`;
            html += `<div style="font-size:11px;color:#999;margin-top:4px;">（请确保已正确做 CNAME 解析）</div>`;
            html += `</div>`;
        }

        html += `<div style="font-size:12px;color:#999;margin-top:10px;">💡 您可以把上面的链接分享给客户</div>`;
        html += `</div>`;

        Swal.fire({
            title: '保存成功',
            html: html,
            icon: 'success',
            showCancelButton: !!fullSubdomain,
            cancelButtonText: '复制链接',
            confirmButtonText: fullSubdomain ? '访问店铺' : '我知道了',
            cancelButtonColor: '#b58aef',
            confirmButtonColor: '#ff97c4',
            reverseButtons: true,
        }).then((result) => {
            // 处理用户操作
            if (result.isConfirmed && fullSubdomain) {
                window.open(`${protocol}://${fullSubdomain}`, '_blank');
            } else if (result.dismiss === Swal.DismissReason.cancel && fullSubdomain) {
                _CopyToClipboard(`${protocol}://${fullSubdomain}`);
                message.success("链接已复制");
            }

            // ★关键：弹窗关闭后再刷新，保证顶部卡片同步显示新地址
            if (needReload) {
                window.location.reload();
            }
        });
    }

    /**
     * 复制文本到剪贴板（兼容老浏览器）
     */
    function _CopyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).catch(() => _FallbackCopy(text));
        } else {
            _FallbackCopy(text);
        }
    }

    function _FallbackCopy(text) {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        document.body.removeChild(ta);
    }

    /**
     * 子域名实时预览 + 复制按钮
     */
    function _BindUrlPreview() {
        const protocol = getVar('_site_protocol') || 'http';

        // 顶部"复制"按钮
        $(document).on('click', '#copyShopUrlBtn', function () {
            const url = $('#shopUrlBox').text().trim();
            if (url) {
                _CopyToClipboard(url);
                message.success("店铺地址已复制");
            }
        });

        $(document).on('click', '#copyShopTopUrlBtn', function () {
            const url = $('#shopTopUrlBox').text().trim();
            if (url) {
                _CopyToClipboard(url);
                message.success("独立域名地址已复制");
            }
        });

        // 子域名输入实时预览
        const $input = $('#subdomainInput');
        const $select = $('#suffixSelect');
        const $preview = $('#subdomainPreview');
        const $previewUrl = $('#subdomainPreviewUrl');

        if ($input.length === 0) return;

        const updatePreview = function () {
            // 已绑定时不刷新预览（保持后端给的真实地址）
            if ($input.is(':disabled')) return;

            const prefix = ($input.val() || '').trim().replace(/\s/g, '').replace(/^\.+|\.+$/g, '');
            const suffix = $select.val() || '';

            if (prefix && suffix) {
                $previewUrl.text(`${protocol}://${prefix}.${suffix}`);
                $preview.slideDown(120);
            } else {
                $preview.slideUp(120);
            }
        };

        $input.on('input keyup change', updatePreview);
        $select.on('change', updatePreview);

        // 初次也跑一次（防止页面回填了内容）
        updatePreview();
    }

    // ============ 新增功能结束 ============


    function _NoticeEditor() {
        ['basePath', 'workerPath', 'modePath', 'themePath'].forEach(name => {
            ace.config.set(name, '/assets/common/js/editor/code/lib');
        });

        const wangEditor = window.wangEditor, uploadUrl = '/user/api/upload/send';
        const editor = new wangEditor(`.editor-container`);
        const textarea = $(`.text-container`);
        const editorContent = $('.editor-content');
        const editorWrapper = $('.editor-wrapper');
        const htmlContainer = $('.html-container');
        const business_notice_var = getVar(`_business_notice_var`);

        editor.config.onchange = function (html) {
            textarea.val(html);
        }

        editor.config.zIndex = 0;
        editor.config.uploadFileName = 'file';
        editor.config.uploadImgServer = uploadUrl + "?mime=image";
        editor.config.uploadImgAccept = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
        editor.config.uploadImgMaxLength = 1;
        editor.config.uploadImgTimeout = 60 * 1000;
        editor.config.uploadImgMaxSize = 50 * 1024 * 1024;  //50M
        editor.config.uploadImgHooks = {
            customInsert: function (insertImgFn, result) {
                if (result.code != 200) {
                    layer.msg(result.msg);
                    return;
                }
                insertImgFn(result.data.url);
            },
            error: function (xhr, editor, resData) {
                layer.msg("图片上传失败，文件可能过大");
            },
        }
        editor.config.uploadVideoServer = uploadUrl + "?mime=video";
        editor.config.uploadVideoName = 'file'
        editor.config.uploadVideoHooks = {
            customInsert: function (insertVideoFn, result) {
                if (result.code != 200) {
                    layer.msg(result.msg);
                    return;
                }
                insertVideoFn(result.data.url);
            },
            error: function (xhr, editor, resData) {
                layer.msg("视频上传失败，文件可能过大");
            },
        }
        editor.config.height = 240;
        editor.create();

        editor.txt.html(business_notice_var);
        textarea.val(business_notice_var);


        $('.button-switch-notice').click(function () {
            let _obj = $(this);
            let type = _obj.attr("data-type");
            if (type == 0) {
                const toolbarWidth = $(`.editor-container .w-e-toolbar`).width();
                const heightDifference = toolbarWidth > 1000 ? 40 : 80;

                _obj.attr("data-type", 1);
                _obj.html('<i class="fa-duotone fa-regular fa-pen-paintbrush me-1"></i>' + i18n("写作"));
                editorWrapper.append(`<div id="notice-tmp-html" style="margin-top:10px;width:100%;height: ${480 + heightDifference}px"></div>`);
                const editor = ace.edit(`notice-tmp-html`, {
                    theme: "ace/theme/chrome",
                    mode: "ace/mode/html"
                });
                editor.getSession().setUseWrapMode(true);
                editor.setOption("showPrintMargin", false);
                editor.setValue(textarea.val());
                editor.getSession().on('change', function (delta) {
                    const currentContent = editor.getValue();
                    textarea.val(currentContent);
                });
                editorContent.hide();
                htmlContainer.fadeIn(150);
            } else {
                _obj.attr("data-type", 0);
                _obj.html('<i class="fa-duotone fa-regular fa-code me-1"></i>HTML');
                editor.txt.html(textarea.val());
                $(`#notice-tmp-html`).remove();
                editorContent.fadeIn(150);
            }
        });
    }


    function _CategoryDef() {
        _CateTable = new Table("/user/api/master/category", "#master_category");
        _CateTable.setTree(1);
        _CateTable.setColumns([
            {field: 'icon', title: '#', type: "image"},
            {field: 'name', title: '主站分类名称'},
            {
                field: 'status',
                title: '状态',
                type: "button",
                buttons: [
                    {
                        icon: 'fa-duotone fa-regular fa-eye',
                        title: "显示",
                        show: item => !item.user_category || item.user_category.status == 1,
                        class: "text-success",
                        click: (event, value, row, index) => {
                            let values = row.user_category;

                            if (!values) {
                                values = {id: 0, category_id: row.id};
                            }

                            util.post("/user/api/master/setCategoryStatus", values, res => {
                                message.success("已生效");
                                _CateTable.refresh();
                            });
                        }
                    },
                    {
                        icon: 'fa-duotone fa-regular fa-eye-slash',
                        title: "隐藏",
                        show: item => item?.user_category && item?.user_category?.status == 0,
                        class: "text-danger",
                        click: (event, value, row, index) => {
                            let values = row.user_category;

                            if (!values) {
                                values = {id: 0, category_id: row.id};
                            }

                            util.post("/user/api/master/setCategoryStatus", values, res => {
                                message.success("已生效");
                                _CateTable.refresh();
                            });
                        }
                    },
                ]
            }
            , {
                field: 'user_name', title: '自定义名称', formatter: function (val, item) {
                    if (!item.user_category || !item.user_category.name) {
                        return '-';
                    }
                    return item?.user_category?.name;
                }
            },
            {
                field: 'operation',
                title: '',
                type: "button",
                buttons: [
                    {
                        icon: 'fa-duotone fa-regular fa-eye',
                        title: "查看商品",
                        class: "text-success",
                        click: (event, value, row, index) => {
                            globalCategoryId = row.id;
                            globalCategoryName = row.name;

                            _ItemTable.reload({
                                silent: false,
                                pageNumber: 1,
                                query: {category_id: row.id}
                            });
                        }
                    },
                    {
                        icon: 'fa-duotone fa-regular fa-gear',
                        title: "设置",
                        class: "text-primary",
                        click: (event, value, row, index) => {
                            let values = row.user_category;

                            if (!values) {
                                values = {category_id: row.id};
                            }

                            component.popup({
                                submit: '/user/api/master/setCategory',
                                tab: [
                                    {
                                        name: `${util.icon("fa-duotone fa-regular fa-gear")} ${row.name}`,
                                        form: [
                                            {title: "cid", name: "category_id", type: "input", hide: true},
                                            {
                                                title: "自定义名称",
                                                name: "name",
                                                type: "textarea",
                                                height: 48,
                                                placeholder: "自定义分类名称，不填写代表使用主站的，支持各种HTML美化代码"
                                            },
                                            {title: "状态", name: "status", type: "switch", text: "显示|隐藏"}
                                        ]
                                    }
                                ],
                                assign: values,
                                autoPosition: true,
                                height: "auto",
                                width: "480px",
                                done: () => {
                                    _CateTable.refresh();
                                }
                            });
                        }
                    },

                ]
            }
        ]);
        _CateTable.render();
    }


    function _ItemDef() {
        _ItemTable = new Table("/user/api/master/commodity", "#master_commodity");
        _ItemTable.setColumns([
            {field: 'cover', title: '#', type: "image"},
            {field: 'name', title: '商品名称'}
            , {field: 'user_price', title: '会员价', class: "normal"}
            , {field: 'price', title: '游客价', class: "normal"}
            , {
                field: 'status',
                title: '状态',
                class: "normal",
                type: "button",
                buttons: [
                    {
                        icon: 'fa-duotone fa-regular fa-eye',
                        title: "显示",
                        show: item => !item.user_commodity || item.user_commodity.status == 1,
                        class: "text-success",
                        click: (event, value, row, index) => {
                            let values = row.user_commodity;

                            if (!values) {
                                values = {id: 0, commodity_id: row.id};
                            }

                            util.post("/user/api/master/setCommodityStatus", values, res => {
                                message.success("已生效");
                                _ItemTable.refresh();
                            });
                        }
                    },
                    {
                        icon: 'fa-duotone fa-regular fa-eye-slash',
                        title: "隐藏",
                        show: item => item?.user_commodity && item?.user_commodity?.status == 0,
                        class: "text-danger",
                        click: (event, value, row, index) => {
                            let values = row.user_commodity;

                            if (!values) {
                                values = {id: 0, commodity_id: row.id};
                            }

                            util.post("/user/api/master/setCommodityStatus", values, res => {
                                message.success("已生效");
                                _ItemTable.refresh();
                            });
                        }
                    },
                ]
            }
            , {
                field: 'user_name', title: '自定义名称', formatter: function (val, item) {
                    if (!item.user_commodity || !item.user_commodity.name) {
                        return '-';
                    }
                    return item?.user_commodity?.name;
                }
            }
            , {
                field: 'premium', title: '加价百分比', class: "normal", formatter: function (val, item) {
                    if (!item.user_commodity || item.user_commodity.premium == 0) {
                        return '-';
                    }
                    return format.badge(`${item.user_commodity.premium}%`, "a-badge-success");
                }
            },
            {
                field: 'operation',
                title: '',
                type: "button",
                buttons: [
                    {
                        icon: 'fa-duotone fa-regular fa-gear',
                        title: "设置",
                        class: "text-primary",
                        click: (event, value, row, index) => {
                            let values = row?.user_commodity;

                            if (!values) {
                                values = {commodity_id: row.id};
                            }

                            component.popup({
                                submit: '/user/api/master/setCommodity',
                                tab: [
                                    {
                                        name: `${util.icon("fa-duotone fa-regular fa-gear")} ${row.name}`,
                                        form: [
                                            {title: "cid", name: "commodity_id", type: "input", hide: true},
                                            {
                                                title: "自定义名称",
                                                name: "name",
                                                type: "textarea",
                                                height: 48,
                                                placeholder: "自定义商品名称，不填写代表使用主站的，支持HTML美化代码"
                                            },
                                            {
                                                title: "加价百分比",
                                                name: "premium",
                                                type: "input",
                                                placeholder: "商品加价",
                                                tips: "比如一个商品市场价 100 元，如果你填写了 50，售价就是：\n" +
                                                    "100 + (100 × 0.5) = 150 元。\n" +
                                                    "如果你的进货价是 70 元，那么最终利润就是：150 - 70 = 80 元。".replace("\n", "<br>")
                                            },
                                            {title: "状态", name: "status", type: "switch", text: "显示|隐藏"}
                                        ]
                                    }
                                ],
                                assign: values,
                                autoPosition: true,
                                height: "auto",
                                width: "480px",
                                done: () => {
                                    _ItemTable.refresh();
                                }
                            });
                        }
                    },

                ]
            }
        ]);
        _ItemTable.render();
    }


    _OpenBusinessGroup();
    _NoticeEditor();
    _BindUrlPreview();   // 新增：实时URL预览 + 复制按钮

    _CategoryDef();
    _ItemDef();
}();
