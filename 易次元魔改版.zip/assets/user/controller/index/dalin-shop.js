/**
 * 大林主题 · 商品列表加载逻辑(双列瓷砖版)
 */
!function(){
    var $SwitchCategory = $(".switch-category"),
        $ItemList = $(".item-list"),
        $Count = $("#dlProductCount"),
        categoryId = (typeof getVar === 'function' ? getVar("CAT_ID") : 0);

    function escapeHtml(s){
        return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    function formatPrice(p){
        var n = parseFloat(p);
        if (isNaN(n)) return p;
        return n.toString();
    }

    function _PushCommodityList(data) {
        $ItemList.html("");
        if (!data || data.length === 0) {
            $Count.text("0 件");
            $ItemList.html('<div class="item-message">该分类暂无商品<br><br><span style="font-size:11px;color:#94a3b8;">请确认后台已上架商品并已分配到当前分类</span></div>');
            return;
        }
        $Count.text(data.length + " 件");

        var html = "";
        data.forEach(function(item){
            var isSoldOut = item.stock == 0;
            var lowStock = item.stock > 0 && item.stock < 10;
            var hrefAttr = isSoldOut ? 'href="javascript:void(0);"' : 'href="/item/' + item.id + '"';
            var coverStyle = item.cover ? 'background-image:url(\'' + item.cover + '\');background-size:cover;background-position:center;' : '';

            var cornerHtml = item.recommend == 1
                ? '<div class="dl-p-corner"><span class="dl-p-tag t-recommend">推荐</span></div>'
                : '';

            var deliveryTag = item.delivery_way === 0
                ? '<span class="dl-p-tag t-auto">自动</span>'
                : '<span class="dl-p-tag t-online">在线</span>';

            var stockHtml = isSoldOut
                ? '<span class="dl-p-stock soldout"><i class="dl-stock-dot"></i>已售罄</span>'
                : '<span class="dl-p-stock' + (lowStock ? ' low' : '') + '">库存 ' + item.stock + '</span>';

            // 售罄角标:右上角斜挂缎带 + 灰度遮罩(取代原中央旋转黑色印章)
            var soldoutFlag = isSoldOut
                ? '<div class="dl-soldout-overlay">' +
                      '<div class="dl-soldout-ribbon"><span>SOLD OUT</span></div>' +
                  '</div>'
                : '';

            html += '<a ' + hrefAttr + ' class="dl-product acg-card' + (isSoldOut ? ' soldout' : '') + '" data-id="' + item.id + '">' +
                        '<div class="dl-p-cover" style="' + coverStyle + '">' +
                            cornerHtml +
                            soldoutFlag +
                        '</div>' +
                        '<div class="dl-p-body">' +
                            '<h3 class="dl-p-name">' + escapeHtml(item.name) + '</h3>' +
                            '<div class="dl-p-meta-tags">' +
                                deliveryTag +
                            '</div>' +
                            '<div class="dl-p-bottom">' +
                                '<div class="dl-p-price"><span class="y">¥</span><span class="now">' + formatPrice(item.price) + '</span></div>' +
                                stockHtml +
                                (isSoldOut
                                    ? '<span class="dl-p-buy dl-p-buy-soldout" aria-disabled="true">' +
                                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' +
                                        '已售罄' +
                                      '</span>'
                                    : '<span class="dl-p-buy">' +
                                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>' +
                                        '立即购买' +
                                      '</span>'
                                ) +
                            '</div>' +
                        '</div>' +
                    '</a>';
        });
        $ItemList.html(html);
    }

    function _SwitchCategory(id, link) {
        if (link === undefined) link = false;
        $SwitchCategory.removeClass("is-primary");
        if (id !== undefined && id !== null && id !== ''){
            $('a[data-id="' + id + '"]').addClass("is-primary");
        }
        if (link && id) history.pushState(null, '', '/cat/' + id);
        var opts = { done: _PushCommodityList };
        if (id) opts.categoryId = id;
        trade.getCommodityList(opts);
    }

    function _Search(keywords) {
        if (keywords == '') {
            if (window.layer) layer.msg("请输入关键词");
            return;
        }
        $SwitchCategory.removeClass("is-primary");
        trade.getCommodityList({
            keywords: keywords,
            done: _PushCommodityList
        });
    }

    var firstId = $SwitchCategory.first().data("id");
    _SwitchCategory((categoryId && categoryId > 0) ? categoryId : firstId);

    $SwitchCategory.click(function () {
        if ($(this).hasClass("is-primary")) return;
        _SwitchCategory($(this).data("id"), true);
    });

    $('.item-search-input').on('keypress', function (e) {
        if (e.which === 13) _Search($(this).val());
    });
}();
