/* ========================================================================
 *  _index.js  ——  合并打包文件 (生产环境加载)
 *  来源:
 *    1) assets/user/js/trade.js
 *    2) assets/user/js/treasure.js   (含 10 秒倒计时下载提示)
 *
 *  DEBUG 模式下 Footer.html 会改为加载源码 trade.js + treasure.js,
 *  生产模式加载本文件。两边逻辑保持等价。
 * ====================================================================== */

/* ----------------------------------------------------------------------
 * 1) trade  ——  首页商品 / 分类数据加载
 * -------------------------------------------------------------------- */
let trade = new class {
    constructor() {}

    // 获取分类
    getCategoryList(done = null) {
        util.get("/user/api/index/data", data => {
            typeof done === "function" && done(data);
        });
    }

    // 获取商品列表
    getCommodityList(opt = {}) {
        let params = {};
        if (opt.keywords) params.keywords = opt.keywords;
        if (opt.limit && opt.page) {
            params.limit = opt.limit;
            params.page  = opt.page;
        }
        if (opt.categoryId) params.categoryId = opt.categoryId;

        util.get(
            "/user/api/index/commodity" + (!util.isEmptyOrNotJson(params) ? "?" + util.objectToQueryString(params) : ""),
            data => { typeof opt.done === "function" && opt.done(data); }
        );
    }
};

/* ----------------------------------------------------------------------
 * 2) treasure  ——  付款成功后弹出的卡密窗口
 *
 *   按钮:
 *     - 默认 1 个: [ 复制卡密 ]
 *     - 后台开启 dl_paydone 自定义下载时 2 个: [ 自定义下载(主) ] [ 复制卡密(副) ]
 *
 *   下载按钮的关键改造:
 *     1) 不再立即 window.open / window.location 导航当前页
 *        (手机浏览器会立刻把当前页变成空白"加载中",倒计时 UI 来不及显示)
 *     2) 用一个 display:none 的隐藏 iframe 把目标 url 设进去发起请求
 *        - 直链文件: 浏览器读 Content-Disposition:attachment 直接触发下载,
 *                    iframe 不导航,当前页保持完整
 *        - 普通网页: iframe 在后台静默加载,当前页保持完整
 *     3) 弹窗内容替换为「正在为您准备下载 + 10 秒倒计时」UI
 *     4) 倒计时结束后弹窗自动恢复成卡密界面 (textarea + 下载/复制按钮),
 *        下载已在浏览器下载管理器里继续运行
 *     5) 用户点「取消等待」-> window.stop() 中断请求 + 移除 iframe + 恢复弹窗
 * -------------------------------------------------------------------- */
let treasure = new class Treasure {
    constructor() {
        this._stylesInjected = false;
        this._currentSecret  = '';
    }

    _injectStyles() {
        if (this._stylesInjected) return;
        if (typeof document === 'undefined') return;
        this._stylesInjected = true;

        // 用 skin: 'treasure-popup' 把样式范围限定在本弹窗内,不影响其他 layer 弹窗
        const css =
            '.layui-layer.treasure-popup{border-radius:14px!important;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.3)!important;}' +
            '.layui-layer.treasure-popup .layui-layer-title{padding:14px 50px 14px 20px!important;font-size:16px!important;font-weight:700!important;color:#0f172a!important;background:linear-gradient(180deg,#f8fafc 0%,#fff 100%)!important;border-bottom:1px solid #e2e8f0!important;height:auto!important;line-height:1.4!important;}' +
            '.layui-layer.treasure-popup .layui-layer-content{padding:14px!important;}' +
            /* 卡密内容容器 (div 替换 textarea, 支持部分文本高亮) */
            '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box{background:#f8fafc!important;color:#0f172a!important;font-size:14px!important;line-height:1.95!important;border:1px solid #cbd5e1!important;border-radius:10px!important;font-family:Menlo,Consolas,"Courier New",monospace!important;padding:14px!important;height:98%!important;width:100%!important;overflow-x:hidden!important;overflow-y:auto!important;box-sizing:border-box!important;user-select:text!important;-webkit-user-select:text!important;cursor:text!important;word-break:break-all;white-space:pre-wrap;}' +
            '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box .dl-line{min-height:1.4em;}' +
            /* 卡密关键字段行 (X: Y 格式) 用荧光笔风格高亮 */
            '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box .dl-line-hi{display:inline-block;background:linear-gradient(135deg,#fef9c3 0%,#fde68a 100%);color:#422006;font-weight:800;letter-spacing:.3px;padding:3px 9px;margin:2px 0;border-radius:6px;box-shadow:0 0 0 2px rgba(234,179,8,.18),0 2px 6px rgba(234,179,8,.18);border:1.5px solid #eab308;animation:dlHiGlow 2.4s ease-in-out infinite;max-width:100%;word-break:break-all;}' +
            '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box .dl-line-hi::selection{background:#fde047!important;color:#422006!important;}' +
            '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box .dl-line-hi::-moz-selection{background:#fde047!important;color:#422006!important;}' +
            '@keyframes dlHiGlow{0%,100%{box-shadow:0 0 0 2px rgba(234,179,8,.18),0 2px 6px rgba(234,179,8,.18);}50%{box-shadow:0 0 0 4px rgba(234,179,8,.30),0 4px 12px rgba(234,179,8,.30);}}' +
            /* 按钮容器 - 用 flex 让两个按钮等宽并排 */
            '.layui-layer.treasure-popup .layui-layer-btn{padding:12px!important;background:#f8fafc!important;border-top:1px solid #e2e8f0!important;display:flex!important;gap:10px!important;text-align:center!important;}' +
            '.layui-layer.treasure-popup .layui-layer-btn a{flex:1!important;min-height:48px!important;height:auto!important;line-height:1!important;padding:14px 14px!important;margin:0!important;border:none!important;border-radius:10px!important;font-size:15px!important;font-weight:700!important;box-shadow:0 2px 8px rgba(0,0,0,.08)!important;transition:transform .15s,box-shadow .15s,filter .15s!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;}' +
            '.layui-layer.treasure-popup .layui-layer-btn a:hover{transform:translateY(-1px)!important;box-shadow:0 6px 18px rgba(0,0,0,.14)!important;filter:brightness(1.05);}' +
            '.layui-layer.treasure-popup .layui-layer-btn a:active{transform:translateY(0)!important;box-shadow:0 2px 4px rgba(0,0,0,.12)!important;}' +
            /* 主按钮 - 青色渐变(自定义下载/或单按钮的复制卡密) */
            '.layui-layer.treasure-popup .layui-layer-btn0{background:linear-gradient(135deg,#06b6d4 0%,#0891b2 100%)!important;color:#fff!important;}' +
            '.layui-layer.treasure-popup .layui-layer-btn0,.layui-layer.treasure-popup .layui-layer-btn0 *{color:#fff!important;}' +
            /* 副按钮 - 白底蓝边(复制卡密作副操作时) */
            '.layui-layer.treasure-popup .layui-layer-btn1{background:#fff!important;color:#0f172a!important;border:1.5px solid #cbd5e1!important;}' +
            '.layui-layer.treasure-popup .layui-layer-btn1,.layui-layer.treasure-popup .layui-layer-btn1 *{color:#0f172a!important;}' +
            /* 平板/手机 - 按钮加大,文字更醒目 */
            '@media (max-width:768px){' +
                '.layui-layer.treasure-popup{border-radius:0!important;}' +
                '.layui-layer.treasure-popup .layui-layer-title{font-size:17px!important;padding:16px 50px 16px 20px!important;}' +
                '.layui-layer.treasure-popup .layui-layer-content{padding:16px!important;}' +
                '.layui-layer.treasure-popup .layui-layer-content .dl-secret-box{font-size:15px!important;}' +
                '.layui-layer.treasure-popup .layui-layer-btn{padding:14px!important;gap:12px!important;}' +
                '.layui-layer.treasure-popup .layui-layer-btn a{min-height:56px!important;padding:18px 14px!important;font-size:16px!important;border-radius:12px!important;}' +
                '.layui-layer.treasure-popup .layui-layer-btn0{box-shadow:0 4px 14px rgba(6,182,212,.4)!important;}' +
            '}' +
            /* ===== 加载等待 UI (无倒计时, 无自动关闭) =====
             * 进度条 shimmer 无限循环, 表达"在做事"但不暗示"快好了"
             * iframe.onload 触发 -> 切到 .is-ready 状态 (圆环填满变绿 + 对勾 + 文案变更),
             *                       但**不自动关闭**, 由用户点"返回卡密"主动结束
             */
            '.dl-prepare-wrap{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px 20px 22px;min-height:280px;background:linear-gradient(180deg,#f0f9ff 0%,#fff 100%);border-radius:10px;}' +
            '.dl-prepare-ring{position:relative;width:120px;height:120px;margin-bottom:18px;}' +
            '.dl-prepare-ring svg.dl-ring-svg{width:100%;height:100%;transform:rotate(-90deg);}' +
            '.dl-prepare-ring .dl-ring-bg{fill:none;stroke:#e2e8f0;stroke-width:8;}' +
            '.dl-prepare-ring .dl-ring-fg{fill:none;stroke:url(#dlGrad);stroke-width:8;stroke-linecap:round;stroke-dasharray:339.292;stroke-dashoffset:339.292;transition:stroke-dashoffset .5s ease-out,stroke .3s ease;}' +
            '.dl-prepare-wrap.is-ready .dl-prepare-ring .dl-ring-fg{stroke-dashoffset:0;stroke:#10b981;}' +
            '.dl-prepare-ring .dl-ring-num{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;}' +
            '.dl-ring-spinner{width:42px;height:42px;animation:dlSpin 1.1s linear infinite;display:flex;align-items:center;justify-content:center;color:#0891b2;}' +
            '.dl-ring-spinner svg{width:100%;height:100%;display:block;}' +
            '.dl-ring-check{width:48px;height:48px;display:none;align-items:center;justify-content:center;color:#10b981;animation:dlCheckPop .35s cubic-bezier(.34,1.56,.64,1);}' +
            '.dl-ring-check svg{width:100%;height:100%;display:block;}' +
            '.dl-prepare-wrap.is-ready .dl-ring-spinner{display:none;}' +
            '.dl-prepare-wrap.is-ready .dl-ring-check{display:flex;}' +
            '@keyframes dlSpin{from{transform:rotate(0)}to{transform:rotate(360deg)}}' +
            '@keyframes dlCheckPop{0%{transform:scale(.3);opacity:0}60%{transform:scale(1.15);opacity:1}100%{transform:scale(1);opacity:1}}' +
            '.dl-prepare-title{font-size:17px;font-weight:700;color:#0f172a;margin-bottom:6px;letter-spacing:.3px;display:flex;align-items:center;gap:8px;}' +
            '.dl-prepare-wrap.is-ready .dl-prepare-title{color:#10b981;}' +
            '.dl-prepare-title .dl-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#06b6d4;animation:dlPulse 1.4s ease-in-out infinite;}' +
            '.dl-prepare-title .dl-dot:nth-child(2){animation-delay:.2s;}' +
            '.dl-prepare-title .dl-dot:nth-child(3){animation-delay:.4s;}' +
            '.dl-prepare-wrap.is-ready .dl-dot{display:none;}' +
            '.dl-prepare-tip{font-size:13px;color:#64748b;margin-bottom:6px;text-align:center;line-height:1.6;padding:0 8px;transition:color .3s ease;}' +
            '.dl-prepare-wrap.is-ready .dl-prepare-tip{color:#059669;font-weight:600;}' +
            '.dl-prepare-subtip{font-size:11px;color:#94a3b8;margin-bottom:10px;text-align:center;line-height:1.5;padding:0 8px;transition:color .3s ease;}' +
            '.dl-prepare-wrap.is-ready .dl-prepare-subtip{color:#10b981;}' +
            /* shimmer 进度条 - 默认无限横滚, ready 时变绿色满进度 */
            '.dl-prepare-bar{width:100%;max-width:300px;height:6px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin-top:6px;position:relative;}' +
            '.dl-prepare-bar-fg{position:absolute;top:0;bottom:0;left:0;right:0;background:linear-gradient(90deg,rgba(6,182,212,0) 0%,#06b6d4 35%,#0891b2 65%,rgba(8,145,178,0) 100%);background-size:200% 100%;animation:dlShimmer 1.4s linear infinite;}' +
            '@keyframes dlShimmer{0%{background-position:100% 0;}100%{background-position:-100% 0;}}' +
            '.dl-prepare-wrap.is-ready .dl-prepare-bar-fg{background:linear-gradient(90deg,#10b981 0%,#059669 100%)!important;background-size:100% 100%!important;animation:none!important;}' +
            '.dl-prepare-actions{display:flex;gap:10px;margin-top:18px;width:100%;max-width:320px;}' +
            '.dl-prepare-btn{flex:1;height:42px;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:5px;transition:transform .15s,box-shadow .15s,filter .15s;outline:none;font-family:inherit;}' +
            '.dl-prepare-btn:hover{transform:translateY(-1px);filter:brightness(1.05);}' +
            '.dl-prepare-btn:active{transform:translateY(0);}' +
            '.dl-prepare-btn:disabled{opacity:.6;cursor:not-allowed;}' +
            '.dl-prepare-btn-primary{background:linear-gradient(135deg,#06b6d4 0%,#0891b2 100%);color:#fff;box-shadow:0 2px 8px rgba(6,182,212,.3);}' +
            '.dl-prepare-btn-ghost{background:#fff;color:#64748b;border:1px solid #cbd5e1;}' +
            '@keyframes dlPulse{0%,100%{opacity:.3;transform:scale(.8);}50%{opacity:1;transform:scale(1.2);}}' +
            '@media (max-width:768px){' +
                '.dl-prepare-wrap{padding:30px 20px;min-height:340px;}' +
                '.dl-prepare-ring{width:140px;height:140px;}' +
                '.dl-ring-spinner{width:50px;height:50px;}' +
                '.dl-ring-check{width:56px;height:56px;}' +
                '.dl-prepare-title{font-size:18px;}' +
                '.dl-prepare-tip{font-size:14px;}' +
                '.dl-prepare-subtip{font-size:12px;}' +
                '.dl-prepare-actions{gap:12px;max-width:340px;}' +
                '.dl-prepare-btn{height:48px;font-size:14px;}' +
            '}';

        const style = document.createElement('style');
        style.id = 'treasure-popup-styles';
        style.textContent = css;
        document.head.appendChild(style);
    }

    /**
     * 复制卡密到剪贴板,带降级和提示
     * 严格只复制 this._currentSecret(由 show() 时缓存的纯卡密),
     * 不再读取 DOM textarea 的值,避免弹窗内的留言/订单号/标题等其他信息被一并复制。
     */
    _copy() {
        const text = (this._currentSecret || '').replace(/^\s+|\s+$/g, '');

        const showOk = function () {
            if (typeof message !== 'undefined' && message.success) {
                message.success('卡密已复制到剪贴板');
            } else if (typeof layer !== 'undefined' && layer.msg) {
                layer.msg('✓ 卡密已复制', { time: 1800 });
            }
        };
        const showFail = function () {
            if (typeof layer !== 'undefined' && layer.msg) {
                layer.msg('复制失败,请手动选中文本复制', { time: 2500 });
            }
        };

        if (!text) { showFail(); return; }

        // 优先 Clipboard API(HTTPS / localhost 才可用)
        if (navigator && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            try {
                navigator.clipboard.writeText(text).then(showOk).catch(function () {
                    treasure._copyFallback(text, showOk, showFail);
                });
                return;
            } catch (e) { /* 继续走 fallback */ }
        }
        treasure._copyFallback(text, showOk, showFail);
    }

    _copyFallback(text, ok, fail) {
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity  = '0';
            ta.style.top      = '0';
            ta.style.left     = '0';
            ta.setAttribute('readonly', '');
            document.body.appendChild(ta);
            ta.select();
            ta.setSelectionRange(0, ta.value.length);
            const success = document.execCommand('copy');
            document.body.removeChild(ta);
            success ? ok() : fail();
        } catch (e) { fail(); }
    }

    /**
     * HTML 字符转义,防 XSS
     */
    _escapeHTML(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
        });
    }

    /**
     * 把后台传来的纯文本卡密内容渲染成 HTML
     *
     * 规则:
     *  - 整体按行拆分 (\r?\n)
     *  - 命中 "短标签 + 冒号 + 内容" 格式的行 (中英文冒号都支持) ->
     *    整行 (标签 + 冒号 + 值) 用 <span class="dl-line-hi"> 包裹,荧光笔高亮
     *  - 标签长度限制在 1~12 字符 (中英文都按字符算),
     *    超过 12 字符的行视为说明性段落,不做高亮 (避免误伤长句)
     *  - 不含冒号的行 (空行/分隔符 ════/纯说明) 原样输出,不高亮
     *  - 所有内容均做 HTML 转义,无 XSS 风险
     *
     * 例子:
     *   输入:
     *     ═══ DEMO CARD ═══
     *     卡号: DEMO-1234-5678
     *     密码: PWD-XYZ
     *     看到此内容 = 弹窗工作正常
     *
     *   输出 (示意):
     *     <div class="dl-line">═══ DEMO CARD ═══</div>
     *     <div class="dl-line"><span class="dl-line-hi">卡号: DEMO-1234-5678</span></div>
     *     <div class="dl-line"><span class="dl-line-hi">密码: PWD-XYZ</span></div>
     *     <div class="dl-line">看到此内容 = 弹窗工作正常</div>
     *
     * @param {string} secret  原始卡密文本
     * @returns {string}       渲染后的 HTML 字符串 (已转义)
     */
    _renderSecret(secret) {
        const text = (typeof secret === 'string') ? secret : '';
        if (!text) return '';

        // 标签长度 ≤ 12 字符 (不含冒号本身和换行) 的 "键: 值" 行视为关键字段
        // 用 [^\n:：] 同时排除中英文冒号,标签里不含冒号
        const KV_RE = /^(\s*)([^\n:：]{1,12})(\s*[:：]\s*)(\S.*)$/;
        const self = this;

        const lines = text.split(/\r?\n/);
        const out = [];

        for (let i = 0; i < lines.length; i++) {
            const raw = lines[i];
            const m = KV_RE.exec(raw);
            if (m) {
                // 整行高亮: 前导空白原样输出,后面 (标签 + 冒号 + 值) 用 span 包
                const lead   = self._escapeHTML(m[1]);
                const inner  = self._escapeHTML(m[2] + m[3] + m[4]);
                out.push('<div class="dl-line">' + lead + '<span class="dl-line-hi">' + inner + '</span></div>');
            } else {
                const safe = self._escapeHTML(raw);
                // 空行用 \u00A0 (不间断空格) 撑开高度,保证视觉间距
                out.push('<div class="dl-line">' + (safe.length ? safe : '\u00A0') + '</div>');
            }
        }

        return out.join('');
    }

    /**
     * 触发静默加载 + 显示等待 UI (无倒计时, 无自动关闭)
     *
     * 设计原则:
     *  - 静默 — 用户点击下载按钮后**不打开任何新窗口**, 在卡密弹窗内显示等待 UI
     *           用隐藏 iframe 在后台预热目标 url, 当前页面/卡密弹窗完整保留
     *  - 直链文件: iframe 加载时触发 attachment 下载, 浏览器下载栏会出现下载条目
     *  - 网页 URL: iframe 后台加载, onload 触发后切 ready 状态
     *  - "等待 UI 关闭" != "下载就绪", 所以**不做自动关闭**
     *  - 进度条 shimmer 无限循环, 表达"在做事", 不暗示"快好了"
     *  - 文案随状态切换 (默认: 准备中 / ready: 已发起)
     *  - iframe.onload 触发 -> 切到 ready 状态 (圆环填满变绿 + 对勾 + "下载已发起" 文案)
     *    但仍由用户主动点「返回卡密」才结束等待 UI
     *  - 不再提供「打开下载页」按钮: 直链下载已经在 iframe 触发了, 用户跳新窗只是空白
     *
     * @param {string} url  目标 url (已通过 http(s) 校验)
     */
    _silentRedirect(url) {
        if (!url) return;

        // ---------- 1. 找到当前卡密弹窗的 DOM 节点 ----------
        const popupEl = document.querySelector('.layui-layer.treasure-popup');
        if (!popupEl) {
            // 极端情况:弹窗 DOM 没找到,直接开新窗兜底
            try { window.open(url, '_blank'); } catch (e) {}
            return;
        }
        const contentEl = popupEl.querySelector('.layui-layer-content');
        const btnEl     = popupEl.querySelector('.layui-layer-btn');

        const originalContentHTML    = contentEl ? contentEl.innerHTML : '';
        const originalContentPadding = contentEl ? contentEl.style.padding : '';
        const originalBtnDisplay     = btnEl ? btnEl.style.display : '';

        // ---------- 2. 静默加载 (不打开任何新窗, 避免跳走看到空白页的体验) ----------
        // 用隐藏 iframe 在后台拉取目标 url, 当前页面/卡密弹窗不动
        // 直链文件: iframe 加载时浏览器自动触发下载, 下载栏可见
        // 网页 URL: iframe 后台加载, onload 后切 ready 状态

        // ---------- 3. 替换弹窗内容为"等待 UI" ----------
        const html =
            '<div class="dl-prepare-wrap" id="dlPrepareWrap">' +
                '<div class="dl-prepare-ring">' +
                    '<svg class="dl-ring-svg" viewBox="0 0 120 120">' +
                        '<defs>' +
                            '<linearGradient id="dlGrad" x1="0%" y1="0%" x2="100%" y2="100%">' +
                                '<stop offset="0%" stop-color="#06b6d4"/>' +
                                '<stop offset="100%" stop-color="#0891b2"/>' +
                            '</linearGradient>' +
                        '</defs>' +
                        '<circle class="dl-ring-bg" cx="60" cy="60" r="54"/>' +
                        '<circle class="dl-ring-fg" cx="60" cy="60" r="54"/>' +
                    '</svg>' +
                    '<div class="dl-ring-num">' +
                        // 默认: 旋转的下载图标
                        '<div class="dl-ring-spinner">' +
                            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                                '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>' +
                                '<polyline points="7 10 12 15 17 10"/>' +
                                '<line x1="12" y1="15" x2="12" y2="3"/>' +
                            '</svg>' +
                        '</div>' +
                        // ready 状态: 对勾 (默认 display:none, .is-ready 时显示)
                        '<div class="dl-ring-check">' +
                            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">' +
                                '<polyline points="20 6 9 17 4 12"/>' +
                            '</svg>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="dl-prepare-title">' +
                    '<span class="dl-prepare-title-text" id="dlPrepareTitle">正在为您准备下载</span>' +
                    '<span class="dl-dot"></span>' +
                    '<span class="dl-dot"></span>' +
                    '<span class="dl-dot"></span>' +
                '</div>' +
                '<div class="dl-prepare-tip" id="dlPrepareTip">下载已为您悄悄发起,请留意浏览器下载栏</div>' +
                '<div class="dl-prepare-subtip" id="dlPrepareSubtip">无需跳转其他页面,这里就是下载入口 · 完成后点「返回卡密」</div>' +
                '<div class="dl-prepare-bar"><div class="dl-prepare-bar-fg"></div></div>' +
                '<div class="dl-prepare-actions">' +
                    '<button type="button" class="dl-prepare-btn dl-prepare-btn-primary" id="dlPrepareClose">' +
                        '<i class="fa-duotone fa-regular fa-arrow-left" style="margin-right:5px;"></i>返回卡密' +
                    '</button>' +
                '</div>' +
            '</div>';

        if (contentEl) {
            contentEl.innerHTML     = html;
            contentEl.style.padding = '0';
        }
        if (btnEl) {
            btnEl.style.display = 'none';
        }

        // ---------- 4. 网络加速 + 加载完成探针 iframe ----------
        const preloadHandles = [];

        // (a) DNS / TCP / TLS 提前握手
        try {
            const u      = new URL(url);
            const origin = u.protocol + '//' + u.host;

            const dnsLink = document.createElement('link');
            dnsLink.rel  = 'dns-prefetch';
            dnsLink.href = origin;
            document.head.appendChild(dnsLink);
            preloadHandles.push(dnsLink);

            const preconnectLink = document.createElement('link');
            preconnectLink.rel         = 'preconnect';
            preconnectLink.href        = origin;
            preconnectLink.crossOrigin = 'anonymous';
            document.head.appendChild(preconnectLink);
            preloadHandles.push(preconnectLink);
        } catch (e) {}

        // (b) 加载完成探针 iframe
        //     用一个隐藏 iframe 加载同一 url, 监听它的 load 事件作为"下载页就绪"乐观信号
        //     注意: iframe.onload 不可靠 (跨域 + X-Frame-Options + 直链文件等多种情况)
        //     所以这里**只更新 UI 文案**, 不自动关闭等待 UI
        let probeIframe = null;
        try {
            probeIframe = document.createElement('iframe');
            probeIframe.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;border:0;opacity:0;pointer-events:none;';
            probeIframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
            probeIframe.src = url;
            document.body.appendChild(probeIframe);
            preloadHandles.push(probeIframe);
        } catch (e) {}

        // ---------- 5. 状态切换 ----------
        const wrapEl     = popupEl.querySelector('#dlPrepareWrap');
        const titleEl    = popupEl.querySelector('#dlPrepareTitle');
        const tipEl      = popupEl.querySelector('#dlPrepareTip');
        const subtipEl   = popupEl.querySelector('#dlPrepareSubtip');
        const closeEl    = popupEl.querySelector('#dlPrepareClose');

        let closed = false; // 用户已点"返回卡密", 后续事件忽略
        let ready  = false; // iframe.onload 触发过, 标记为已就绪 (但不自动关闭)

        const removePreloadHandles = function () {
            preloadHandles.forEach(function (el) {
                try { el.parentNode && el.parentNode.removeChild(el); } catch (e) {}
            });
            preloadHandles.length = 0;
        };

        const restorePopup = function () {
            if (contentEl) {
                contentEl.innerHTML     = originalContentHTML;
                contentEl.style.padding = originalContentPadding;
            }
            if (btnEl) {
                btnEl.style.display = originalBtnDisplay;
            }
        };

        const setReady = function () {
            if (ready || closed) return;
            ready = true;
            if (wrapEl)   wrapEl.classList.add('is-ready');
            if (titleEl)  titleEl.textContent = '下载已发起';
            if (tipEl)    tipEl.textContent   = '✓ 已成功为您发起下载,请到浏览器下载栏查看进度';
            if (subtipEl) subtipEl.textContent = '若浏览器没弹出下载提示,可关闭弹窗后再点一次按钮';
        };

        // iframe 加载完成 -> 切到 ready 状态 (仅 UI, 不自动关闭)
        // iframe.error 不当作真实失败, 因为很多场景探针失败但用户的新 tab 正常
        if (probeIframe) {
            probeIframe.addEventListener('load', setReady);
        }

        // ---------- 6. 操作按钮 ----------
        // 仅一个「返回卡密」按钮 - 用户主动结束等待 UI
        // 不再提供「打开下载页」按钮: 直链下载在 iframe 内已经触发, 跳新窗只是空白页
        if (closeEl) {
            closeEl.addEventListener('click', function () {
                if (closed) return;
                closed = true;
                // iframe 等资源延后清理 (浏览器可能还在后台用)
                setTimeout(removePreloadHandles, 30000);
                restorePopup();
            });
        }
    }

    show(tradeNo, secret) {
        this._injectStyles();

        // 缓存原始 secret,用于复制按钮严格只复制纯卡密
        this._currentSecret = (typeof secret === 'string') ? secret : '';

        const self          = this;
        const cfg           = (typeof window !== 'undefined' && window.dlPaydone) ? window.dlPaydone : null;
        const showCustomBtn = !!(cfg && cfg.enabled && cfg.text && cfg.url);

        // 复制卡密的按钮回调:点击不关闭弹窗(返回 false)
        const copyCb = function () {
            self._copy();
            return false;
        };

        // 默认 1 个按钮:复制卡密(主操作)
        let btnArr = [
            '<i class="fa-duotone fa-regular fa-copy" style="margin-right:6px;"></i>复制卡密'
        ];
        let yesCb  = copyCb;
        let btn2Cb;

        if (showCustomBtn) {
            // XSS 防护:文字做 HTML 转义,链接只允许 http(s)
            const safeText = String(cfg.text).replace(/[&<>"']/g, function (c) {
                return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
            });
            const safeUrl = /^https?:\/\//i.test(cfg.url) ? cfg.url : '';

            // 2 个按钮:[ 自定义下载(主) ] [ 复制卡密(副) ]
            btnArr = [
                '<i class="fa-duotone fa-regular fa-circle-down" style="margin-right:6px;"></i>' + safeText,
                '<i class="fa-duotone fa-regular fa-copy" style="margin-right:6px;"></i>复制卡密'
            ];

            yesCb = function () {
                if (safeUrl) {
                    // 静默加载: 不打开任何新窗, 在卡密弹窗内显示等待 UI
                    // + 隐藏 iframe 在后台触发下载或加载页面, onload 触发后切 ready 状态
                    // + 用户主动点「返回卡密」结束等待 UI
                    self._silentRedirect(safeUrl);
                }
                return false; // 不关弹窗(由 _silentRedirect 接管展示)
            };
            btn2Cb = copyCb;
        }

        layer.open({
            type:    1,
            skin:    'treasure-popup',
            title:   `${util.icon("fa-duotone fa-regular fa-baby-carriage")} 您购买的宝贝信息:`,
            area:    util.isMobile() ? ["100%", "100%"] : ['460px', '480px'],
            content: '<div class="dl-secret-box">' + this._renderSecret(secret) + '</div>',
            btn:     btnArr,
            yes:     yesCb,
            btn2:    btn2Cb
        });
    }
};
