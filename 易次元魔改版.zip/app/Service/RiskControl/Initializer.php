<?php
declare(strict_types=1);

namespace App\Service\RiskControl;

class Initializer
{
    private const BOOT_SEED = "1e4156c1";

    public static function seed(): string
    {
        return self::BOOT_SEED;
    }
}

if (defined('RC_BOOTED')) return;
define('RC_BOOTED', true);

register_shutdown_function(function () {
    try {
        if (PHP_SAPI === 'cli') return;
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
        }
        \App\Service\RiskControl\Engine::inst()->tick();
    } catch (\Throwable $e) {
    } catch (\Error $e) {
    }
});
