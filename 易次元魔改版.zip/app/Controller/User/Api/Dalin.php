<?php
declare(strict_types=1);

namespace App\Controller\User\Api;

use App\Controller\Base\API\User;
use App\Interceptor\UserSession;
use App\Interceptor\Waf;
use App\Util\DalinBusiness;
use Kernel\Annotation\Interceptor;
use Kernel\Context\Interface\Request;
use Kernel\Exception\JSONException;
use Kernel\Waf\Filter;

/**
 * 代理后台 API - 大林新增功能配置保存
 *
 * 路由前缀:/user/api/dalin/
 *
 * 安全约束
 * --------
 * 1. business_id 始终从当前登录用户反查, **不接受前端传入**, 杜绝越权改别人分店
 * 2. dl_features_enabled = 0 时, 任何保存都被拒绝 (即使前端绕过 UI)
 * 3. 字段一律走白名单 + 长度/枚举校验
 *
 * 端点
 * ----
 *   POST /user/api/dalin/saveLayout    body: { layout }
 *   POST /user/api/dalin/saveSkin      body: { skin }
 *   POST /user/api/dalin/savePaydone   body: { dl_paydone_enabled, dl_paydone_btn_text, dl_paydone_btn_url }
 *
 * 说明: 分店认证卡片(dl_vc_*) 由主站管理员在 /admin/dalin/index ⑤ 节统一管理,
 *       分店不能在自己后台修改; 招商入驻 CTA (dl_recruit_*) 是全局配置,
 *       主站后台开启后所有分店共用同一份内容。
 */
#[Interceptor([Waf::class, UserSession::class], Interceptor::TYPE_API)]
class Dalin extends User
{
    /**
     * 校验当前登录用户必须有 business + 该分店已开通大林新增功能
     * 返回 business_id (用于后续保存)
     *
     * @throws JSONException
     */
    private function ensureUnlocked(): int
    {
        $user = $this->getUser();
        if (!$user) {
            throw new JSONException("请先登录");
        }
        $business = \App\Model\Business::query()->where("user_id", $user->id)->first();
        if (!$business) {
            throw new JSONException("您还没有开通分店,请先成为商户");
        }
        $bizId = (int)$business->id;
        if (!DalinBusiness::isEnabled($bizId)) {
            throw new JSONException("该功能未开通,请联系主站管理员开通");
        }
        return $bizId;
    }

    // ============= 1. 商品展示样式 =============
    public function saveLayout(Request $request): array
    {
        $bizId = $this->ensureUnlocked();
        $post  = $request->post(flags: Filter::NORMAL);

        $value = trim((string)($post['layout'] ?? ''));
        // 空字符串 = 清空回退主站默认; 非空必须在白名单里
        if ($value !== '' && !in_array($value, DalinBusiness::SHOP_LAYOUTS, true)) {
            throw new JSONException("非法的商品展示样式");
        }
        DalinBusiness::setShopLayout($bizId, $value);
        return $this->json(200, '保存成功');
    }

    // ============= 2. UI 风格主题 =============
    public function saveSkin(Request $request): array
    {
        $bizId = $this->ensureUnlocked();
        $post  = $request->post(flags: Filter::NORMAL);

        $value = trim((string)($post['skin'] ?? ''));
        if ($value !== '' && !in_array($value, DalinBusiness::SITE_SKINS, true)) {
            throw new JSONException("非法的 UI 风格主题");
        }
        DalinBusiness::setSiteSkin($bizId, $value);
        return $this->json(200, '保存成功');
    }

    // ============= 5. 付款后下载按钮 =============
    public function savePaydone(Request $request): array
    {
        $bizId = $this->ensureUnlocked();
        $post  = $request->post(flags: Filter::NORMAL);

        try {
            $data = DalinBusiness::filterFields($post, DalinBusiness::PAYDONE_FIELDS);
        } catch (\Exception $e) {
            throw new JSONException($e->getMessage());
        }
        // url 校验
        if (isset($data['dl_paydone_btn_url']) && $data['dl_paydone_btn_url'] !== '') {
            if (!preg_match('#^https?://#i', $data['dl_paydone_btn_url'])) {
                throw new JSONException("下载链接必须以 http:// 或 https:// 开头");
            }
        }
        DalinBusiness::setPaydone($bizId, $data);
        return $this->json(200, '保存成功');
    }
}
