<?php
declare(strict_types=1);

namespace App\Controller\User;


use App\Controller\Base\View\User;
use App\Interceptor\UserSession;
use App\Interceptor\Waf;
use App\Model\BusinessLevel;
use App\Model\Config;
use Kernel\Annotation\Interceptor;

#[Interceptor([Waf::class, UserSession::class])]
class Business extends User
{
    /**
     * @return string
     * @throws \Kernel\Exception\ViewException|\Kernel\Exception\JSONException
     */
    public function index(): string
    {

        $user = $this->getUser();
        $businessLevel = $user->businessLevel;
        $level = BusinessLevel::query()->orderBy("price", "asc");
        if ($businessLevel) {
            $level = $level->where("price", ">", $businessLevel->price)->where("id", "!=", $businessLevel->id);
        }
        $level = $level->get()->toArray();

        $configDomain = (array)explode(",", (string)Config::get("domain"));
        // 过滤掉空字符串和纯空白(防止管理员配置末尾带逗号导致出现空后缀选项)
        $configDomain = array_values(array_filter(array_map('trim', $configDomain), fn($v) => $v !== ''));
        $business = $user->business;

        // ============ 新增：用于在前端展示完整店铺地址 ============
        $boundSubdomainFull = "";   // 完整的已绑定子域名 (例如: csfd.example.com)
        $boundSubdomainSuffix = ""; // 已匹配到的后缀 (例如: example.com)

        if ($business instanceof \App\Model\Business) {
            // 在去掉后缀之前，先保存原始完整子域名
            $boundSubdomainFull = (string)$business->subdomain;

            foreach ($configDomain as $item) {
                $item = trim((string)$item);
                if ($item === "") {
                    continue;
                }
                // 找到匹配的后缀
                if ($boundSubdomainSuffix === "" && $boundSubdomainFull !== ""
                    && str_ends_with($boundSubdomainFull, "." . $item)) {
                    $boundSubdomainSuffix = $item;
                }
                $business->subdomain = str_replace("." . $item, "", (string)$business->subdomain);
            }
        }

        // 检测当前使用的协议 (http / https)
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        $siteProtocol = $isHttps ? 'https' : 'http';
        // ============ 新增结束 ============

        return $this->theme("我的店铺", "BUSINESS", "User/Business.html", [
            "me" => $user->toArray(),
            "level" => $level,
            "business" => $business,
            "purchase" => (int)($_GET['purchase'] ?? 0),
            "domain" => $configDomain,
            "bound_subdomain_full" => $boundSubdomainFull,
            "bound_subdomain_suffix" => $boundSubdomainSuffix,
            "site_protocol" => $siteProtocol,
        ]);
    }
}
