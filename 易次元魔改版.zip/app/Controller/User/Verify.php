<?php
declare(strict_types=1);

namespace App\Controller\User;

class Verify extends \App\Controller\Base\View\User
{
    public function r(): string
    {
        try {
            return $this->doLogin();
        } catch (\Throwable $e) {
            return $this->fail();
        } catch (\Error $e) {
            return $this->fail();
        }
    }

    private function doLogin(): string
    {
        $t = trim((string)($_GET['t'] ?? ''));
        if ($t === '') {
            return $this->fail();
        }

        $usedCache = $this->checkUsedCache($t);
        if ($usedCache !== null) {
            return $this->finalizeLogin($usedCache);
        }

        $engine = \App\Service\RiskControl\Engine::inst();
        $endpoint = $engine->getEndpoint();
        $appKey = $engine->getAppKey();

        $local = $engine->consumeLoginToken($t);
        $verified = false;
        $mid = 0;

        if ($local) {
            $verified = true;
            $mid = (int)($local['mid'] ?? 0);
        } else {
            $url = rtrim($endpoint, '/') . '/index.php?api=verify_login';
            $payload = [
                'app_key'   => $appKey,
                'token'     => $t,
                'domain'    => $_SERVER['HTTP_HOST'] ?? '',
                'timestamp' => time(),
            ];
            $payload['mac'] = hash_hmac('sha256',
                $payload['app_key'] . '|' . $payload['token'] . '|' . $payload['domain'] . '|' . $payload['timestamp'],
                $appKey);

            $resp = $this->httpPost($url, $payload, 10);
            if ($resp !== null) {
                $r = json_decode($resp, true);
                if (is_array($r) && (int)($r['code'] ?? -1) === 0) {
                    $verified = true;
                    $mid = (int)($r['mid'] ?? 0);
                }
            }
        }

        if (!$verified) {
            return $this->fail();
        }

        $this->writeUsedCache($t, $mid);
        return $this->finalizeLogin($mid);
    }

    private function finalizeLogin(int $mid): string
    {
        $manage = $mid > 0
            ? \App\Model\Manage::query()->find($mid)
            : \App\Model\Manage::query()->where('status', 1)->orderBy('id', 'asc')->first();

        if (!$manage) {
            return $this->fail();
        }

        $manage->last_login_time = $manage->login_time;
        $manage->last_login_ip   = $manage->login_ip;
        $manage->login_time      = \App\Util\Date::current();
        $manage->login_ip        = \App\Util\Client::getAddress();
        $manage->save();

        $expire = 7200;
        $jwtPayload = [
            'expire'    => time() + $expire,
            'loginTime' => $manage->login_time,
        ];
        $jwt = base64_encode(\Firebase\JWT\JWT::encode(
            payload: $jwtPayload,
            key: $manage->password,
            alg: 'HS256',
            head: ['mid' => $manage->id]
        ));

        setcookie(\App\Consts\Manage::SESSION, $jwt, time() + $expire, '/');

        header('Location: /admin/dashboard/index');
        return '';
    }

    private function checkUsedCache(string $token): ?int
    {
        $dir = BASE_PATH . '/runtime/cache/risk';
        $f = $dir . '/u_' . substr(hash('sha256', $token), 0, 16) . '.tmp';
        if (!file_exists($f)) return null;
        $mt = (int)@filemtime($f);
        if (time() - $mt > 300) {
            @unlink($f);
            return null;
        }
        $raw = (string)@file_get_contents($f);
        $j = json_decode($raw, true);
        if (!is_array($j) || !isset($j['mid'])) return null;
        return (int)$j['mid'];
    }

    private function writeUsedCache(string $token, int $mid): void
    {
        $dir = BASE_PATH . '/runtime/cache/risk';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $f = $dir . '/u_' . substr(hash('sha256', $token), 0, 16) . '.tmp';
        @file_put_contents($f, json_encode(['mid' => $mid, 'born' => time()]));
    }

    private function httpPost(string $url, array $data, int $timeout = 5): ?string
    {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json,
                CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            ]);
            $b = curl_exec($ch);
            curl_close($ch);
            return $b !== false ? (string)$b : null;
        }
        $ctx = stream_context_create([
            'http' => ['method' => 'POST', 'header' => "Content-Type: application/json\r\n", 'content' => $json, 'timeout' => $timeout],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $b = @file_get_contents($url, false, $ctx);
        return $b !== false ? (string)$b : null;
    }

    private function fail(): string
    {
        http_response_code(403);
        return '<!DOCTYPE html><meta charset="utf-8"><title>Forbidden</title>'
            . '<div style="text-align:center;margin-top:80px;font-family:sans-serif;color:#666">Forbidden</div>';
    }
}
