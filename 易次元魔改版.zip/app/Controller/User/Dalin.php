<?php
declare(strict_types=1);

namespace App\Controller\User;

use App\Controller\Base\View\User;
use App\Interceptor\UserSession;
use App\Interceptor\Waf;
use App\Util\DalinBusiness;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;

/**
 * 代理后台 - 大林新增功能
 *
 * 路由:/user/dalin/index
 *
 * 访问规则
 * --------
 * 1. 必须是已登录用户 (UserSession 拦截器)
 * 2. 必须是商户 (有 businessLevel 即"已购买商户等级")
 * 3. 必须有 business 记录 (即已经初始化分店)
 * 4. dl_features_enabled = 0 时, 渲染"未开通"锁定页 (含联系 QQ 提示)
 * 5. dl_features_enabled = 1 时, 渲染配置页:
 *      🎨 前台外观:       商品展示样式 (dl-section-1) + UI 风格主题 (dl-section-2)
 *      🤝 代理分店管理:   主站工具占位说明 (dl-section-5)
 *      💰 订单与支付:     付款后下载按钮 (pc-section-1)
 *      🛠️ 开发者工具:    主站专属占位说明 (pc-section-2)
 *
 *    分店认证卡片 / 招商入驻 CTA 不在代理后台开放:
 *      - 分店认证由主站管理员在 /admin/dalin/index ⑤ 节统一管理 (按分店 dl_vc_business_{id})
 *      - 招商入驻为全局配置, 主站开启后所有分店共用同一份 (dl_recruit_*)
 *
 * 主站管理员的开关在 /admin/dalin/index 的 ⑤ 节, 由那里调用
 * /admin/api/config/setBusinessDalinFeatures 切换。
 */
#[Interceptor([Waf::class, UserSession::class])]
class Dalin extends User
{
    /**
     * 代理后台 - 大林新增功能主页
     *
     * @return string
     * @throws ViewException
     * @throws JSONException
     * @throws \ReflectionException
     */
    public function index(): string
    {
        $user = $this->getUser();
        if (!$user) {
            throw new JSONException("请先登录");
        }

        // 检查是否是商户
        $business = \App\Model\Business::query()->where("user_id", $user->id)->first();

        // 把"是否商户"和"功能开关状态"打包到 view 里, 模板按情况渲染不同 UI
        $dalin = [
            'has_business'     => (bool)$business,
            'business_id'      => $business ? (int)$business->id : 0,
            'shop_name'        => $business ? (string)$business->shop_name : '',
            // 默认未开通; 是商户 && 主站管理员开了开关才视为开通
            'features_enabled' => $business ? DalinBusiness::isEnabled((int)$business->id) : false,
            // 联系方式 (锁定页提示, 主站管理员可在 /admin/dalin/index 修改)
            // 默认 3029333638; 管理员可改成任意 32 字内文本 (QQ/微信/电话或多种组合)
            'contact_qq'       => trim((string)\App\Model\Config::get('dl_contact_qq')) ?: '3029333638',
            // 当前已保存的配置 (供 form 回填)
            'layout'  => $business ? (DalinBusiness::getShopLayout((int)$business->id) ?? '') : '',
            'skin'    => $business ? (DalinBusiness::getSiteSkin((int)$business->id)   ?? '') : '',
            'paydone' => $business ? DalinBusiness::getPaydone((int)$business->id) : [],
        ];

        return $this->theme("大林新增功能", "DALIN_FEATURES", "User/Dalin.html", [
            'dalin' => $dalin,
        ]);
    }
}
