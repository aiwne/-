<?php
declare(strict_types=1);

namespace App\Controller\Base\View;

use App\Consts\Render;
use App\Model\Business;
use App\Model\Config;
use App\Util\Client;
use App\Util\DalinBusiness;
use App\Util\Theme;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;
use Kernel\Util\View;

/**
 * Class Manage
 * @package App\Controller\Base\View
 */
abstract class User extends \App\Controller\Base\User
{
    /**
     * @var array|string[]
     */
    protected array $indexTemplateList = [
        'INDEX', 'ITEM', 'QUERY', 'CLOSED'
    ];

    /**
     * @param string $title
     * @param string $template
     * @param array $data
     * @return string
     * @throws ViewException
     * @throws JSONException
     */
    protected function render(string $title, string $template, array $data = []): string
    {
        try {
            //加载helper
            require(BASE_PATH . "/app/View/User/Helper.php");

            $data['title'] = $title;
            $data['app']['version'] = \config("app")['version'];
            $cfg = Config::list();

            foreach ($cfg as $k => $v) {
                $data["config"][$k] = $v;
            }
            return View::render('User/' . $template, $data);
        } catch (\SmartyException $e) {
            throw new ViewException($e->getMessage());
        }
    }

    /**
     * @param string $title
     * @param string $template
     * @param string $default
     * @param array $data
     * @return string
     * @throws JSONException
     * @throws ViewException
     * @throws \ReflectionException
     */
    protected function theme(string $title, string $template, string $default, array $data = []): string
    {
        try {
            //加载helper
            require(BASE_PATH . "/app/View/User/Helper.php");

            $data['title'] = $title;
            $data['app']['version'] = \config("app")['version'];
            $data['favicon'] = "/favicon.ico";

            $cfg = Config::list();

            foreach ($cfg as $k => $v) {
                $data["config"][$k] = $v;
            }

            if (in_array($template, $this->indexTemplateList)) {
                if (Client::isMobile()) {
                    $theme = $cfg['user_mobile_theme'];
                    if ($data['config']['background_mobile_url']) {
                        $data['config']['background_url'] = $data['config']['background_mobile_url'];
                    }

                } else {
                    $theme = $cfg['user_theme'];
                }

                if ($theme == "0") {
                    $theme = $cfg['user_theme'];
                }
            } else {
                $theme = $cfg['user_center_theme'] ?: "Cartoon";
            }

            //模板静态路径
            $data['static'] = "/app/View/User/Theme/" . $theme;

            $domain = Client::getDomain();
            $business = Business::query()->where("subdomain", $domain)->first() ?? Business::query()->where("topdomain", $domain)->first();
            if ($business) {
                $data['config']['shop_name'] = $business->shop_name;
                $data['config']['title'] = $business->title;
                $data['config']['notice'] = $business->notice;
                $data['config']['service_url'] = $business->service_url != "" ? $business->service_url : "https://wpa.qq.com/msgrd?v=1&uin={$business->service_qq}";
                if (!$data['from']) {
                    $data['from'] = $business->user_id;
                }
                $businessUser = $business->user;

                if ($businessUser && $businessUser->avatar) {
                    $data['favicon'] = $businessUser->avatar;
                }

                // 招商入驻 CTA: 全局配置 (dl_recruit_*), 主站后台开启后所有分店共用同一份
                // 之前曾强制分店隐藏, 现已取消; 如需在分店隐藏请直接在主站后台关闭 dl_recruit_enabled

                // 大林专属:分店「官方认证商家」卡片由主站管理员在后台 → 大林专属 → ⑤ 代理店铺认证 中配置
                // 这里读取该分店的专属配置(若存在),覆盖主站默认值,使每个分店看到自己专属的认证信息
                // 注意:这段逻辑保持向后兼容 - vc 永远生效,不受 dl_features_enabled 开关控制
                $vcRaw = Config::get("dl_vc_business_" . $business->id);
                if ($vcRaw !== "") {
                    $vcData = json_decode($vcRaw, true);
                    if (is_array($vcData)) {
                        $vcKeys = ['dl_vc_enabled', 'dl_vc_title', 'dl_vc_badge', 'dl_vc_label1', 'dl_vc_value1', 'dl_vc_label2', 'dl_vc_value2', 'dl_vc_label3', 'dl_vc_value3'];
                        foreach ($vcKeys as $vk) {
                            if (array_key_exists($vk, $vcData)) {
                                $data['config'][$vk] = $vcData[$vk];
                            }
                        }
                    }
                }

                // 大林新增功能 - 应用分店级 fallback (layout/skin/paydone)
                // 仅当主站管理员为该分店开通了 dl_features_enabled 时, 代理后台保存的字段才会生效。
                // 字段为空 -> 自动回退主站默认值; 字段有值 -> 覆盖主站默认。
                $data['config'] = DalinBusiness::applyFallback($data['config'], (int)$business->id);
            }

            $defaultThemePath = "User/Theme/Cartoon/";
            $themePath = "User/Theme/{$theme}/";
            $config = Theme::getConfig($theme);
            $path = $defaultThemePath . $default;
            $system = true;

            //判断路径是否存在
            if (!empty($config['theme']) && key_exists($template, $config['theme'])) {
                $path = $themePath . $config['theme'][$template];
                $system = false;
            }

            $user = $this->getUser();
            if ($user) {
                $data['user'] = $user;
                $data['group'] = $this->getUserGroup()?->toArray();
            }

            if ($system) {
                $data['setting'] = Theme::getConfig("Cartoon")["setting"];
            } else {
                $data['setting'] = $config['setting'];
            }

            if ($config['info']['RENDER'] == Render::ENGINE_SMARTY || $system) {
                return View::render($path, $data);
            } elseif ($config['info']['RENDER'] == Render::ENGINE_PHP) {
                ob_start();
                require(BASE_PATH . '/app/View/' . $path);
                $result = ob_get_contents();
                ob_end_clean();
                hook(\App\Consts\Hook::RENDER_VIEW, $result);
                return $result;
            }
        } catch (\SmartyException $e) {
            throw new ViewException($e->getMessage());
        }

        return "";
    }


}