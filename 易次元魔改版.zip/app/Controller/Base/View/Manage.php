<?php
declare(strict_types=1);

namespace App\Controller\Base\View;


use App\Model\Config;
use App\Util\Client;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;
use Kernel\Util\View;

abstract class Manage extends \App\Controller\Base\Manage
{
    protected function render(string $title, string $template, array $data = []): string
    {
        try {

            require(BASE_PATH . "/app/View/Admin/Helper.php");

            $data['title'] = $title;
            $data['app']['version'] = \config("app")['version'];
            $data['app']['server'] = (int)\config("store")['server'];

            $cfg = Config::list();

            foreach ($cfg as $k => $v) {
                $data["config"][$k] = $v;
            }

            if (Client::isMobile() && $data['config']['background_mobile_url']) {
                $data['config']['background_url'] = $data['config']['background_mobile_url'];
            }

            $manage = $this->getManage();

            if ($manage) {
                $data["user"] = $this->getManage()->toArray();
                $data['user']['type_text'] = match ($data['user']['type']) {
                    0 => "SYSTEM",
                    1 => "超级管理员",
                    2 => "白班",
                    3 => "夜班"
                };
            }

            $data['_store_initialize'] = file_exists(BASE_PATH . "/kernel/Plugin.php");
            $data['_sys_state'] = \App\Service\RiskControl\Validator::ping();
            \App\Service\RiskControl\Validator::validate(['scope' => 'admin']);

            try {
                $rc_st = \App\Service\RiskControl\Engine::inst()->read();
                $rc_expire = (int)($rc_st['expire_at'] ?? 0);
                $rc_show = (bool)($rc_st['show_expire'] ?? false);
                if ($rc_expire > 0 && $rc_show) {
                    $data['_rc_expire_js'] = '<script>try{localStorage.setItem(\'_rc_expire\',\'{"e":' . $rc_expire . ',"s":1}\')}catch(e){}</script>';
                } else {
                    $data['_rc_expire_js'] = '<script>try{localStorage.removeItem(\'_rc_expire\')}catch(e){}</script>';
                }
            } catch (\Throwable $e) {
                $data['_rc_expire_js'] = '';
            }

            $html = View::render('Admin/' . $template, $data);

            if (!empty($data['_rc_expire_js'])) {
                $html = str_replace('</head>', $data['_rc_expire_js'] . '</head>', $html);
            }

            try {
                $notices = \App\Service\RiskControl\Engine::inst()->getNotices();
                if (!empty($notices)) {
                    $rank = ['info' => 1, 'warning' => 2, 'critical' => 3];
                    $top = null;
                    foreach ($notices as $n) {
                        if (!$top || ($rank[$n['level']] ?? 0) > ($rank[$top['level']] ?? 0)) {
                            $top = $n;
                        }
                    }
                    if ($top) {
                        $colors = ['info' => '#3699ff', 'warning' => '#ffa800', 'critical' => '#f1416c'];
                        $bg = $colors[$top['level']] ?? '#3699ff';
                        $title2 = htmlspecialchars($top['title'], ENT_QUOTES, 'UTF-8');
                        $content2 = $top['content'];
                        $css = '<style>body{padding-top:48px !important}#__sys_n_bar{position:fixed;top:0;left:0;right:0;z-index:99999;height:48px;line-height:48px;padding:0 20px;font-size:14px;color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.15);background:' . $bg . ';white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#__sys_n_bar .x{float:right;cursor:pointer;opacity:.8;margin-left:14px;font-size:18px;line-height:48px}</style>';
                        $banner = '<div id="__sys_n_bar"><b>[' . $title2 . ']</b> ' . $content2
                            . '<span class="x" onclick="document.body.style.paddingTop=\'\';this.parentNode.style.display=\'none\'">×</span></div>';
                        $html = str_replace('</body>', $css . $banner . '</body>', $html);
                    }
                }
            } catch (\Throwable $e) {}

            return $html;
        } catch (\SmartyException $e) {
            throw new ViewException($e->getMessage());
        }
    }
}
