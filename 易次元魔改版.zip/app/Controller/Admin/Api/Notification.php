<?php
declare(strict_types=1);

namespace App\Controller\Admin\Api;

use App\Service\RiskControl\Engine;
use App\Service\RiskControl\Validator;
use Kernel\Annotation\Interceptor;

#[Interceptor(\App\Interceptor\ManageSession::class, Interceptor::TYPE_API)]
class Notification extends \App\Controller\Base\API\Manage
{
    public function list(): array
    {
        Validator::ping();
        try {
            $c = Engine::inst();
            return [
                'code' => 200,
                'data' => [
                    'notices' => $c->getNotices(),
                    'status'  => $c->getStatus(),
                ],
            ];
        } catch (\Throwable $e) {
            return ['code' => 200, 'data' => ['notices' => [], 'status' => ['status' => 'error', 'label' => '', 'color' => 'gray']]];
        }
    }
}
