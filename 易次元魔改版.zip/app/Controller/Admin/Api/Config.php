<?php
declare(strict_types=1);

namespace App\Controller\Admin\Api;

use App\Controller\Base\API\Manage;
use App\Entity\Query\Get;
use App\Interceptor\ManageSession;
use App\Model\Business;
use App\Model\Config as CFG;
use App\Model\ManageLog;
use App\Service\Email;
use App\Service\Query;
use App\Service\Sms;
use App\Util\Client;
use App\Util\DalinBusiness;
use App\Util\Date;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\Relation;
use Kernel\Annotation\Inject;
use Kernel\Annotation\Interceptor;
use Kernel\Context\Interface\Request;
use Kernel\Exception\JSONException;
use Kernel\Exception\RuntimeException;
use Kernel\Waf\Filter;
use PHPMailer\PHPMailer\PHPMailer;

#[Interceptor(ManageSession::class, Interceptor::TYPE_API)]
class Config extends Manage
{

    #[Inject]
    private Query $query;

    #[Inject]
    private Sms $sms;

    #[Inject]
    private Email $email;

    /**
     * @param Request $request
     * @return array
     * @throws JSONException
     * @throws \Throwable
     */
    public function setting(Request $request): array
    {
        $post = $request->post(flags: Filter::NORMAL);
        $keys = ["closed_message", "background_mobile_url", "closed", "username_len", "user_theme", "user_mobile_theme", "user_center_theme", "background_url", "shop_name", "title", "description", "keywords", "registered_state", "registered_type", "registered_verification", "registered_phone_verification", "registered_email_verification", "login_verification", "forget_type", "notice", "trade_verification", "session_expire", "request_log", "dl_shop_layout", "dl_site_skin", "dl_vc_enabled", "dl_vc_title", "dl_vc_badge", "dl_vc_label1", "dl_vc_value1", "dl_vc_label2", "dl_vc_value2", "dl_vc_label3", "dl_vc_value3", "dl_recruit_enabled", "dl_recruit_title", "dl_recruit_subtitle", "dl_recruit_button", "dl_recruit_url", "dl_paydone_enabled", "dl_paydone_btn_text", "dl_paydone_btn_url", "dl_paydone_test_btn", "dl_contact_qq"]; //全部字段(包含大林专属及支付完成)
        $inits = ["closed", "registered_state", "registered_type", "registered_verification", "registered_phone_verification", "registered_email_verification", "login_verification", "forget_type", "trade_verification", "session_expire", "request_log"]; //需要初始化的字段

        $file = $post['logo'] ?? '/favicon.ico';
        if ($file != '/favicon.ico') {
            @copy(BASE_PATH . $file, BASE_PATH . '/favicon.ico');
            @unlink(BASE_PATH . $file);
        }
        try {
            if (isset($post['ip_get_mode'])) {
                Client::setClientMode((int)$post['ip_get_mode']);
            }

            foreach ($keys as $index => $key) {
                if (in_array($key, $inits)) {
                    if (!isset($post[$key])) {
                        $post[$key] = 0;
                    }
                }
                // 兜底保护:如果该字段未提交,保留原值不写入,避免清空
                if (!isset($post[$key])) {
                    continue;
                }
                CFG::put($key, $post[$key]);
            }
        } catch (\Exception $e) {
            throw new JSONException("保存失败，请检查原因");
        }

        if (!empty($post['user_theme'])) {
            _plugin_start($post['user_theme'], true);
        }
        ManageLog::log($this->getManage(), "修改了网站设置");
        return $this->json(200, '保存成功');
    }

    /**
     * 大林专属配置保存(独立 API,只更新 dl_ 前缀字段,不影响其他配置)
     *
     * @param Request $request
     * @return array
     * @throws JSONException
     */
    public function dalin(Request $request): array
    {
        $post = $request->post(flags: Filter::NORMAL);
        // 严格白名单:仅大林相关字段,且每个字段都校验合法值
        $allowed = [
            'dl_shop_layout' => ['classic', 'magazine', 'compact', 'gallery'],
            'dl_site_skin'   => ['dalin', 'cardpunk', 'bento', 'terminal'],
            'dl_vc_enabled'  => ['0', '1'],
            'dl_recruit_enabled' => ['0', '1'],
        ];
        // 文本字段白名单(主站「官方认证商家」卡片自定义内容 + 招商入驻 CTA + 联系方式)
        // 长度限制防止数据库被塞爆,trim 防止前后空格
        $textFields = [
            'dl_vc_title'  => 32,
            'dl_vc_badge'  => 16,
            'dl_vc_label1' => 16,
            'dl_vc_value1' => 32,
            'dl_vc_label2' => 16,
            'dl_vc_value2' => 32,
            'dl_vc_label3' => 16,
            'dl_vc_value3' => 32,
            'dl_recruit_title'    => 64,
            'dl_recruit_subtitle' => 96,
            'dl_recruit_button'   => 16,
            'dl_recruit_url'      => 200,
            // 大林新增功能 · 未开通锁定页显示给代理的"联系管理员开通"信息
            // 显示在 /user/dalin/index 锁定页 + ⑤ 节"主站工具说明"上
            // 任意文本(可写 QQ / 微信 / 电话 / 多种方式拼接), 32 字内
            'dl_contact_qq'       => 32,
        ];
        try {
            foreach ($allowed as $key => $valid) {
                if (!isset($post[$key])) continue;
                $value = (string)$post[$key];
                if (!in_array($value, $valid, true)) {
                    throw new JSONException("非法值: {$key}");
                }
                CFG::put($key, $value);
            }
            foreach ($textFields as $key => $maxLen) {
                if (!isset($post[$key])) continue;
                $value = trim((string)$post[$key]);
                if (mb_strlen($value) > $maxLen) {
                    throw new JSONException("{$key} 长度超过 {$maxLen} 个字符");
                }
                CFG::put($key, $value);
            }
        } catch (JSONException $e) {
            throw $e;
        } catch (\Exception $e) {
            throw new JSONException("保存失败:" . $e->getMessage());
        }
        ManageLog::log($this->getManage(), "修改了大林专属配置");
        return $this->json(200, '保存成功');
    }

    /**
     * 大林专属 - 分店「官方认证商家」卡片配置(每个分店一份,只有主站管理员能改)
     * 数据存在 config 表中,key 为 dl_vc_business_{business_id},value 为 JSON
     *
     * @param Request $request
     * @return array
     * @throws JSONException
     */
    public function dalinBusiness(Request $request): array
    {
        $post = $request->post(flags: Filter::NORMAL);
        $businessId = (int)($post['business_id'] ?? 0);
        if ($businessId <= 0) {
            throw new JSONException("分店 ID 无效");
        }
        // 校验该分店确实存在
        $business = Business::query()->find($businessId);
        if (!$business) {
            throw new JSONException("分店不存在");
        }

        // 字段白名单(与主站同款,但是落地存在 dl_vc_business_{id} 这个 key 里)
        $enableField = ['dl_vc_enabled' => ['0', '1']];
        $textFields = [
            'dl_vc_title'  => 32,
            'dl_vc_badge'  => 16,
            'dl_vc_label1' => 16,
            'dl_vc_value1' => 32,
            'dl_vc_label2' => 16,
            'dl_vc_value2' => 32,
            'dl_vc_label3' => 16,
            'dl_vc_value3' => 32,
        ];

        $data = [];
        try {
            foreach ($enableField as $key => $valid) {
                if (!isset($post[$key])) continue;
                $value = (string)$post[$key];
                if (!in_array($value, $valid, true)) {
                    throw new JSONException("非法值: {$key}");
                }
                $data[$key] = $value;
            }
            foreach ($textFields as $key => $maxLen) {
                if (!isset($post[$key])) continue;
                $value = trim((string)$post[$key]);
                if (mb_strlen($value) > $maxLen) {
                    throw new JSONException("{$key} 长度超过 {$maxLen} 个字符");
                }
                $data[$key] = $value;
            }
            CFG::put("dl_vc_business_" . $businessId, json_encode($data, JSON_UNESCAPED_UNICODE));
        } catch (JSONException $e) {
            throw $e;
        } catch (\Exception $e) {
            throw new JSONException("保存失败:" . $e->getMessage());
        }
        ManageLog::log($this->getManage(), "修改了分店【{$business->shop_name}】(#{$businessId}) 的认证卡片配置");
        return $this->json(200, '保存成功');
    }

    /**
     * 大林专属 - 拉取所有分店及其认证卡片当前配置(供后台管理界面渲染)
     *
     * @return array
     */
    public function dalinBusinessList(): array
    {
        $businesses = Business::query()->with(['user' => function ($r) {
            $r->select(['id', 'username', 'avatar']);
        }])->orderBy('id', 'desc')->get();

        $list = [];
        foreach ($businesses as $b) {
            $vcRaw = CFG::get("dl_vc_business_" . $b->id);
            $vcData = $vcRaw !== "" ? json_decode($vcRaw, true) : [];
            if (!is_array($vcData)) {
                $vcData = [];
            }
            $list[] = [
                'id'           => $b->id,
                'user_id'      => $b->user_id,
                'username'     => $b->user?->username ?? '',
                'shop_name'    => $b->shop_name ?: '(未设置)',
                'subdomain'    => $b->subdomain ?: '',
                'topdomain'    => $b->topdomain ?: '',
                'create_time'  => $b->create_time,
                // 大林新增功能 - 主站管理员开关 + 当前分店配置摘要
                'features_enabled' => DalinBusiness::isEnabled((int)$b->id) ? 1 : 0,
                'has_layout'       => DalinBusiness::getShopLayout((int)$b->id) !== null ? 1 : 0,
                'has_skin'         => DalinBusiness::getSiteSkin((int)$b->id)   !== null ? 1 : 0,
                'has_paydone'      => !empty(DalinBusiness::getPaydone((int)$b->id)) ? 1 : 0,
                'has_recruit'      => !empty(DalinBusiness::getRecruit((int)$b->id)) ? 1 : 0,
                // 主站 ⑤ 既有的 vc 字段保持原样
                'vc_enabled'   => $vcData['dl_vc_enabled'] ?? '',
                'vc_title'     => $vcData['dl_vc_title'] ?? '',
                'vc_badge'     => $vcData['dl_vc_badge'] ?? '',
                'vc_label1'    => $vcData['dl_vc_label1'] ?? '',
                'vc_value1'    => $vcData['dl_vc_value1'] ?? '',
                'vc_label2'    => $vcData['dl_vc_label2'] ?? '',
                'vc_value2'    => $vcData['dl_vc_value2'] ?? '',
                'vc_label3'    => $vcData['dl_vc_label3'] ?? '',
                'vc_value3'    => $vcData['dl_vc_value3'] ?? '',
                'has_custom'   => !empty($vcData),
            ];
        }
        return $this->json(200, '成功', $list);
    }

    /**
     * 大林新增功能 - 主站管理员切换某分店是否可使用"大林新增功能"
     * 关闭后该分店:
     *   1. 代理后台 /user/dalin/* 任何子页面都看到"未开通"提示
     *   2. 前台访问该分店时, dl_* 配置全部回退到主站默认 (相当于功能不存在)
     *
     * @param Request $request
     * @return array
     * @throws JSONException
     */
    public function setBusinessDalinFeatures(Request $request): array
    {
        $post = $request->post(flags: Filter::NORMAL);
        $businessId = (int)($post['business_id'] ?? 0);
        $enabled    = (string)($post['enabled'] ?? '');

        if ($businessId <= 0) {
            throw new JSONException("分店 ID 无效");
        }
        if (!in_array($enabled, ['0', '1'], true)) {
            throw new JSONException("非法值 enabled, 仅接受 0/1");
        }

        $business = Business::query()->find($businessId);
        if (!$business) {
            throw new JSONException("分店不存在");
        }

        DalinBusiness::setEnabled($businessId, $enabled === '1');

        $action = $enabled === '1' ? '开通' : '停用';
        ManageLog::log($this->getManage(), "{$action}了分店【{$business->shop_name}】(#{$businessId}) 的大林新增功能");
        return $this->json(200, ($enabled === '1' ? '已开通' : '已停用'));
    }

    /**
     * 支付完成设置(独立 API,只更新 dl_paydone_ 前缀字段,不影响其他配置)
     *
     * 三个字段:
     *  - dl_paydone_enabled  (0/1) 是否启用自定义下载按钮
     *  - dl_paydone_btn_text 按钮文字(可改名,不固定为"安装包")
     *  - dl_paydone_btn_url  点击后跳转的链接
     *
     * @param Request $request
     * @return array
     * @throws JSONException
     */
    public function payComplete(Request $request): array
    {
        $post = $request->post(flags: Filter::NORMAL);

        // 开关字段(白名单)
        $boolField = [
            'dl_paydone_enabled'  => ['0', '1'],
            'dl_paydone_test_btn' => ['0', '1'],   // 开发测试按钮(默认关,生产环境必须关)
        ];
        // 文本字段(白名单 + 长度上限,防数据库被塞爆)
        $textFields = [
            'dl_paydone_btn_text' => 32,   // 按钮文字
            'dl_paydone_btn_url'  => 500,  // 跳转链接
        ];

        try {
            foreach ($boolField as $key => $valid) {
                if (!isset($post[$key])) continue;
                $value = (string)$post[$key];
                if (!in_array($value, $valid, true)) {
                    throw new JSONException("非法值: {$key}");
                }
                CFG::put($key, $value);
            }

            foreach ($textFields as $key => $maxLen) {
                if (!isset($post[$key])) continue;
                $value = trim((string)$post[$key]);
                if (mb_strlen($value) > $maxLen) {
                    throw new JSONException("{$key} 长度超过 {$maxLen} 个字符");
                }
                // URL 字段做基础校验:必须 http/https 开头(允许空字符串清空)
                if ($key === 'dl_paydone_btn_url' && $value !== '') {
                    if (!preg_match('#^https?://#i', $value)) {
                        throw new JSONException("跳转链接必须以 http:// 或 https:// 开头");
                    }
                }
                CFG::put($key, $value);
            }
        } catch (JSONException $e) {
            throw $e;
        } catch (\Exception $e) {
            throw new JSONException("保存失败:" . $e->getMessage());
        }

        ManageLog::log($this->getManage(), "修改了支付完成设置");
        return $this->json(200, '保存成功');
    }

    /**
     * @return array
     * @throws JSONException
     */
    public function other(): array
    {
        $map = $this->request->post(flags: Filter::NORMAL);
        $keys = ["recharge_min", "commodity_recommend", "commodity_name", "recharge_max", "cname", "default_category", "callback_domain", "recharge_welfare_config", "recharge_welfare", "substation_display", "domain", "service_url", "service_qq", "cash_type_alipay", "cash_type_wechat", "cash_type_balance", "cash_cost", "cash_min", "cash_type_usdt"]; //全部字段
        $inits = ["recharge_min", "commodity_recommend", "recharge_max", "recharge_welfare", "substation_display", "cash_type_alipay", "cash_type_wechat", "cash_type_balance", "cash_cost", "cash_min", "default_category", "cash_type_usdt"]; //需要初始化的字段

        if (!empty($map['recharge_welfare_config'])) {
            $explode = explode(PHP_EOL, trim($map['recharge_welfare_config'], PHP_EOL));
            foreach ($explode as $item) {
                $def = explode("-", $item);
                if (count($def) != 2) {
                    throw new JSONException("充值赠送配置规则表达式错误");
                }
            }
        }

        try {
            foreach ($keys as $index => $key) {
                if (in_array($key, $inits)) {
                    if (!isset($map[$key])) {
                        $map[$key] = 0;
                    }
                }
                CFG::put($key, $map[$key]);
            }
        } catch (\Exception $e) {
            throw new JSONException("保存失败，请检查原因");
        }

        ManageLog::log($this->getManage(), "修改了其他设置");
        return $this->json(200, '保存成功');
    }


    /**
     * @return array
     * @throws RuntimeException
     */
    public function setSubstationDisplayList(): array
    {
        $userId = (int)$_POST['id'];
        $type = (int)$_POST['type'];
        $list = json_decode(CFG::get("substation_display_list"), true);
        if ($type == 0) {
            //添加过滤
            if (!in_array($userId, $list)) {
                $list[] = $userId;
            }
        } else {
            //解除过滤
            if (($key = array_search($userId, $list)) !== false) {
                unset($list[$key]);
                $list = array_values($list);
            }
        }

        ManageLog::log($this->getManage(), "修改了子站显示列表");
        CFG::put("substation_display_list", json_encode($list));
        return $this->json(200, "成功", $list);
    }

    /**
     * @throws JSONException
     */
    public function sms(): array
    {
        try {
            CFG::put("sms_config", json_encode($_POST));
        } catch (\Exception $e) {
            throw new JSONException("保存失败，请检查原因");
        }

        ManageLog::log($this->getManage(), "修改了短信配置");
        return $this->json(200, '保存成功');
    }

    /**
     * @throws JSONException
     */
    public function email(): array
    {
        try {
            CFG::put("email_config", json_encode($_POST));
        } catch (\Exception $e) {
            throw new JSONException("保存失败，请检查原因");
        }

        ManageLog::log($this->getManage(), "修改了邮件配置");
        return $this->json(200, '保存成功');
    }


    public function smsTest(): array
    {
        $this->sms->sendCaptcha($_POST['phone'], Sms::CAPTCHA_REGISTER);

        ManageLog::log($this->getManage(), "测试了短信发送");
        return $this->json(200, "短信发送成功");
    }

    /**
     * @return array
     * @throws JSONException
     * @throws RuntimeException
     */
    public function emailTest(): array
    {
        $shopName = CFG::get("shop_name");
        $result = $this->email->send($_POST['email'], $shopName . "-手动测试邮件", '测试邮件，发送时间：' . Date::current());
        if (!$result) {
            throw new JSONException("发送失败");
        }
        ManageLog::log($this->getManage(), "测试了邮件发送");
        return $this->json(200, "成功!");
    }

    /**
     * @return array
     */
    public function getBusiness(): array
    {
        $get = new Get(Business::class);
        $get->setPaginate((int)$this->request->post("page"), (int)$this->request->post("limit"));
        $data = $this->query->get($get, function (Builder $builder) {
            return $builder->with(['user' => function (Relation $relation) {
                $relation->with(['businessLevel'])->select(["id", "business_level", "username", "avatar"]);
            }]);
        });
        return $this->json(data: $data);
    }
}