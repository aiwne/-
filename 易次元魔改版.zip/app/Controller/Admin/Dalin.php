<?php
declare(strict_types=1);

namespace App\Controller\Admin;

use App\Controller\Base\View\Manage;
use App\Interceptor\ManageSession;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;

/**
 * 大林主题专属配置面板
 *
 * 独立于「网站设置」,把大林主题的 UI 风格、商品布局集中管理
 * 路由:/admin/dalin/index
 */
#[Interceptor(ManageSession::class)]
class Dalin extends Manage
{
    /**
     * @return string
     * @throws ViewException
     * @throws JSONException
     */
    public function index(): string
    {
        return $this->render("大林专属", "Dalin/Index.html");
    }
}
