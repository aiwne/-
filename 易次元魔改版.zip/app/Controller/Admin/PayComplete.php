<?php
declare(strict_types=1);

namespace App\Controller\Admin;

use App\Controller\Base\View\Manage;
use App\Interceptor\ManageSession;
use Kernel\Annotation\Interceptor;
use Kernel\Exception\JSONException;
use Kernel\Exception\ViewException;

/**
 * 支付完成设置
 *
 * 用户付款成功后弹出的卡密弹窗中,可显示一个"自定义下载按钮"
 * 按钮文字、跳转链接、显示/隐藏均在本页配置,全部商品共用
 *
 * 路由:/admin/payComplete/index
 */
#[Interceptor(ManageSession::class)]
class PayComplete extends Manage
{
    /**
     * @return string
     * @throws ViewException
     * @throws JSONException
     */
    public function index(): string
    {
        return $this->render("支付完成设置", "PayComplete/Index.html");
    }
}
