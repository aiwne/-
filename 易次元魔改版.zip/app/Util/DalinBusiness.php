<?php
declare(strict_types=1);

namespace App\Util;

use App\Model\Config as CFG;

/**
 * 大林新增功能 - 分店级配置读写工具
 *
 * 设计要点
 * --------
 * 1. **零数据库迁移**:复用主站已有的"按 business_id 拆 key"方案,所有分店级配置都
 *    存在全局 `config` 表里, key 模板:
 *      - 功能开关:        dl_features_enabled_business_{id}    -> "0" / "1"
 *      - 商品展示样式:    dl_layout_business_{id}              -> 字符串
 *      - UI 风格主题:    dl_skin_business_{id}                -> 字符串
 *      - 认证卡片:       dl_vc_business_{id}                  -> JSON (跟主站 ⑤ 已有键兼容)
 *      - 招商入驻 CTA:   dl_recruit_business_{id}             -> JSON
 *      - 付款后下载按钮: dl_paydone_business_{id}             -> JSON
 *
 * 2. **回退优先级 (空字段回退主站)**:任何字段空值都视为"用主站默认", 这样代理不需要
 *    一次配齐所有项就能开通使用, 渐进式配置体验更好。
 *
 * 3. **功能开关守门**: 主站管理员可以单独开关任一分店的"大林新增功能"。开关关闭时,
 *    无论代理分店字段如何配置, 前台一律使用主站默认值 (相当于功能未购买)。
 */
class DalinBusiness
{
    // ----- 单值 key (每个 key 存一个标量) -----
    private const KEY_FEATURES_ENABLED = 'dl_features_enabled_business_';
    private const KEY_SHOP_LAYOUT      = 'dl_layout_business_';
    private const KEY_SITE_SKIN        = 'dl_skin_business_';

    // ----- JSON key (每个 key 存一组字段) -----
    private const KEY_VC      = 'dl_vc_business_';        // 兼容主站 ⑤ 已有
    private const KEY_RECRUIT = 'dl_recruit_business_';
    private const KEY_PAYDONE = 'dl_paydone_business_';

    // ----- 各分组的合法字段白名单 -----
    public const VC_FIELDS = [
        'dl_vc_enabled' => ['0', '1'],
        'dl_vc_title'   => 32,
        'dl_vc_badge'   => 16,
        'dl_vc_label1'  => 16,
        'dl_vc_value1'  => 32,
        'dl_vc_label2'  => 16,
        'dl_vc_value2'  => 32,
        'dl_vc_label3'  => 16,
        'dl_vc_value3'  => 32,
    ];

    public const RECRUIT_FIELDS = [
        'dl_recruit_enabled'  => ['0', '1'],
        'dl_recruit_title'    => 32,
        'dl_recruit_subtitle' => 64,
        'dl_recruit_button'   => 16,
        'dl_recruit_url'      => 255,
    ];

    public const PAYDONE_FIELDS = [
        'dl_paydone_enabled'  => ['0', '1'],
        'dl_paydone_btn_text' => 32,
        'dl_paydone_btn_url'  => 500,
    ];

    public const SHOP_LAYOUTS = ['classic', 'magazine', 'compact', 'gallery'];
    public const SITE_SKINS   = ['dalin', 'cardpunk', 'bento', 'terminal'];

    /**
     * 该分店是否已开通"大林新增功能"
     */
    public static function isEnabled(int $businessId): bool
    {
        if ($businessId <= 0) return false;
        $v = (string)CFG::get(self::KEY_FEATURES_ENABLED . $businessId);
        return $v === '1';
    }

    /**
     * 设置开关 (主站管理员用)
     */
    public static function setEnabled(int $businessId, bool $enabled): void
    {
        CFG::put(self::KEY_FEATURES_ENABLED . $businessId, $enabled ? '1' : '0');
    }

    // ============= 单值字段 =============

    public static function getShopLayout(int $businessId): ?string
    {
        $v = (string)CFG::get(self::KEY_SHOP_LAYOUT . $businessId);
        return $v !== '' ? $v : null;
    }

    public static function setShopLayout(int $businessId, string $value): void
    {
        CFG::put(self::KEY_SHOP_LAYOUT . $businessId, $value);
    }

    public static function getSiteSkin(int $businessId): ?string
    {
        $v = (string)CFG::get(self::KEY_SITE_SKIN . $businessId);
        return $v !== '' ? $v : null;
    }

    public static function setSiteSkin(int $businessId, string $value): void
    {
        CFG::put(self::KEY_SITE_SKIN . $businessId, $value);
    }

    // ============= JSON 字段组 =============

    /**
     * 通用读取 JSON 配置组, 返回数组 (空值返回 [])
     */
    private static function readJson(string $keyPrefix, int $businessId): array
    {
        $raw = (string)CFG::get($keyPrefix . $businessId);
        if ($raw === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    /**
     * 通用写入 JSON 配置组
     */
    private static function writeJson(string $keyPrefix, int $businessId, array $data): void
    {
        CFG::put($keyPrefix . $businessId, json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    public static function getVc(int $businessId): array      { return self::readJson(self::KEY_VC, $businessId); }
    public static function setVc(int $businessId, array $d): void { self::writeJson(self::KEY_VC, $businessId, $d); }

    public static function getRecruit(int $businessId): array { return self::readJson(self::KEY_RECRUIT, $businessId); }
    public static function setRecruit(int $businessId, array $d): void { self::writeJson(self::KEY_RECRUIT, $businessId, $d); }

    public static function getPaydone(int $businessId): array { return self::readJson(self::KEY_PAYDONE, $businessId); }
    public static function setPaydone(int $businessId, array $d): void { self::writeJson(self::KEY_PAYDONE, $businessId, $d); }

    /**
     * 获取该分店的所有 dl_* 配置摘要 (供 admin 列表 / 代理后台渲染)
     *
     * @return array{
     *   features_enabled: bool,
     *   layout: ?string, skin: ?string,
     *   vc: array, recruit: array, paydone: array
     * }
     */
    public static function getAll(int $businessId): array
    {
        return [
            'features_enabled' => self::isEnabled($businessId),
            'layout'           => self::getShopLayout($businessId),
            'skin'             => self::getSiteSkin($businessId),
            'vc'               => self::getVc($businessId),
            'recruit'          => self::getRecruit($businessId),
            'paydone'          => self::getPaydone($businessId),
        ];
    }

    /**
     * 解析输入字段, 按白名单过滤+长度校验, 返回过滤后的有效字段
     *
     * @param array $post   原始 $_POST
     * @param array $whitelist  类似 self::VC_FIELDS / RECRUIT_FIELDS / PAYDONE_FIELDS
     * @return array  仅含合法字段的关联数组
     * @throws \Exception 字段长度超限或值不合法
     */
    public static function filterFields(array $post, array $whitelist): array
    {
        $out = [];
        foreach ($whitelist as $field => $rule) {
            if (!isset($post[$field])) continue;
            $value = $post[$field];

            if (is_array($rule)) {
                // 枚举字段
                $strVal = (string)$value;
                if (!in_array($strVal, $rule, true)) {
                    throw new \Exception("非法值: {$field}");
                }
                $out[$field] = $strVal;
            } else {
                // 长度限制字段
                $strVal = trim((string)$value);
                if (mb_strlen($strVal) > (int)$rule) {
                    throw new \Exception("{$field} 长度不能超过 {$rule} 个字符");
                }
                $out[$field] = $strVal;
            }
        }
        return $out;
    }

    /**
     * 给定一个 business_id 和主站全局配置, 计算应用 fallback 后的最终 dl_* 配置
     *
     * 逻辑:
     *   - 若 features_enabled = 0 -> 不动 layout/skin/paydone (回退主站默认, 等同于功能未购买)
     *   - 若 features_enabled = 1 -> 分店字段非空覆盖, 空字段回退主站
     *
     * 注意: dl_vc_* (认证卡片) 由调用方 (Base/View/User.php) 单独处理,
     * **永远生效, 不受 features_enabled 开关控制**。原因:
     *   1. 主站 ⑤ 的"代理分店认证管理"是主站管理员的工具, 不依赖代理付费
     *   2. 已有分店配置不能因为加了开关被破坏
     *   3. 代理只在开通后能自己改 vc, 但显示永远生效
     *
     * dl_recruit_* 在分店访问时不论代理是否设置, 业务上都不显示
     * (Base/View/User.php 已经强制 enabled=0); 此函数不动 recruit。
     *
     * @param array $globalConfig  当前 $data['config'] 数组
     * @param int   $businessId
     * @return array  应用 fallback 后的新数组
     */
    public static function applyFallback(array $globalConfig, int $businessId): array
    {
        if (!self::isEnabled($businessId)) {
            return $globalConfig;
        }

        // 1. 商品展示样式
        $layout = self::getShopLayout($businessId);
        if ($layout !== null && $layout !== '') {
            $globalConfig['dl_shop_layout'] = $layout;
        }

        // 2. UI 风格主题
        $skin = self::getSiteSkin($businessId);
        if ($skin !== null && $skin !== '') {
            $globalConfig['dl_site_skin'] = $skin;
        }

        // 3. 付款后下载按钮 (3 字段)
        $paydone = self::getPaydone($businessId);
        if (!empty($paydone)) {
            foreach (self::PAYDONE_FIELDS as $f => $_) {
                if (array_key_exists($f, $paydone) && $paydone[$f] !== '') {
                    $globalConfig[$f] = $paydone[$f];
                }
            }
        }

        return $globalConfig;
    }
}
