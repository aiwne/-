<?php
declare (strict_types=1);

return [
    'version' => '3.4.9'
]; 