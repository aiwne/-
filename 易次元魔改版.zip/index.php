<?php
declare(strict_types=1);
@include_once __DIR__ . '/includes/autoload.php';
const DEBUG = false;
require("kernel/Kernel.php");
