<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理 - 导航页</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

    <div class="bg-no-video"></div>

    <div class="page-layer">
        <div class="container">

            <!-- Login -->
            <div id="loginView" class="login-box neu-card">
                <div class="login-icon neu-inset">
                    <i class="fa-solid fa-lock"></i>
                </div>
                <h2>后台管理</h2>
                <p>请输入管理密码</p>
                <div class="form-group">
                    <input type="password" id="loginPassword" class="form-input neu-inset" placeholder="密码" autofocus>
                </div>
                <button class="form-submit" onclick="doLogin()">登 录</button>
            </div>

            <!-- Admin Panel -->
            <div id="adminView" style="display:none">

                <div class="admin-header neu-card">
                    <h2><i class="fa-solid fa-sliders"></i> 导航管理</h2>
                    <div class="admin-header-actions">
                        <a href="index.php" class="neu-btn neu-action-btn neu-action-ghost"><i class="fa-solid fa-eye"></i> 查看</a>
                        <button class="neu-btn neu-action-btn neu-action-ghost" onclick="doLogout()"><i class="fa-solid fa-right-from-bracket"></i> 退出</button>
                    </div>
                </div>

                <!-- Buttons List -->
                <div class="btn-list neu-card" id="btnList">
                    <div class="empty-state">
                        <i class="fa-solid fa-spinner fa-spin"></i>
                        <p>加载中...</p>
                    </div>
                </div>

                <!-- Add Button -->
                <div class="add-btn-wrap">
                    <button class="neu-btn neu-action-btn neu-action-primary" onclick="openAddModal()"><i class="fa-solid fa-plus"></i> 添加按钮</button>
                </div>

                <!-- Settings -->
                <div class="settings-section neu-card">
                    <h3><i class="fa-solid fa-gear"></i> 站点设置</h3>
                    <div class="form-group">
                        <label>站点标题</label>
                        <input type="text" id="settingTitle" class="form-input neu-inset" placeholder="站点标题">
                    </div>
                    <div class="form-group">
                        <label>站点描述</label>
                        <input type="text" id="settingDesc" class="form-input neu-inset" placeholder="站点描述">
                    </div>
                    <div class="form-group">
                        <label>搜索引擎</label>
                        <select id="settingEngine" class="form-input neu-inset">
                            <option value="baidu">百度</option>
                            <option value="google">Google</option>
                            <option value="bing">Bing</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Logo 图片</label>
                        <div class="image-upload-area" id="logoUploadArea">
                            <i class="fa-solid fa-image"></i>
                            <p>点击或拖拽上传 Logo <br><span>支持 JPG / PNG / SVG / WebP</span></p>
                            <input type="file" id="logoFileInput" accept="image/jpeg,image/png,image/svg+xml,image/webp" style="display:none">
                        </div>
                        <div class="image-preview" id="logoPreview" style="display:none">
                            <img id="logoPreviewImg" src="" alt="Logo">
                            <button class="image-remove" id="logoRemoveBtn" title="移除 Logo"><i class="fa-solid fa-xmark"></i></button>
                        </div>
                        <div class="image-status" id="logoStatus"></div>
                    </div>
                    <div class="form-group">
                        <label>页面背景视频</label>
                        <div class="video-upload-area" id="videoUploadArea">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                            <p>点击或拖拽上传视频 <br><span>支持 MP4 / WebM</span></p>
                            <input type="file" id="videoFileInput" accept="video/mp4,video/webm" style="display:none">
                        </div>
                        <div class="video-preview" id="videoPreview" style="display:none">
                            <video id="previewVideo" muted loop playsinline></video>
                            <button class="video-remove" id="videoRemoveBtn" title="移除视频"><i class="fa-solid fa-xmark"></i></button>
                        </div>
                        <div class="video-status" id="videoStatus"></div>
                    </div>
                    <button class="form-submit" onclick="saveSettings()" style="width:auto; display:inline-flex; align-items:center; gap:8px;">
                        <i class="fa-solid fa-check"></i> 保存设置
                    </button>
                </div>

                <div class="settings-section neu-card" style="margin-top:20px;">
                    <h3><i class="fa-solid fa-lock"></i> 修改密码</h3>
                    <div class="form-group">
                        <label>当前密码</label>
                        <input type="password" id="oldPassword" class="form-input neu-inset" placeholder="当前密码">
                    </div>
                    <div class="form-group">
                        <label>新密码</label>
                        <input type="password" id="newPassword" class="form-input neu-inset" placeholder="新密码（至少4位）">
                    </div>
                    <div class="form-group">
                        <label>确认新密码</label>
                        <input type="password" id="confirmPassword" class="form-input neu-inset" placeholder="再次输入新密码">
                    </div>
                    <button class="form-submit" onclick="changePassword()" style="width:auto; display:inline-flex; align-items:center; gap:8px;">
                        <i class="fa-solid fa-key"></i> 修改密码
                    </button>
                </div>

            </div>
        </div>
    </div>

    <!-- Add/Edit Modal -->
    <div class="modal-overlay" id="modalOverlay">
        <div class="modal neu-card">
            <h3 id="modalTitle">添加按钮</h3>
            <input type="hidden" id="editId">
            <div class="form-group">
                <label>按钮名称</label>
                <input type="text" id="inputTitle" class="form-input neu-inset" placeholder="例如: 百度">
            </div>
            <div class="form-group">
                <label>链接地址</label>
                <input type="text" id="inputUrl" class="form-input neu-inset" placeholder="例如: https://www.baidu.com">
            </div>
            <div class="form-group">
                <label>图标</label>
                <div class="icon-mode-tabs">
                    <button class="icon-tab active" onclick="switchIconMode('image')" id="tabImage"><i class="fa-solid fa-image"></i> 图片</button>
                    <button class="icon-tab" onclick="switchIconMode('fa')" id="tabFa"><i class="fa-solid fa-font"></i> Font Awesome</button>
                </div>
                <div id="iconImageMode">
                    <div class="image-upload-area" id="iconUploadArea" style="padding:18px;">
                        <i class="fa-solid fa-cloud-arrow-up" style="font-size:1.4em;"></i>
                        <p style="font-size:0.78em;">点击或拖拽上传图标 <br><span>支持 JPG / PNG / SVG / WebP，≤2MB</span></p>
                        <input type="file" id="iconFileInput" accept="image/jpeg,image/png,image/svg+xml,image/webp" style="display:none">
                    </div>
                    <div class="image-preview" id="iconPreview" style="display:none; margin-top:10px;">
                        <img id="iconPreviewImg" src="" alt="Icon">
                        <button class="image-remove" id="iconRemoveBtn" title="移除图标"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                </div>
                <div id="iconFAMode" style="display:none;">
                    <input type="text" id="inputIcon" class="form-input neu-inset" placeholder="例如: fa-solid fa-magnifying-glass">
                    <div class="icon-hint">输入 FA class，如 <code>fa-brands fa-github</code>。查看全部: <a href="https://fontawesome.com/search" target="_blank">fontawesome.com</a></div>
                </div>
            </div>
            <div class="modal-actions">
                <button class="neu-btn neu-action-btn neu-action-ghost" onclick="closeModal()">取消</button>
                <button class="neu-btn neu-action-btn neu-action-primary" onclick="saveBtn()"><i class="fa-solid fa-check"></i> 保存</button>
            </div>
        </div>
    </div>

    <!-- Delete Confirm Modal -->
    <div class="modal-overlay" id="deleteOverlay">
        <div class="modal neu-card">
            <h3>确认删除</h3>
            <p style="color:var(--text-dim); font-size:0.88em; margin-bottom:4px;">
                确定要删除 "<span id="deleteName" style="color:var(--text-secondary)"></span>" 吗？
            </p>
            <input type="hidden" id="deleteId">
            <div class="modal-actions">
                <button class="neu-btn neu-action-btn neu-action-ghost" onclick="closeDeleteModal()">取消</button>
                <button class="neu-btn neu-action-btn neu-action-danger" onclick="confirmDelete()" style="flex:1; justify-content:center; padding:12px;">
                    <i class="fa-solid fa-trash"></i> 删除
                </button>
            </div>
        </div>
    </div>

<script>
(function() {
    let buttons = [];
    let currentBgVideo = '';
    let currentLogo = '';
    let currentIconFile = '';
    let iconMode = 'image';

    function esc(str) {
        const d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    async function api(action, method, body) {
        const opts = { method, headers: { 'Content-Type': 'application/json' } };
        if (body) opts.body = JSON.stringify(body);
        const res = await fetch('api.php?action=' + action, opts);
        return await res.json();
    }

    function showToast(msg, isError) {
        const t = document.createElement('div');
        t.className = 'toast' + (isError ? ' error' : '');
        t.textContent = msg;
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 2500);
    }

    // ---- Login ----
    window.doLogin = async function() {
        const pwd = document.getElementById('loginPassword').value.trim();
        if (!pwd) return;
        const data = await api('login', 'POST', { password: pwd });
        if (data.success) {
            document.getElementById('loginView').style.display = 'none';
            document.getElementById('adminView').style.display = 'block';
            loadAdmin();
        } else {
            showToast(data.error || '密码错误', true);
        }
    };
    document.getElementById('loginPassword').addEventListener('keydown', e => {
        if (e.key === 'Enter') doLogin();
    });

    window.doLogout = async function() {
        await api('logout', 'POST');
        location.reload();
    };

    // ---- Load ----
    async function loadAdmin() {
        const data = await api('admin_get', 'GET');
        if (data.error) {
            document.getElementById('loginView').style.display = '';
            document.getElementById('adminView').style.display = 'none';
            return;
        }
        buttons = data.buttons || [];
        renderButtons();
        if (data.settings) {
            document.getElementById('settingTitle').value = data.settings.site_title || '';
            document.getElementById('settingDesc').value = data.settings.site_desc || '';
            document.getElementById('settingEngine').value = data.settings.search_engine || 'baidu';
            if (data.settings.bg_video) {
                currentBgVideo = data.settings.bg_video;
                showVideoPreview('previewVideo', 'videoPreview', 'videoUploadArea', 'videoStatus', currentBgVideo);
            }
            if (data.settings.logo) {
                currentLogo = data.settings.logo;
                showLogoPreview(currentLogo);
            }
        }
    }

    function renderButtons() {
        const list = document.getElementById('btnList');
        if (!buttons.length) {
            list.innerHTML = '<div class="empty-state"><i class="fa-solid fa-link-slash"></i><p>暂无按钮，点击下方添加</p></div>';
            return;
        }
        list.innerHTML = buttons.map((b, i) => {
            const iconHtml = b.icon.startsWith('uploads/')
                ? `<img src="${esc(b.icon)}" alt="" style="width:22px;height:22px;border-radius:6px;object-fit:cover;">`
                : `<i class="${esc(b.icon)}"></i>`;
            return `
            <div class="btn-item" draggable="true" data-id="${b.id}" data-index="${i}">
                <div class="btn-item-icon">${iconHtml}</div>
                <div class="btn-item-info">
                    <div class="btn-item-name">${esc(b.title)}</div>
                    <div class="btn-item-url">${esc(b.url)}</div>
                </div>
                <div class="btn-item-actions">
                    <button class="neu-btn neu-action-btn neu-action-primary" onclick="openEditModal(${b.id})" title="编辑" style="padding:7px 12px; font-size:0.78em;"><i class="fa-solid fa-pen"></i></button>
                    <button class="neu-btn neu-action-btn neu-action-danger" onclick="openDeleteModal(${b.id}, '${esc(b.title).replace(/'/g, "\\'")}')" title="删除" style="padding:7px 12px; font-size:0.78em;"><i class="fa-solid fa-trash"></i></button>
                </div>
            </div>`;
        }).join('');
        initDrag();
    }

    // ---- Drag & Drop ----
    function initDrag() {
        const items = document.querySelectorAll('.btn-item');
        let dragItem = null;
        items.forEach(item => {
            item.addEventListener('dragstart', e => {
                dragItem = item;
                item.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            });
            item.addEventListener('dragend', () => {
                item.classList.remove('dragging');
                dragItem = null;
                items.forEach(i => i.classList.remove('drag-over'));
            });
            item.addEventListener('dragover', e => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                if (dragItem && dragItem !== item) item.classList.add('drag-over');
            });
            item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
            item.addEventListener('drop', async e => {
                e.preventDefault();
                item.classList.remove('drag-over');
                if (!dragItem || dragItem === item) return;
                const fromIdx = parseInt(dragItem.dataset.index);
                const toIdx = parseInt(item.dataset.index);
                const moved = buttons.splice(fromIdx, 1)[0];
                buttons.splice(toIdx, 0, moved);
                renderButtons();
                await api('sort', 'POST', { order: buttons.map(b => b.id) });
            });
        });
    }

    // ---- Generic video upload helper ----
    function showVideoPreview(videoId, previewId, areaId, statusId, filename) {
        document.getElementById(videoId).src = 'uploads/' + filename;
        document.getElementById(videoId).load();
        document.getElementById(previewId).style.display = 'block';
        document.getElementById(areaId).style.display = 'none';
        document.getElementById(statusId).innerHTML = '<i class="fa-solid fa-circle-check" style="color:var(--success)"></i> 当前: ' + esc(filename);
    }

    // ---- Page background video ----
    function clearVideoPreview() {
        document.getElementById('previewVideo').src = '';
        document.getElementById('videoPreview').style.display = 'none';
        document.getElementById('videoUploadArea').style.display = '';
        document.getElementById('videoStatus').innerHTML = '';
        currentBgVideo = '';
    }

    function setupVideoUpload(areaId, inputId, removeBtnId, statusId, previewId, videoId, onUpload) {
        const area = document.getElementById(areaId);
        const input = document.getElementById(inputId);
        area.addEventListener('click', () => input.click());
        area.addEventListener('dragover', e => { e.preventDefault(); area.classList.add('dragover'); });
        area.addEventListener('dragleave', () => area.classList.remove('dragover'));
        area.addEventListener('drop', e => {
            e.preventDefault();
            area.classList.remove('dragover');
            if (e.dataTransfer.files.length) onUpload(e.dataTransfer.files[0]);
        });
        input.addEventListener('change', () => { if (input.files.length) onUpload(input.files[0]); });
        document.getElementById(removeBtnId).addEventListener('click', () => {
            document.getElementById(videoId).src = '';
            document.getElementById(previewId).style.display = 'none';
            area.style.display = '';
            document.getElementById(statusId).innerHTML = '';
            if (areaId === 'videoUploadArea') currentBgVideo = '';
        });
    }

    async function handleVideoFile(file, statusId, onSuccess) {
        if (!file.type.match(/video\/(mp4|webm)/)) {
            showToast('仅支持 MP4 和 WebM 格式', true);
            return;
        }
        if (file.size > 100 * 1024 * 1024) {
            showToast('文件不能超过 100MB', true);
            return;
        }
        document.getElementById(statusId).innerHTML = '<i class="fa-solid fa-spinner fa-spin" style="color:var(--accent)"></i> 上传中...';
        const formData = new FormData();
        formData.append('video', file);
        try {
            const res = await fetch('api.php?action=upload_video', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.filename) {
                onSuccess(data.filename);
                showToast('上传成功');
            } else {
                showToast(data.error || '上传失败', true);
                document.getElementById(statusId).innerHTML = '';
            }
        } catch (e) {
            showToast('上传失败', true);
            document.getElementById(statusId).innerHTML = '';
        }
    }

    setupVideoUpload('videoUploadArea', 'videoFileInput', 'videoRemoveBtn', 'videoStatus', 'videoPreview', 'previewVideo',
        file => handleVideoFile(file, 'videoStatus', fn => { currentBgVideo = fn; showVideoPreview('previewVideo', 'videoPreview', 'videoUploadArea', 'videoStatus', fn); })
    );

    // ---- Logo Upload ----
    function showLogoPreview(filename) {
        document.getElementById('logoPreviewImg').src = 'uploads/' + filename;
        document.getElementById('logoPreview').style.display = 'inline-block';
        document.getElementById('logoUploadArea').style.display = 'none';
        document.getElementById('logoStatus').innerHTML = '<i class="fa-solid fa-circle-check" style="color:var(--success)"></i> 当前: ' + esc(filename);
    }

    const logoArea = document.getElementById('logoUploadArea');
    const logoInput = document.getElementById('logoFileInput');
    logoArea.addEventListener('click', () => logoInput.click());
    logoArea.addEventListener('dragover', e => { e.preventDefault(); logoArea.classList.add('dragover'); });
    logoArea.addEventListener('dragleave', () => logoArea.classList.remove('dragover'));
    logoArea.addEventListener('drop', e => {
        e.preventDefault();
        logoArea.classList.remove('dragover');
        if (e.dataTransfer.files.length) handleLogoFile(e.dataTransfer.files[0]);
    });
    logoInput.addEventListener('change', () => { if (logoInput.files.length) handleLogoFile(logoInput.files[0]); });
    document.getElementById('logoRemoveBtn').addEventListener('click', () => {
        document.getElementById('logoPreviewImg').src = '';
        document.getElementById('logoPreview').style.display = 'none';
        logoArea.style.display = '';
        document.getElementById('logoStatus').innerHTML = '';
        currentLogo = '';
    });

    async function handleLogoFile(file) {
        if (!file.type.match(/image\/(jpeg|png|svg\+xml|webp)/)) {
            showToast('仅支持 JPG / PNG / SVG / WebP', true);
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            showToast('文件不能超过 5MB', true);
            return;
        }
        document.getElementById('logoStatus').innerHTML = '<i class="fa-solid fa-spinner fa-spin" style="color:var(--accent)"></i> 上传中...';
        const formData = new FormData();
        formData.append('image', file);
        try {
            const res = await fetch('api.php?action=upload_image', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.filename) {
                currentLogo = data.filename;
                showLogoPreview(data.filename);
                showToast('上传成功');
            } else {
                showToast(data.error || '上传失败', true);
                document.getElementById('logoStatus').innerHTML = '';
            }
        } catch (e) {
            showToast('上传失败', true);
            document.getElementById('logoStatus').innerHTML = '';
        }
    }

    // ---- Icon mode & upload ----
    window.switchIconMode = function(mode) {
        iconMode = mode;
        document.getElementById('tabImage').classList.toggle('active', mode === 'image');
        document.getElementById('tabFa').classList.toggle('active', mode === 'fa');
        document.getElementById('iconImageMode').style.display = mode === 'image' ? '' : 'none';
        document.getElementById('iconFAMode').style.display = mode === 'fa' ? '' : 'none';
    };

    const iconArea = document.getElementById('iconUploadArea');
    const iconInput = document.getElementById('iconFileInput');
    iconArea.addEventListener('click', () => iconInput.click());
    iconArea.addEventListener('dragover', e => { e.preventDefault(); iconArea.classList.add('dragover'); });
    iconArea.addEventListener('dragleave', () => iconArea.classList.remove('dragover'));
    iconArea.addEventListener('drop', e => {
        e.preventDefault();
        iconArea.classList.remove('dragover');
        if (e.dataTransfer.files.length) handleIconFile(e.dataTransfer.files[0]);
    });
    iconInput.addEventListener('change', () => { if (iconInput.files.length) handleIconFile(iconInput.files[0]); });
    document.getElementById('iconRemoveBtn').addEventListener('click', () => {
        document.getElementById('iconPreviewImg').src = '';
        document.getElementById('iconPreview').style.display = 'none';
        iconArea.style.display = '';
        currentIconFile = '';
    });

    async function handleIconFile(file) {
        if (!file.type.match(/image\/(jpeg|png|svg\+xml|webp)/)) {
            showToast('仅支持 JPG / PNG / SVG / WebP', true);
            return;
        }
        if (file.size > 2 * 1024 * 1024) {
            showToast('文件不能超过 2MB', true);
            return;
        }
        const formData = new FormData();
        formData.append('icon', file);
        try {
            const res = await fetch('api.php?action=upload_icon', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.filename) {
                currentIconFile = 'uploads/' + data.filename;
                document.getElementById('iconPreviewImg').src = currentIconFile;
                document.getElementById('iconPreview').style.display = 'inline-block';
                iconArea.style.display = 'none';
                showToast('上传成功');
            } else {
                showToast(data.error || '上传失败', true);
            }
        } catch (e) {
            showToast('上传失败', true);
        }
    }

    // ---- Modals ----
    window.openAddModal = function() {
        document.getElementById('modalTitle').textContent = '添加按钮';
        document.getElementById('editId').value = '';
        document.getElementById('inputTitle').value = '';
        document.getElementById('inputUrl').value = '';
        document.getElementById('inputIcon').value = '';
        currentIconFile = '';
        document.getElementById('iconPreview').style.display = 'none';
        document.getElementById('iconUploadArea').style.display = '';
        switchIconMode('image');
        document.getElementById('modalOverlay').classList.add('active');
        setTimeout(() => document.getElementById('inputTitle').focus(), 100);
    };

    window.openEditModal = function(id) {
        const btn = buttons.find(b => b.id == id);
        if (!btn) return;
        document.getElementById('modalTitle').textContent = '编辑按钮';
        document.getElementById('editId').value = btn.id;
        document.getElementById('inputTitle').value = btn.title;
        document.getElementById('inputUrl').value = btn.url;
        currentIconFile = '';
        if (btn.icon && btn.icon.startsWith('uploads/')) {
            currentIconFile = btn.icon;
            document.getElementById('iconPreviewImg').src = btn.icon;
            document.getElementById('iconPreview').style.display = 'inline-block';
            document.getElementById('iconUploadArea').style.display = 'none';
            document.getElementById('inputIcon').value = '';
            switchIconMode('image');
        } else {
            document.getElementById('inputIcon').value = btn.icon;
            document.getElementById('iconPreview').style.display = 'none';
            document.getElementById('iconUploadArea').style.display = '';
            switchIconMode('fa');
        }
        document.getElementById('modalOverlay').classList.add('active');
        setTimeout(() => document.getElementById('inputTitle').focus(), 100);
    };

    window.closeModal = function() {
        document.getElementById('modalOverlay').classList.remove('active');
    };

    window.saveBtn = async function() {
        const id = document.getElementById('editId').value;
        const title = document.getElementById('inputTitle').value.trim();
        const url = document.getElementById('inputUrl').value.trim();
        const icon = iconMode === 'image' ? currentIconFile : document.getElementById('inputIcon').value.trim();
        if (!title || !url) { showToast('名称和链接不能为空', true); return; }
        if (!icon) { showToast('请选择图标', true); return; }
        let data;
        if (id) {
            data = await api('update', 'POST', { id: parseInt(id), title, url, icon });
        } else {
            data = await api('add', 'POST', { title, url, icon });
        }
        if (data.success) {
            showToast(id ? '已更新' : '已添加');
            closeModal();
            loadAdmin();
        } else {
            showToast(data.error || '操作失败', true);
        }
    };

    window.openDeleteModal = function(id, name) {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteName').textContent = name;
        document.getElementById('deleteOverlay').classList.add('active');
    };

    window.closeDeleteModal = function() {
        document.getElementById('deleteOverlay').classList.remove('active');
    };

    window.confirmDelete = async function() {
        const id = parseInt(document.getElementById('deleteId').value);
        const data = await api('delete', 'POST', { id });
        if (data.success) {
            showToast('已删除');
            closeDeleteModal();
            loadAdmin();
        } else {
            showToast(data.error || '删除失败', true);
        }
    };

    window.saveSettings = async function() {
        const title = document.getElementById('settingTitle').value.trim();
        const desc = document.getElementById('settingDesc').value.trim();
        const engine = document.getElementById('settingEngine').value;
        const payload = {
            site_title: title,
            site_desc: desc,
            search_engine: engine,
            bg_video: currentBgVideo,
            logo: currentLogo
        };
        const data = await api('update_settings', 'POST', payload);
        if (data.success) {
            showToast('设置已保存');
        } else {
            showToast(data.error || '保存失败', true);
        }
    };

    window.changePassword = async function() {
        const oldPw = document.getElementById('oldPassword').value;
        const newPw = document.getElementById('newPassword').value;
        const confirmPw = document.getElementById('confirmPassword').value;
        if (!oldPw || !newPw) { showToast('请填写密码', true); return; }
        if (newPw !== confirmPw) { showToast('两次输入的新密码不一致', true); return; }
        if (newPw.length < 4) { showToast('新密码至少4位', true); return; }
        const data = await api('change_password', 'POST', { old_password: oldPw, new_password: newPw });
        if (data.success) {
            showToast('密码已修改');
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        } else {
            showToast(data.error || '修改失败', true);
        }
    };

    document.getElementById('modalOverlay').addEventListener('click', e => {
        if (e.target === e.currentTarget) closeModal();
    });
    document.getElementById('deleteOverlay').addEventListener('click', e => {
        if (e.target === e.currentTarget) closeDeleteModal();
    });

    // ---- Auto check session ----
    (async function() {
        try {
            const session = await api('check_session', 'GET');
            if (!session.logged_in) return;
            const data = await api('admin_get', 'GET');
            if (data.buttons !== undefined) {
                document.getElementById('loginView').style.display = 'none';
                document.getElementById('adminView').style.display = 'block';
                buttons = data.buttons;
                renderButtons();
                if (data.settings) {
                    document.getElementById('settingTitle').value = data.settings.site_title || '';
                    document.getElementById('settingDesc').value = data.settings.site_desc || '';
                    document.getElementById('settingEngine').value = data.settings.search_engine || 'baidu';
                    if (data.settings.bg_video) {
                        currentBgVideo = data.settings.bg_video;
                        showVideoPreview('previewVideo', 'videoPreview', 'videoUploadArea', 'videoStatus', currentBgVideo);
                    }
                    if (data.settings.logo) {
                        currentLogo = data.settings.logo;
                        showLogoPreview(currentLogo);
                    }
                }
            }
        } catch(e) {}
    })();
})();
</script>
</body>
</html>
