<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

define('DB_PATH', __DIR__ . '/nav.db');
define('DEFAULT_PASSWORD', 'admin123');
define('UPLOAD_DIR', __DIR__ . '/uploads');

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

function getDB() {
    $db = new SQLite3(DB_PATH);
    $db->enableExceptions(true);
    $db->exec('PRAGMA journal_mode=WAL');
    return $db;
}

function initDB($db) {
    $db->exec('CREATE TABLE IF NOT EXISTS buttons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        url TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT \'\',
        sort_order INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime(\'now\',\'localtime\'))
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )');

    $count = $db->querySingle('SELECT COUNT(*) FROM buttons');
    if ($count == 0) {
        $defaults = [
            ['百度', 'https://www.baidu.com', 'fa-solid fa-magnifying-glass'],
            ['GitHub', 'https://github.com', 'fa-brands fa-github'],
            ['Google', 'https://www.google.com', 'fa-brands fa-google'],
            ['ChatGPT', 'https://chat.openai.com', 'fa-solid fa-robot'],
        ];
        $stmt = $db->prepare('INSERT INTO buttons (title, url, icon, sort_order) VALUES (:title, :url, :icon, :order)');
        foreach ($defaults as $i => $d) {
            $stmt->bindValue(':title', $d[0], SQLITE3_TEXT);
            $stmt->bindValue(':url', $d[1], SQLITE3_TEXT);
            $stmt->bindValue(':icon', $d[2], SQLITE3_TEXT);
            $stmt->bindValue(':order', $i, SQLITE3_INTEGER);
            $stmt->execute();
            $stmt->reset();
        }
    }

    $siteTitle = $db->querySingle("SELECT value FROM settings WHERE key='site_title'");
    if (!$siteTitle) {
        $db->exec("INSERT INTO settings (key, value) VALUES ('site_title', '我的导航')");
        $db->exec("INSERT INTO settings (key, value) VALUES ('site_desc', '常用网站快捷入口')");
        $db->exec("INSERT INTO settings (key, value) VALUES ('search_engine', 'baidu')");
    }
}

try {
    $db = getDB();
    initDB($db);
} catch (Exception $e) {
    echo json_encode(['error' => '数据库初始化失败: ' . $e->getMessage()]);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function isLoggedIn() {
    return !empty($_SESSION['admin_logged_in']);
}

function getAdminPassword($db) {
    $pw = $db->querySingle("SELECT value FROM settings WHERE key='admin_password'");
    return $pw ?: DEFAULT_PASSWORD;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

switch ($action) {
    case 'check_session':
        jsonResponse(['logged_in' => isLoggedIn()]);
        break;

    case 'admin_get':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        $result = $db->query('SELECT * FROM buttons ORDER BY sort_order ASC, id ASC');
        $buttons = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $buttons[] = $row;
        }
        $settings = [];
        $res = $db->query('SELECT * FROM settings');
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $settings[$row['key']] = $row['value'];
        }
        jsonResponse(['buttons' => $buttons, 'settings' => $settings]);
        break;

    case 'list':
        $result = $db->query('SELECT * FROM buttons ORDER BY sort_order ASC, id ASC');
        $buttons = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $buttons[] = $row;
        }
        jsonResponse(['buttons' => $buttons]);
        break;

    case 'get':
        $result = $db->query('SELECT * FROM buttons ORDER BY sort_order ASC, id ASC');
        $buttons = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $buttons[] = $row;
        }
        $settings = [];
        $res = $db->query('SELECT * FROM settings');
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $settings[$row['key']] = $row['value'];
        }
        jsonResponse(['buttons' => $buttons, 'settings' => $settings]);
        break;

    case 'settings':
        $result = $db->query('SELECT * FROM settings');
        $settings = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $settings[$row['key']] = $row['value'];
        }
        jsonResponse($settings);
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $password = $input['password'] ?? '';
        if ($password === getAdminPassword($db)) {
            $_SESSION['admin_logged_in'] = true;
            jsonResponse(['success' => true]);
        }
        jsonResponse(['error' => '密码错误'], 401);
        break;

    case 'logout':
        session_destroy();
        jsonResponse(['success' => true]);
        break;

    case 'change_password':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $oldPw = $input['old_password'] ?? '';
        $newPw = $input['new_password'] ?? '';
        if ($oldPw !== getAdminPassword($db)) jsonResponse(['error' => '当前密码错误'], 400);
        if (strlen($newPw) < 4) jsonResponse(['error' => '新密码至少4位'], 400);
        $stmt = $db->prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (:key, :value)');
        $stmt->bindValue(':key', 'admin_password', SQLITE3_TEXT);
        $stmt->bindValue(':value', $newPw, SQLITE3_TEXT);
        $stmt->execute();
        jsonResponse(['success' => true]);
        break;

    case 'add':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $title = trim($input['title'] ?? '');
        $url = trim($input['url'] ?? '');
        $icon = trim($input['icon'] ?? '');
        if (!$title || !$url) jsonResponse(['error' => '名称和链接不能为空'], 400);
        $maxOrder = $db->querySingle('SELECT COALESCE(MAX(sort_order), -1) FROM buttons');
        $stmt = $db->prepare('INSERT INTO buttons (title, url, icon, sort_order) VALUES (:title, :url, :icon, :order)');
        $stmt->bindValue(':title', $title, SQLITE3_TEXT);
        $stmt->bindValue(':url', $url, SQLITE3_TEXT);
        $stmt->bindValue(':icon', $icon, SQLITE3_TEXT);
        $stmt->bindValue(':order', $maxOrder + 1, SQLITE3_INTEGER);
        $stmt->execute();
        jsonResponse(['success' => true, 'id' => $db->lastInsertRowID()]);
        break;

    case 'update':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $title = trim($input['title'] ?? '');
        $url = trim($input['url'] ?? '');
        $icon = trim($input['icon'] ?? '');
        if (!$id || !$title || !$url) jsonResponse(['error' => '参数不完整'], 400);
        $stmt = $db->prepare('UPDATE buttons SET title=:title, url=:url, icon=:icon WHERE id=:id');
        $stmt->bindValue(':title', $title, SQLITE3_TEXT);
        $stmt->bindValue(':url', $url, SQLITE3_TEXT);
        $stmt->bindValue(':icon', $icon, SQLITE3_TEXT);
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $stmt->execute();
        jsonResponse(['success' => true]);
        break;

    case 'delete':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        if (!$id) jsonResponse(['error' => '无效ID'], 400);
        $stmt = $db->prepare('DELETE FROM buttons WHERE id=:id');
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $stmt->execute();
        jsonResponse(['success' => true]);
        break;

    case 'sort':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $order = $input['order'] ?? [];
        if (!is_array($order)) jsonResponse(['error' => '无效排序数据'], 400);
        $stmt = $db->prepare('UPDATE buttons SET sort_order=:order WHERE id=:id');
        foreach ($order as $i => $id) {
            $stmt->bindValue(':order', $i, SQLITE3_INTEGER);
            $stmt->bindValue(':id', intval($id), SQLITE3_INTEGER);
            $stmt->execute();
            $stmt->reset();
        }
        jsonResponse(['success' => true]);
        break;

    case 'update_settings':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (:key, :value)');
        foreach (['site_title', 'site_desc', 'search_engine', 'bg_video', 'logo'] as $key) {
            if (isset($input[$key])) {
                $stmt->bindValue(':key', $key, SQLITE3_TEXT);
                $stmt->bindValue(':value', trim($input[$key]), SQLITE3_TEXT);
                $stmt->execute();
                $stmt->reset();
            }
        }
        jsonResponse(['success' => true]);
        break;

    case 'upload_video':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        if (empty($_FILES['video'])) jsonResponse(['error' => '没有文件'], 400);
        $file = $_FILES['video'];
        if ($file['error'] !== UPLOAD_ERR_OK) jsonResponse(['error' => '上传错误: ' . $file['error']], 400);
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['mp4', 'webm'])) jsonResponse(['error' => '仅支持 MP4 和 WebM'], 400);
        if ($file['size'] > 100 * 1024 * 1024) jsonResponse(['error' => '文件不能超过 100MB'], 400);
        $filename = 'bg_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . '/' . $filename)) {
            jsonResponse(['error' => '保存文件失败'], 500);
        }
        jsonResponse(['success' => true, 'filename' => $filename]);
        break;

    case 'upload_image':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        if (empty($_FILES['image'])) jsonResponse(['error' => '没有文件'], 400);
        $file = $_FILES['image'];
        if ($file['error'] !== UPLOAD_ERR_OK) jsonResponse(['error' => '上传错误: ' . $file['error']], 400);
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'svg', 'webp'])) jsonResponse(['error' => '仅支持 JPG/PNG/SVG/WebP'], 400);
        if ($file['size'] > 5 * 1024 * 1024) jsonResponse(['error' => '文件不能超过 5MB'], 400);
        $filename = 'img_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . '/' . $filename)) {
            jsonResponse(['error' => '保存文件失败'], 500);
        }
        jsonResponse(['success' => true, 'filename' => $filename]);
        break;

    case 'upload_icon':
        if (!isLoggedIn()) jsonResponse(['error' => '未登录'], 401);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => '无效请求'], 405);
        if (empty($_FILES['icon'])) jsonResponse(['error' => '没有文件'], 400);
        $file = $_FILES['icon'];
        if ($file['error'] !== UPLOAD_ERR_OK) jsonResponse(['error' => '上传错误: ' . $file['error']], 400);
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'svg', 'webp'])) jsonResponse(['error' => '仅支持 JPG/PNG/SVG/WebP'], 400);
        if ($file['size'] > 2 * 1024 * 1024) jsonResponse(['error' => '文件不能超过 2MB'], 400);
        $filename = 'icon_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . '/' . $filename)) {
            jsonResponse(['error' => '保存文件失败'], 500);
        }
        jsonResponse(['success' => true, 'filename' => $filename]);
        break;

    default:
        jsonResponse(['error' => '未知操作'], 400);
        break;
}

$db->close();
