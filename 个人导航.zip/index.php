<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>导航页</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

    <div class="bg-no-video" id="bgFallback"></div>
    <div class="bg-video-wrap" id="bgVideoWrap" style="display:none">
        <video id="bgVideo" autoplay muted loop playsinline></video>
    </div>

    <div class="page-layer">
        <div class="container">

            <header class="site-header neu-card" id="siteHeader">
                <div class="scan-line"></div>
                <div class="site-logo" id="siteLogoWrap" style="display:none">
                    <img id="siteLogo" src="" alt="Logo">
                </div>
                <h1 class="site-title" id="siteTitle">我的导航</h1>
                <svg class="crayon-svg" viewBox="0 0 140 20" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="crayonGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stop-color="rgba(74,138,238,0.5)"/>
                            <stop offset="50%" stop-color="rgba(123,92,255,0.6)"/>
                            <stop offset="100%" stop-color="rgba(74,138,238,0.3)"/>
                        </linearGradient>
                    </defs>
                    <path d="M10,14 C20,6 30,16 45,10 C55,6 60,15 75,9 C85,5 95,16 110,10 C120,6 125,13 132,11" />
                </svg>
                <p class="site-desc" id="siteDesc">常用网站快捷入口</p>
                <div class="site-clock">
                    <span class="clock-time">
                        <span id="clockHour">--</span><span class="clock-colon">:</span><span id="clockMin">--</span><span class="clock-colon">:</span><span class="clockSec" id="clockSec">--</span>
                    </span>
                    <span class="clock-date" id="clockDate">----</span>
                </div>
            </header>

            <div class="search-wrap">
                <div class="search-bar neu-inset" id="searchBar">
                    <i class="fa-solid fa-magnifying-glass search-icon"></i>
                    <input type="text" id="searchInput" placeholder="搜索导航..." autocomplete="off">
                </div>
            </div>

            <div class="nav-grid" id="navGrid">
                <div class="empty-state" style="grid-column:1/-1;">
                    <i class="fa-solid fa-spinner fa-spin"></i>
                    <p>加载中...</p>
                </div>
            </div>

            <div class="footer">
                <p class="footer-copy">NavPage &copy; 2025</p>
            </div>

        </div>
    </div>

<script>
(function() {
    const ICON_THEMES = 8;
    let allButtons = [];

    function esc(str) {
        const d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    // ---- Clock ----
    function updateClock() {
        const now = new Date();
        const h = String(now.getHours()).padStart(2, '0');
        const m = String(now.getMinutes()).padStart(2, '0');
        const s = String(now.getSeconds()).padStart(2, '0');
        document.getElementById('clockHour').textContent = h;
        document.getElementById('clockMin').textContent = m;
        document.getElementById('clockSec').textContent = s;
        const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
        const dateStr = `${now.getFullYear()}年${now.getMonth()+1}月${now.getDate()}日 星期${weekdays[now.getDay()]}`;
        document.getElementById('clockDate').textContent = dateStr;
    }
    updateClock();
    setInterval(updateClock, 1000);

    // ---- 3D Tilt ----
    function initTilt() {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('mousemove', e => {
                const rect = btn.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width - 0.5;
                const y = (e.clientY - rect.top) / rect.height - 0.5;
                btn.style.transform = `translateY(-6px) perspective(600px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg)`;
            });
            btn.addEventListener('mouseleave', () => { btn.style.transform = ''; });
        });
    }

    // ---- Load ----
    async function loadNav() {
        try {
            const res = await fetch('api.php?action=get');
            const data = await res.json();

            if (data.settings) {
                const s = data.settings;

                if (s.site_title) {
                    document.getElementById('siteTitle').textContent = s.site_title;
                    document.title = s.site_title;
                }
                if (s.site_desc) {
                    document.getElementById('siteDesc').textContent = s.site_desc;
                }

                // Logo
                if (s.logo) {
                    document.getElementById('siteLogo').src = 'uploads/' + s.logo;
                    document.getElementById('siteLogoWrap').style.display = '';
                }

                // Main bg video
                if (s.bg_video) {
                    const video = document.getElementById('bgVideo');
                    video.src = 'uploads/' + s.bg_video;
                    video.load();
                    document.getElementById('bgVideoWrap').style.display = 'block';
                    document.getElementById('bgFallback').style.display = 'none';
                }

            }

            const grid = document.getElementById('navGrid');
            if (!data.buttons || data.buttons.length === 0) {
                grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><i class="fa-solid fa-link-slash"></i><p>暂无导航按钮</p></div>';
                return;
            }

            allButtons = data.buttons;
            renderNav(allButtons);
            initTilt();
        } catch (e) {
            document.getElementById('navGrid').innerHTML =
                '<div class="empty-state" style="grid-column:1/-1;"><i class="fa-solid fa-triangle-exclamation"></i><p>加载失败，请刷新重试</p></div>';
        }
    }

    // ---- Render ----
    function renderNav(buttons) {
        const grid = document.getElementById('navGrid');
        if (!buttons.length) {
            grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><i class="fa-solid fa-magnifying-glass"></i><p>没有匹配的导航</p></div>';
            return;
        }
        grid.innerHTML = buttons.map((btn, i) => {
            const iconHtml = btn.icon.startsWith('uploads/')
                ? `<img src="${esc(btn.icon)}" alt="" class="btn-icon-img">`
                : `<i class="${esc(btn.icon)}"></i>`;
            return `
            <a href="${esc(btn.url)}" class="nav-btn neu-card icon-theme-${(i % ICON_THEMES) + 1}" target="_blank" rel="noopener noreferrer" style="animation-delay:${0.05 + i * 0.04}s">
                <div class="btn-icon-wrap">
                    ${iconHtml}
                </div>
                <span>${esc(btn.title)}</span>
            </a>`;
        }).join('');
        initTilt();
    }

    // ---- Search ----
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', function() {
        const q = this.value.trim().toLowerCase();
        if (!q) {
            renderNav(allButtons);
            return;
        }
        const filtered = allButtons.filter(btn => btn.title.toLowerCase().includes(q) || btn.url.toLowerCase().includes(q));
        renderNav(filtered);
    });

    loadNav();
})();
</script>
</body>
</html>
